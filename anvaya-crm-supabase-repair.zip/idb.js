/* ============================================================================
   Anvaya CRM — local database
   ---------------------------------------------------------------------------
   IndexedDB is the working copy on the device: one object store per CRM table,
   plus a meta store (sync cursors) and an outbox (changes not yet accepted by
   the server).

   Every row carries three bookkeeping fields, stripped before it is sent:
     _dirty        this row has changes the server has not accepted
     _base         the server's updated_at when the local edit was made
     _deleted      a tombstone, so a delete can be replayed

   The module also ships a MemoryStore with the same interface, so the sync
   rules can be tested without a browser.
   ========================================================================== */
(function (root) {
  'use strict';

  const DB_NAME = 'anvaya';
  const DB_VERSION = 1;

  /* ---------------------------------------------------------------- IndexedDB */
  function openDb(tables) {
    return new Promise((resolve, reject) => {
      const req = root.indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const t of tables) {
          if (!db.objectStoreNames.contains(t)) {
            const s = db.createObjectStore(t, { keyPath: 'id' });
            s.createIndex('_dirty', '_dirty');
            s.createIndex('updated_at', 'updated_at');
          }
        }
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta');
        if (!db.objectStoreNames.contains('outbox')) {
          const o = db.createObjectStore('outbox', { keyPath: 'id' });
          o.createIndex('queuedAt', 'queuedAt');
        }
        if (!db.objectStoreNames.contains('conflicts')) {
          db.createObjectStore('conflicts', { keyPath: 'id' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function tx(db, stores, mode) {
    const t = db.transaction(stores, mode);
    const done = new Promise((resolve, reject) => {
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
    return { t, done };
  }

  const wrap = (req) => new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  function idbStore(db) {
    return {
      kind: 'indexeddb',

      async put(table, row) {
        const { t, done } = tx(db, [table], 'readwrite');
        t.objectStore(table).put(row);
        await done;
        return row;
      },

      async putMany(table, rows) {
        if (!rows.length) return 0;
        const { t, done } = tx(db, [table], 'readwrite');
        const store = t.objectStore(table);
        for (const r of rows) store.put(r);
        await done;
        return rows.length;
      },

      async get(table, id) {
        const { t } = tx(db, [table], 'readonly');
        return wrap(t.objectStore(table).get(id));
      },

      async all(table) {
        const { t } = tx(db, [table], 'readonly');
        return wrap(t.objectStore(table).getAll());
      },

      async remove(table, id) {
        const { t, done } = tx(db, [table], 'readwrite');
        t.objectStore(table).delete(id);
        await done;
      },

      async clear(table) {
        const { t, done } = tx(db, [table], 'readwrite');
        t.objectStore(table).clear();
        await done;
      },

      async dirty(table) {
        const { t } = tx(db, [table], 'readonly');
        return wrap(t.objectStore(table).index('_dirty').getAll(IDBKeyRange.only(1)));
      },

      async meta(key) {
        const { t } = tx(db, ['meta'], 'readonly');
        const v = await wrap(t.objectStore('meta').get(key));
        return v === undefined ? null : v;
      },

      async setMeta(key, value) {
        const { t, done } = tx(db, ['meta'], 'readwrite');
        t.objectStore('meta').put(value, key);
        await done;
      },

      async outboxAdd(item) {
        const { t, done } = tx(db, ['outbox'], 'readwrite');
        t.objectStore('outbox').put(item);
        await done;
      },

      async outboxList() {
        const { t } = tx(db, ['outbox'], 'readonly');
        const rows = await wrap(t.objectStore('outbox').getAll());
        return rows.sort((a, b) => a.queuedAt - b.queuedAt);
      },

      async outboxRemove(id) {
        const { t, done } = tx(db, ['outbox'], 'readwrite');
        t.objectStore('outbox').delete(id);
        await done;
      },

      async conflictAdd(entry) {
        const { t, done } = tx(db, ['conflicts'], 'readwrite');
        t.objectStore('conflicts').put(entry);
        await done;
      },

      async conflictList() {
        const { t } = tx(db, ['conflicts'], 'readonly');
        return wrap(t.objectStore('conflicts').getAll());
      },

      async conflictClear() {
        const { t, done } = tx(db, ['conflicts'], 'readwrite');
        t.objectStore('conflicts').clear();
        await done;
      }
    };
  }

  /* ------------------------------------------------------------------ memory */
  function memoryStore() {
    const data = new Map();       // table -> Map(id -> row)
    const meta = new Map();
    let outbox = [];
    let conflicts = [];
    const bucket = (t) => { if (!data.has(t)) data.set(t, new Map()); return data.get(t); };

    return {
      kind: 'memory',
      async put(table, row) { bucket(table).set(row.id, { ...row }); return row; },
      async putMany(table, rows) { for (const r of rows) bucket(table).set(r.id, { ...r }); return rows.length; },
      async get(table, id) { return bucket(table).get(id) || null; },
      async all(table) { return [...bucket(table).values()]; },
      async remove(table, id) { bucket(table).delete(id); },
      async clear(table) { bucket(table).clear(); },
      async dirty(table) { return [...bucket(table).values()].filter((r) => r._dirty); },
      async meta(key) { return meta.has(key) ? meta.get(key) : null; },
      async setMeta(key, value) { meta.set(key, value); },
      async outboxAdd(item) { outbox.push(item); },
      async outboxList() { return [...outbox].sort((a, b) => a.queuedAt - b.queuedAt); },
      async outboxRemove(id) { outbox = outbox.filter((i) => i.id !== id); },
      async conflictAdd(entry) { conflicts.push(entry); },
      async conflictList() { return [...conflicts]; },
      async conflictClear() { conflicts = []; }
    };
  }

  root.AnvayaDb = {
    async open(tables) { return idbStore(await openDb(tables)); },
    memory: memoryStore,
    available: typeof root.indexedDB !== 'undefined'
  };
  // Static shape so Node's CommonJS named-export detection can see it.
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { open: root.AnvayaDb.open, memory: memoryStore, available: root.AnvayaDb.available };
    module.exports.default = module.exports;
  }
})(typeof window !== 'undefined' ? window : globalThis);
