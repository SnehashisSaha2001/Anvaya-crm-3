# Anvaya CRM — Supabase connectivity and login repair

This is the engineering record of the repair: what was actually broken, what was
changed, and what was verified. Nothing here is a claim that was not measured.
Where a check could not be run in this environment it is marked **NOT VERIFIED**
and the reason is given.

---

## 1. Root causes — random Supabase connection failures

Seven independent faults, all of which had to be fixed. None of them was "the URL
is wrong", although a wrong URL made several of them worse.

### 1.1 `.vercelignore` excluded `api/` and `backend/`

```
backend/     ← ignored
api/         ← ignored
```

Vercel uploads the deployment source minus `.vercelignore`. Ignoring `api/`
removed the serverless function itself; ignoring `backend/` removed every module
it imports. `/api/*` therefore had no function behind it, and the browser's
request fell through to the SPA rewrite and received `index.html`.

*Consequence:* the API only ever worked under `npm run dev`. In production, login
and registration "worked" only when the frontend fell back to its demo engine.

### 1.2 Silent fallback to PGlite, and `delete process.env.DATABASE_URL`

```js
if (attempt >= maxRetries) {
  console.warn('[db] ... Falling back gracefully to local PGlite database.');
  delete process.env.DATABASE_URL;      // ← the URL is destroyed process-wide
  break;
}
```

Two failures in five lines. The first is that a production serverless function
silently switched to an embedded WASM PostgreSQL whose filesystem is read-only or
ephemeral: registrations either crashed with `EROFS` or vanished at the next cold
start. The second is that deleting `DATABASE_URL` made the process permanently
unrecoverable — every later call saw "no URL configured" and stayed on PGlite even
after the network returned. This is why the behaviour looked *random*: it depended
on whether the first attempt after a cold start happened to win.

### 1.3 Two pools, because `initDb()` was not concurrency-safe

```js
export async function initDb() {
  if (client) return client;        // ← checked before the await
  ...  const pool = new Pool(...);  // ← N concurrent callers all reach here
  await pool.query('select 1');
  client = pgAdapter(pool);
}
```

Under concurrent cold-start traffic every request that arrived before `client` was
assigned built its own pool. With `max: 5` and several instances, Supabase's
connection budget was exhausted (`53300 too many clients already`), which then
looked like a *different* random failure on the next request.

### 1.4 The direct Supabase host from Vercel

The shipped `DATABASE_URL` was `…@db.<ref>.supabase.co:5432/postgres`. Supabase's
direct endpoint is IPv6-only; Vercel's serverless network has no IPv6. Attempts
fail with `ENETUNREACH`/`ETIMEDOUT`, and whether they do depends on the instance's
egress path — intermittent by construction. The pooler
(`aws-0-<region>.pooler.supabase.com:6543`) is IPv4 and is the supported endpoint
for serverless.

### 1.5 Retries with no classification and no jitter

`maxRetries = 2` with a fixed `attempt * 1500ms` sleep, applied equally to
`28P01` (wrong password — permanent) and `ETIMEDOUT` (transient). Wrong
credentials were retried forever and eventually *did* trigger the PGlite
fallback; genuine transient faults got one extra try and then gave up.

### 1.6 Migrations ran on every boot, unversioned

`migrate()` read every `.sql` file and executed it on each start, with no
`schema_migrations` ledger. Two instances booting together ran the same DDL
concurrently; nothing recorded what had been applied, so drift was invisible.
`package.json` then wrapped it in `|| true`, so a failed migration produced a
successful deployment.

### 1.7 RLS was `FORCE`d — and that broke the system connection

`002_rls.sql` ran `ALTER TABLE … FORCE ROW LEVEL SECURITY` on all 51 tables.
`FORCE` applies policies to the **table owner** as well. On Supabase the
connecting role (`postgres`) is not a superuser, so:

* `sessions` deliberately has **no policy** → the auth layer could read **zero
  rows**, so `loadContext()` always returned `null` and every login was refused;
* `users`, `organisations` and `notifications` were equally unreadable through
  the system connection.

Local PGlite runs as a superuser, which bypasses RLS regardless of `FORCE` — so
every test passed while production could never sign anyone in.

---

## 2. Root causes — login and registration failures

### 2.1 The frontend fell into "standalone" mode and faked authentication

`data.js` probed `/api/health` **once**, with a **2.5 second** timeout. A Vercel
cold start (pool connect + retries) routinely exceeds that. On timeout:

```js
D.mode = off.rememberedMode() === 'server' ? 'offline' : 'standalone';
...
if (D.mode === 'standalone') return window.AnvayaEngine.handle(path, opts);
```

and `engine.js` answered:

```js
if (parts[1] === 'login') return { ok: true };          // always success
if (parts[1] === 'register') { /* build a fake workspace in localStorage */ }
```

So a slow first request turned the app into a demo: any password "logged in", and
registration created a browser-local workspace that existed nowhere else. The user
then could not reach their real workspace, because the real session had never been
created.

### 2.2 The schema in the Supabase instructions was a different schema

`supabase/anvaya-supabase.sql` — the file the docs told operators to paste — had
**29 tables and no `sessions` table at all**, no `subscriptions`, no
`members.workspace_id`, no `organisations.currency/timezone/settings`. The
application queries all of those. Registration failed on a missing column; login
failed on a missing table; `/api/health` still said the connection was fine
because it only ran `select now()`.

### 2.3 A `Secure` cookie on a non-https origin

```js
secure: process.env.NODE_ENV === 'production'
```

The shipped `.env` sets `NODE_ENV=production` while serving `http://localhost:3000`.
The browser discards `Secure` cookies on plain http, so login returned 200 and then
`/api/auth/me` returned 401 — the classic "it logs in but bounces me back".

### 2.4 Registration was not atomic with the session

`tx(...)` committed the user/org/workspace, then `createSession()` ran **outside**
the transaction. A failure there left a real account with no login and a 500 to the
user. Duplicate emails raced past the pre-check and surfaced as 500 rather than 409.

### 2.5 Suspended accounts and suspended workspaces were not checked

`/api/auth/login` verified the password and then issued a session without ever
looking at `users.status` (the column did not exist) or `organisations.status`.

### 2.6 Invitations were unauthenticated

`POST /api/auth/accept-invite` generated an `inviteToken`, never stored it, and
then set the password for any pending membership matching the supplied **email**.
Anyone who knew an invited address could take over the account.

### 2.7 The frontend reported success it had not observed

`doLogin()` called the endpoint and then `boot()`; it never inspected the
response, so `{ ok: true }` from the demo engine and a real 200 were
indistinguishable. `doRegister()` was the same.

---

## 3. What was changed

### Backend

| File | Change |
| --- | --- |
| `backend/src/db.js` | rewritten: single pool behind one shared promise; no PGlite in production (config error instead); `DATABASE_URL` never deleted; error classification (permanent vs transient); bounded exponential backoff with full jitter; pool tuned for serverless (`max`, `idleTimeoutMillis`, `connectionTimeoutMillis`, `maxUses`, `allowExitOnIdle`, `keepAlive`, `statement_timeout`); `verifyConnection()` does a real query; versioned migrations with `schema_migrations` + checksum + advisory lock + drift detection; `asUser()` fails closed when `SET LOCAL ROLE` does not take effect; driver errors become `DbUnavailableError` → 503 |
| `backend/src/health.js` | **new**. Structured health (`status`, `provider`, `driver`, `connectionStatus`, `schemaStatus`, `migrationStatus`, `authenticationStatus`, `workspaceStatus`, `rlsStatus`, `permissionsStatus`) plus administrator-only deep diagnostics. Never returns the URL, password, key, token or hash |
| `backend/src/security.js` | **new**. Fixed-window rate limiter (429 + `Retry-After`) and an Origin/`Sec-Fetch-Site` guard for cookie-authenticated state changes |
| `backend/src/auth.js` | session cookie flags derived from the **request protocol**, not `NODE_ENV`; `SameSite=Lax`, `HttpOnly`, explicit expiry; `createSessionIn(tx)` for atomic registration; `loadContext` checks user status, organisation status, active membership and resolves the workspace; constant-time-ish handling of unknown accounts; `requireAuth` returns 503 on outage |
| `backend/src/app.js` | `/api/health` rewritten (503 when unavailable); `/api/health/diagnostics`; registration is one transaction covering user → organisation → roles → workspace → owner membership → pipeline → 6 stages → subscription → notification → session, with rollback on any failure and 409 on duplicate email; login checks status/suspension and returns the workspace; `/api/auth/me` returns the workspace; `switch-workspace`; invite tokens are hashed and verified with an expiry; CORS no longer reflects arbitrary origins; JSON 404 for `/api/*`; error handler maps outages to 503 and never leaks internals |
| `backend/src/server.js` | refuses to start without a database in production; verifies the connection; migrations at boot with a hard failure (no `|| true`); demo seed only when `SEED_DEMO=1` and not in production; graceful shutdown |
| `backend/db/migrate.js` | rewritten: connects, verifies, applies versioned migrations, re-verifies schema/RLS/grants and **exits non-zero** on any problem; `--check` mode |
| `backend/db/migrations/006_auth_hardening.sql` | **new**. Removes `FORCE RLS` (the login-breaking fault), adds `users.status`/`suspended_at`, invite token hash + expiry, session indexes, re-asserts grants for `authenticated`, repairs null workspace pointers, adds `app.uid()`/`app.current_workspace()` |
| `backend/db/migrations/002_rls.sql` | `FORCE` → `no force` (RLS stays enabled; owner bypasses, request roles do not) |
| `api/index.js` | one shared init promise per instance; failed init is cleared so the next request retries; no migrations per request; JSON 503 with a safe code; raw-Node JSON responses (it sits outside Express); no secrets in logs |
| `backend/scripts/check-supabase.mjs` | rewritten as an 11-point doctor against the canonical schema, including the `FORCE RLS` and grant checks that would have caught the real outages |
| `backend/scripts/legacy/` | the dangerous one-off scripts (`disable-rls.js`, `grant-permissions.js`, `setup-supabase-complete.js`, `init-supabase-db.js`, debug scripts) moved here with a README, hardcoded passwords removed |
| `backend/tests/repair.test.js` | **new** — Tests A–F (32 checks) |
| `backend/tests/live-supabase.test.js` | **new** — wire-level checks that skip without `DATABASE_URL` |
| `backend/tests/supabase-doctor.test.js` | rewritten for the canonical schema, including a test that fails when RLS is forced |
| `backend/tests/test-pw.js` | deleted — a credential-guessing scratch file containing two plaintext passwords |

### Schema and deployment

| File | Change |
| --- | --- |
| `supabase/anvaya-supabase.sql` | **regenerated** from `backend/db/migrations/*.sql` by `scripts/build-supabase-sql.mjs`; one canonical schema |
| `supabase/legacy/` | the competing `00_…05_*.sql` set moved here with a README explaining why it must not be used |
| `scripts/build-supabase-sql.mjs` | **new** generator (+ `--check` for CI) |
| `scripts/build-static.mjs` | **new** static build; replaces the `node -e` build that swallowed migration failures |
| `scripts/verify-env.js` | rewritten: validates `DATABASE_URL` shape and endpoint mode, refuses `VITE_*`/`PUBLIC_*` secrets, never prints the password, non-zero exit |
| `vercel.json` | explicit build/install commands, function `maxDuration`, `/api` rewrite, `no-store` on API responses, SPA rewrite that excludes `/api` |
| `.vercelignore` | `api/` and `backend/` no longer ignored; secrets and zips ignored |
| `package.json` | `db:migrate`, `db:check`, `db:doctor`, `db:sql`, `env:verify`, `build`, `test` (runs on the `pg` path), `test:live` |
| `.env`, `backend/.env` | committed credentials removed; placeholders and instructions instead |
| `cookies.txt` | deleted (contained a live session token) |
| `index.html` | `meta[name="anvaya-demo"]="false"` — the hosted build cannot enter demo mode |
| `data.js` | rewritten: 3-attempt/12s health probe; explicit `unavailable` state; auth is never cached, queued or simulated; 503 becomes a readable error; demo mode requires an explicit flag **and** a local origin |
| `engine.js` | refuses every `/api/auth/*` route unless `window.ANVAYA_DEMO_ENABLED === true`; `health` no longer claims `mode: 'server'` |
| `app.js` | login/register inspect the response and verify `ok`, `org` and `workspace`; honest messages for 503/401/429; connection chip shows *Service unavailable*; `boot()` distinguishes 401 from 503 |
| `DEPLOY.md`, `README.md` | rewritten to describe the one real deployment path |
| `tools/build-single-file.py` | fixes the broken asset paths, and flips the demo flag for the single-file demo only |

---

## 4. Verification

Environment: Debian 12, Node 20.20.2, PostgreSQL engine 17.5 (embedded, via the
project's `pg` shim). **There is no network path from this environment to
`*.supabase.co`**, so nothing below is a claim about the user's live Supabase
project — those rows are marked NOT VERIFIED with the exact command to run.

`npm test` → **121 passing, 0 failing, 4 skipped** (the 4 are the live-Supabase
checks, skipped by design without `DATABASE_URL`).

### Test A — connectivity

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| A1 | Active driver | `pg` | `pg` | PASS |
| A2 | `/api/health` | 200, real query, all required fields, `status: ok`, `mode: server` | 200, `latencyMs: 2`, schema `ok` (52 tables), migrations `up-to-date` (`006_auth_hardening`), RLS `ok` (182 policies) | PASS |
| A3 | No secret in health | no URL / password hash / JWT / service key | none present | PASS |
| A4 | Required tables and columns | all present | 11/11 tables, all session columns | PASS |
| A5 | Missing `DATABASE_URL` in production | configuration error, **no** PGlite | `DB_CONFIG_MISSING`, `status: 503`, `driver: null`, server exits 1 | PASS |
| A6 | Error classification | credentials/3D000/ENOTFOUND permanent; ETIMEDOUT/ECONNRESET/57P03/53300 transient | as expected | PASS |
| A7 | Backoff | bounded, exponential ceiling, jittered | attempt 3 ≤ 400ms with 100ms base; capped at 1000ms; >5 distinct values | PASS |
| A8 | Concurrent requests | one pool, one init | 20 parallel requests, `initAttempts` unchanged | PASS |
| A9 | Unreachable database (serverless entry) | 503 JSON, no secrets, no HTML | `health 503`, `login 503`, `code: TIMEOUT`, `leaksUrl: false`, `leaksPassword: false` | PASS |
| A10 | Live Supabase connection | connected, doctor passes | — | **NOT VERIFIED** (no egress to `*.supabase.co` from this sandbox). Run `npm run db:doctor` |

### Test B — workspace creation

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| B1 | Registration writes everything | user, org, workspace, owner membership, 9 role templates, pipeline, 6 stages, trial subscription, notification, session | all present; password `scrypt$…`; `sessions.token_hash` is a 64-hex hash | PASS |
| B2 | Auto-login into the new workspace | `/api/auth/me` 200, same org and workspace | same ids, role `owner` | PASS |
| B3 | Duplicate email | 409, nothing created | 409, 1 user, no new org | PASS |
| B4 | Failure at step 9 of 11 | full rollback, no orphans | 500, zero user/org/workspace/member/pipeline/session rows; retry succeeds once the fault is removed | PASS |
| B5 | No orphan sessions or memberships | none | none | PASS |
| B6 | Same flow on the live project | real rows in Supabase | — | **NOT VERIFIED** — `LIVE_WRITE=1 npm run test:live` |

### Test C — sign-in

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| C1 | Correct credentials | 200, session usable | 200, `/me` 200 | PASS |
| C2 | Wrong password | 401, no cookie, no session row, no dashboard | 401, no cookie, count unchanged, `/me` 401 | PASS |
| C3 | Unknown account | 401, same message | 401 "Incorrect email or password." | PASS |
| C4 | Suspended account | 403 | 403 "This account is suspended…" | PASS |
| C5 | Expired session | 401 | 401 | PASS |
| C6 | Logout | revoked in DB, replay fails | `revoked_at` set, cookie cleared, replayed cookie → 401 | PASS |
| C7 | Browser restart | session survives | new client + same cookie → 200, same user and org | PASS |
| C8 | Second login | same workspace restored | same org, same workspace id | PASS |
| C9 | Cookie flags | `HttpOnly`, `SameSite=Lax`, `Path=/`, persistent, `Secure` only on https | exactly that (no `Secure` on http — the local-dev fix) | PASS |
| C10 | Rate limiting | the (N+1)th login attempt in the window → 429 | limiter unit test: 10 allowed, 11th refused; endpoint with `AUTH_LOGIN_LIMIT=2`: `401, 401, 429 (retryAfter=300), 429` | PASS |

### Test D — failure recovery

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| D1 | Database outage | health 503 + `mode: unavailable`; login 503; registration 503; authenticated reads 503; **no** fake session or workspace | exactly that, `ECONNRESET` code, no rows created | PASS |
| D2 | Recovery | next request 200, registration works without restart | 200, `status: ok`, registration 201 | PASS |
| D3 | Frontend on outage | "temporarily unable to connect to its database", no demo fallback | message rendered; `data.js` throws `serviceUnavailable`; `engine.js` refuses auth routes | PASS (static + unit assertions) |

### Test E — persistence

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| E1 | Record survives logout and re-login | same workspace, record still there | same org/workspace, `total: 1` | PASS |
| E2 | Data in PostgreSQL, not local | row in the SQL database | row present via SQL; driver `pg` | PASS |
| E3 | Redeploy does not erase data | — | — | **NOT VERIFIED** — requires a Vercel redeploy against the real project |

### Test F — security

| # | Test | Expected | Actual | Result |
| --- | --- | --- | --- | --- |
| F1 | Organisation isolation | no cross-tenant read/update/delete; no org switch | 404/404/404, `switch-org` 403 | PASS |
| F2 | Invalid session | 401 | 401 (forged and empty) | PASS |
| F3 | Cookie behaviour | see C9 | PASS | PASS |
| F4 | Cross-site state change | 403 `CROSS_SITE_BLOCKED`, session untouched | 403, session still valid | PASS |
| F5 | No secrets in browser files | no URL, JWT, service key, `DATABASE_URL` | none in 8 frontend files | PASS |
| F6 | Demo auth cannot run in production | explicit flag + local origin required | `meta=false`, guard in `engine.js`, gating in `data.js` | PASS |
| F7 | RLS policies enforced | policies present and not forced | 182 policies, 0 forced, tenant scoping verified through `SET LOCAL ROLE` | PASS |
| F8 | Live RLS on Supabase | same | — | **NOT VERIFIED** — `npm run db:doctor` check 11 |

### End-to-end HTTP smoke (real processes, not the test harness)

| Check | Result |
| --- | --- |
| `NODE_ENV=production` with no `DATABASE_URL` | exits 1: `DB_CONFIG_MISSING`, "must be set to a Supabase PostgreSQL connection string in production" |
| Serverless entry with an unreachable host | `/api/health` 503, `/api/auth/login` 503, no URL or password in the body |
| Dev server: register → me → create lead → logout → me | 201 → 200 (org+workspace) → 201 → 200 → 401 |
| Wrong password | 401 "Incorrect email or password." |
| Correct password after logout | 200, same org, **same workspace** |
| Lead created before logout | still there (`total: 1`) |

---

## 5. What you must do — exact steps

### 5.1 Rotate the credentials that were committed

The repository contained, in plaintext: the Supabase database password (in `.env`,
`backend/.env`), an anon key, and — in the deleted scratch scripts — two further
database passwords. **Treat all of them as compromised.**

1. Supabase → Settings → Database → **Reset database password**.
2. Project Settings → API → **Roll the anon key** if you use it anywhere.
3. Update the new password only in Vercel's environment variables (and your local
   `.env` if you run the server locally).

### 5.2 Supabase

1. SQL Editor → paste all of `supabase/anvaya-supabase.sql` → **Run**. It is
   idempotent; it will not drop data.
2. Confirm: `select count(*) from information_schema.tables where table_schema='public';`
   → 52 (or more if you have extra tables).
3. Settings → Database → Connection string → **URI**, copy the **pooler** host.

### 5.3 Vercel

Project → Settings → Environment Variables (Production and Preview):

```
DATABASE_URL   postgresql://postgres.<ref>:<url-encoded-password>@aws-0-<region>.pooler.supabase.com:6543/postgres
NODE_ENV       production
DB_USER_ROLE   authenticated
DB_POOL_SIZE   3
ENCRYPTION_KEY <openssl rand -base64 48>
```

Then **Redeploy** (environment changes only apply to new deployments).

### 5.4 Migrations

```bash
npm ci
DATABASE_URL="…pooler…:6543/postgres" npm run db:migrate
DATABASE_URL="…pooler…:6543/postgres" npm run db:doctor
```

`db:migrate` exits non-zero unless the schema, RLS policies and grants all verify.

### 5.5 Prove it

```bash
curl -s https://<your-app>/api/health | jq '{status, provider, driver, connectionStatus, schemaStatus, migrationStatus}'
```

Then register a new account in the browser and confirm `GET /api/auth/me` returns
the organisation and workspace the registration just created.

---

## 6. What still needs your account access

1. **Live connection to your Supabase project.** No network path exists from the
   environment this was repaired in. Everything above was proven against the same
   SQL, the same driver adapter and the same HTTP layer, but the wire protocol and
   your project's actual state are unverified. `npm run db:doctor` settles it in
   one command.
2. **A real redeploy.** `vercel.json` and `.vercelignore` are fixed, but only a
   deployment can confirm the function is bundled with `backend/`.
3. **The existing rows in your database.** If an earlier run created accounts
   through the demo engine, those accounts exist only in browsers — there is
   nothing in Supabase to migrate. If `supabase/anvaya-supabase.sql` (the 29-table
   version) was applied, the canonical migration set adds the missing tables and
   columns additively; no existing row is touched.
4. **Password rotation**, as above — only you can do it.

---

## 7. Deliberate limitations

* The rate limiter is per instance. On Vercel each instance keeps its own window;
  it stops credential stuffing from one client, not a distributed attack. A shared
  store (Upstash/Redis) can be dropped in behind `hit()` without touching callers.
* `sessions` has no RLS policy by design: it is read only by the system connection,
  which is why `FORCE RLS` had to go. Request connections still cannot read it
  (verified by `has_table_privilege` in the doctor).
* PGlite remains in the codebase for local development and tests only. It is
  refused on Vercel and whenever `NODE_ENV=production`.
* MFA, PDF documents, payments and integrations were not touched.

---

## 8. Addendum — dependency installation (the "check your package.json" error)

A platform reported *"Dependency installation failed. Please check your
package.json."* The manifests were the problem, not the dependencies.

| File | Change |
| --- | --- |
| `package.json` | `devDependencies` removed entirely (`puppeteer-core`, `tsx` — neither was imported anywhere; `tsx` pulls `esbuild`, which runs a platform-binary install script). `engines` relaxed from `>=20` to `>=18`. `build` now builds the static bundle only; the strict environment check moved to `npm run verify`, so a build cannot fail because a database URL is absent. |
| `bun.lock` | deleted. A stale Bun lockfile next to an npm lockfile makes an installer that prefers Bun resolve a tree the code was not written against. |
| `backend/package.json` | reduced to a four-line ESM marker (`"type": "module"`, no dependencies, no scripts). It existed to make `backend/` ESM, and its own dependency list was a second source of truth. |
| `backend/package-lock.json` | deleted — a second lockfile for the same code. |
| `package-lock.json` | regenerated from a clean install (lockfileVersion 3, 103 packages, **no package in the tree runs an install script**). |

Verified installs from a clean directory, with an empty cache:

| Command | Result |
| --- | --- |
| `npm ci` | 103 packages, no errors |
| `npm ci --omit=dev` | 103 packages, no errors |
| `npm install --omit=dev` with no lockfile | 103 packages, no errors |
| `npm test` after the change | 121 passing, 0 failing, 4 skipped |

Runtime dependencies are now the five the server actually imports: `express`,
`pg`, `serverless-http`, `pdfkit`, `@electric-sql/pglite` (local development and
tests only). `node_modules` is 46 MB, and nothing in it compiles or downloads at
install time.

**What this does not fix:** Google AI Studio runs Vite-style web apps — it
installs, builds a static bundle and serves it. It cannot run
`backend/src/server.js` and has nowhere to keep a `DATABASE_URL`, so it cannot
host the API that login and workspace creation depend on. Editing the code there
is fine; connecting it to Supabase is not something that runtime can do. Deploy
to Vercel (`DEPLOY.md`, sections 2–5) for the real thing.
