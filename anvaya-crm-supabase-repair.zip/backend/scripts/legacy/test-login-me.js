import { createApp } from '../src/app.js';
import { initDb } from '../src/db.js';
import http from 'node:http';

async function run() {
  await initDb();
  const app = createApp();
  const server = http.createServer(app);
  server.listen(0, async () => {
    const port = server.address().port;
    try {
      const loginResp = await fetch(`http://localhost:${port}/api/auth/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email: 'sneha@brightline.in', password: 'AnvayaDemo2026' })
      });
      const cookie = loginResp.headers.get('set-cookie');
      console.log('Login status:', loginResp.status, 'Cookie:', cookie);

      const meResp = await fetch(`http://localhost:${port}/api/auth/me`, {
        headers: { cookie }
      });
      const meData = await meResp.json();
      console.log('Me status:', meResp.status, 'Me body:', meData);
    } catch (err) {
      console.error('Test failed:', err);
    } finally {
      server.close();
    }
  });
}
run();
