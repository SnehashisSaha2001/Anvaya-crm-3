# Connecting Anvaya CRM to Supabase

This page used to describe a seven-check script and a hand-maintained schema
file. Both are gone. **The canonical instructions are in
[`../DEPLOY.md`](../DEPLOY.md)** (sections 1–5), and the record of what was
broken is in [`SUPABASE-REPAIR.md`](SUPABASE-REPAIR.md).

Short version:

```bash
# 1 · schema: paste supabase/anvaya-supabase.sql into the Supabase SQL editor
# 2 · connection string: Settings → Database → URI, pooler host, port 6543
# 3 · from the repository root:
DATABASE_URL="postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres" \
  npm run db:migrate      # applies + verifies, exits non-zero on any problem

DATABASE_URL="…" npm run db:doctor    # 11 checks, each naming its own fix
```

`npm run db:migrate` **is** the right command for Supabase now. The old advice on
this page ("do not run the migrations against Supabase") was written when there
were two schemas — a hand-maintained Supabase file and a separate migration set.
They disagreed: the Supabase file had 29 tables and no `sessions` table, so
registration and login could never work on a database built from it. There is
now one schema (`backend/db/migrations/*.sql`) and
`supabase/anvaya-supabase.sql` is generated from it by
`scripts/build-supabase-sql.mjs`, so the two cannot drift again.

## Two things that still matter

**`DB_USER_ROLE=authenticated`.** Every request runs as that role, so row-level
security applies. Without it the backend connects as the table owner and the
policies protect nothing. `006_auth_hardening.sql` grants the privileges that
role needs; the doctor fails if they are missing.

**The pooler, not the direct host.** `db.<ref>.supabase.co:5432` is IPv6-only and
fails intermittently from Vercel. Use
`aws-0-<region>.pooler.supabase.com:6543` on serverless, `:5432` on a
long-running server.
