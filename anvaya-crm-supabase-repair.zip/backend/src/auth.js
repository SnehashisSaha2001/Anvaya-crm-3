// Authentication, sessions and request context.
//
// Passwords: scrypt with a per-user salt (preserved — this is not a partial
// Supabase Auth migration, and there is exactly one identity system).
// Sessions: an opaque 32-byte token in an httpOnly cookie; only its SHA-256
// hash is stored, so a database read cannot be replayed as a login.
//
// Every function here is honest about failure: an unusable session returns
// null, a database outage throws DbUnavailableError (→ HTTP 503), and nothing
// ever fabricates a logged-in user.

import crypto from 'node:crypto';
import { q, one, DbUnavailableError } from './db.js';

const SESSION_COOKIE = 'anvaya_session';
const ORG_COOKIE = 'anvaya_org';
const WORKSPACE_COOKIE = 'anvaya_workspace';
const SESSION_DAYS = Number(process.env.SESSION_DAYS || 7);

// ------------------------------------------------------------- passwords ---
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$16384$8$1$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  try {
    const parts = String(stored || '').split('$');
    if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
    const salt = parts[4];
    const hash = parts[5];
    const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
    const a = Buffer.from(hash, 'hex');
    const b = Buffer.from(candidate, 'hex');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/**
 * Burn the same CPU as a real verification when the account does not exist,
 * so login timing does not reveal which emails are registered.
 */
export function dummyVerify(password) {
  try {
    crypto.scryptSync(String(password || 'x'), 'anvaya-timing-equaliser', 64);
  } catch { /* ignore */ }
  return false;
}

export function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 10) return 'Password must be at least 10 characters';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password must contain a letter and a number';
  return null;
}

// -------------------------------------------------------------- sessions ---
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

/** Create a session on the system connection (used by /api/auth/login). */
export async function createSession(userId, req) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000);
  const row = await one(
    `insert into sessions (user_id, token_hash, ip, user_agent, expires_at) values ($1,$2,$3,$4,$5) returning id`,
    [userId, sha(token), clientIp(req), (req?.headers?.['user-agent'] || '').slice(0, 200), expires]
  );
  return { id: row.id, token, tokenHash: sha(token), expires };
}

/**
 * Insert a session inside an existing transaction, so registration can create
 * the user, the workspace and the login in one atomic unit.
 */
export async function createSessionIn(t, userId, req) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000);
  const row = await t.one(
    `insert into sessions (user_id, token_hash, ip, user_agent, expires_at) values ($1,$2,$3,$4,$5) returning id`,
    [userId, sha(token), clientIp(req), (req?.headers?.['user-agent'] || '').slice(0, 200), expires]
  );
  return { id: row.id, token, tokenHash: sha(token), expires };
}

export async function destroySession(token) {
  if (!token) return;
  await q(`update sessions set revoked_at = now() where token_hash = $1 and revoked_at is null`, [sha(token)]);
}

/** Revoke every session of a user (used after a password change). */
export async function destroyAllSessions(userId) {
  await q(`update sessions set revoked_at = now() where user_id = $1 and revoked_at is null`, [userId]);
}

function clientIp(req) {
  if (!req) return null;
  const fwd = req.headers?.['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length) return fwd.split(',')[0].trim().slice(0, 64);
  return (req.ip || req.socket?.remoteAddress || null)?.toString().slice(0, 64) || null;
}

function readCookie(req, name) {
  const raw = req.headers?.cookie || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return null;
}

/**
 * A cookie is only `Secure` when the browser is actually on https. Setting
 * Secure because NODE_ENV says "production" while the app is served over
 * http://localhost makes the browser drop the cookie: login appears to
 * succeed, then /api/auth/me answers 401 and the user is back on the login
 * screen. That was one of the real causes of the "login does not stick" bug.
 */
function isHttps(req) {
  if (!req) return process.env.NODE_ENV === 'production' && !process.env.ALLOW_INSECURE_COOKIES;
  const proto = String(req.headers?.['x-forwarded-proto'] || '').split(',')[0].trim();
  if (proto) return proto === 'https';
  if (req.secure) return true;
  return false;
}

const baseCookie = (req) => ({
  httpOnly: true,
  sameSite: 'lax',
  secure: isHttps(req),
  path: '/'
});

export function setSessionCookie(res, token, expires, req) {
  res.cookie(SESSION_COOKIE, token, {
    ...baseCookie(req),
    expires,
    maxAge: Math.max(0, new Date(expires).getTime() - Date.now())
  });
}

export function clearSessionCookie(res, req) {
  const opts = { ...baseCookie(req) };
  res.clearCookie(SESSION_COOKIE, opts);
  res.clearCookie(ORG_COOKIE, { ...opts, httpOnly: false });
  res.clearCookie(WORKSPACE_COOKIE, { ...opts, httpOnly: false });
}

/** The active organisation. Readable by JS so the UI can show a switcher. */
export function setOrgCookie(res, orgId, req) {
  res.cookie(ORG_COOKIE, orgId, {
    ...baseCookie(req),
    httpOnly: false,
    maxAge: SESSION_DAYS * 86400_000
  });
}

/** The active workspace inside that organisation. */
export function setWorkspaceCookie(res, workspaceId, req) {
  if (!workspaceId) return;
  res.cookie(WORKSPACE_COOKIE, workspaceId, {
    ...baseCookie(req),
    httpOnly: false,
    maxAge: SESSION_DAYS * 86400_000
  });
}

// ------------------------------------------------------- request context ---
/**
 * Resolve the caller from the session cookie.
 * Returns null for "not signed in" (401) and throws DbUnavailableError for
 * "database is down" (503) — the two must never be confused.
 */
export async function loadContext(req, { allowPendingMfa = false } = {}) {
  const token = readCookie(req, SESSION_COOKIE);
  if (!token) return null;

  const session = await one(
    `select s.id, s.user_id, s.expires_at, s.revoked_at, s.mfa_ok,
            u.email, u.full_name, u.is_platform_admin, u.mfa_enabled_at,
            coalesce(u.status, 'active') as user_status
       from sessions s join users u on u.id = s.user_id
      where s.token_hash = $1`,
    [sha(token)]
  );
  if (!session || session.revoked_at) return null;
  if (new Date(session.expires_at) <= new Date()) return null;
  if (session.user_status !== 'active') return null;      // suspended or disabled account
  if (session.mfa_ok === false && !allowPendingMfa) return null;

  const memberships = await q(
    `select m.id as member_id, m.org_id, m.workspace_id, m.status, m.title,
            r.id as role_id, r.key as role_key, r.name as role_name, r.permissions,
            o.name as org_name, o.currency, o.timezone, o.plan, o.settings, o.status as org_status,
            w.id as ws_id, w.name as ws_name, w.slug as ws_slug
       from members m
       join roles r on r.id = m.role_id
       join organisations o on o.id = m.org_id
       left join workspaces w on w.id = m.workspace_id
      where m.user_id = $1 and m.status = 'active'
        and o.deleted_at is null and o.status <> 'suspended'
      order by o.name`,
    [session.user_id]
  );
  if (!memberships.length) return null;

  const wantedOrg = readCookie(req, ORG_COOKIE);
  const active = memberships.find((m) => m.org_id === wantedOrg) || memberships[0];

  // Workspace: the member's own workspace, else the organisation's default.
  let workspaceId = active.ws_id || active.workspace_id || null;
  let workspaceName = active.ws_name || null;
  if (!workspaceId) {
    const ws = await one(
      `select id, name from workspaces where org_id = $1 order by is_default desc, created_at limit 1`,
      [active.org_id]
    );
    workspaceId = ws?.id || null;
    workspaceName = ws?.name || null;
  }

  const settings = active.settings || {};
  const requireMfa = settings.require_mfa === true || settings.require_mfa === 'true';

  return {
    token,
    sessionId: session.id,
    mfaOk: session.mfa_ok !== false,
    mfaEnabled: Boolean(session.mfa_enabled_at),
    mfaSetupRequired: requireMfa && !session.mfa_enabled_at,
    userId: session.user_id,
    email: session.email,
    fullName: session.full_name,
    isPlatformAdmin: session.is_platform_admin,
    orgId: active.org_id,
    orgName: active.org_name,
    orgPlan: active.plan,
    currency: active.currency,
    timezone: active.timezone,
    plan: active.plan,
    workspaceId,
    workspaceName,
    memberId: active.member_id,
    memberStatus: active.status,
    roleId: active.role_id,
    roleKey: active.role_key,
    roleName: active.role_name,
    perms: active.permissions || [],
    memberships: memberships.map((m) => ({
      orgId: m.org_id, orgName: m.org_name, roleKey: m.role_key, roleName: m.role_name,
      plan: m.plan, workspaceId: m.ws_id || m.workspace_id || null
    }))
  };
}

export async function requireAuth(req, res, next) {
  try {
    // An API key has already resolved a context; do not override it with a cookie.
    if (req.ctx) return next();
    const ctx = await loadContext(req);
    if (!ctx) return res.status(401).json({ error: 'Not authenticated', code: 'NOT_AUTHENTICATED' });
    req.ctx = ctx;
    next();
  } catch (err) {
    if (err instanceof DbUnavailableError) {
      return res.status(503).json({
        error: 'Anvaya CRM is temporarily unable to connect to its database. Please try again.',
        code: err.code || 'DB_UNAVAILABLE'
      });
    }
    next(err);
  }
}

/** Route guard: requires a permission key in the active organisation. */
export function requirePerm(perm) {
  return (req, res, next) => {
    const perms = req.ctx?.perms || [];
    if (perms.includes('*') || perms.includes(perm)) return next();
    return res.status(403).json({ error: `Missing permission: ${perm}`, code: 'MISSING_PERMISSION' });
  };
}

/** Platform-level guard for the super admin console. */
export function requirePlatformAdmin(req, res, next) {
  if (!req.ctx?.isPlatformAdmin) return res.status(403).json({ error: 'Platform admin only', code: 'PLATFORM_ADMIN_ONLY' });
  next();
}

export const cookies = { SESSION_COOKIE, ORG_COOKIE, WORKSPACE_COOKIE, readCookie };
