# Anvaya CRM V6

A CRM that deploys without surprises.

The reason the earlier builds failed on Vercel was structural: one folder tried to be
both a static site and a Node server, so the platform kept guessing wrong. This rewrite
splits the two, and the split is the whole design:

```
  index.html, app.js, …   the app, at the repo root → deploys anywhere, zero config
  backend/                optional server → deploys to a host that gives it a disk
```

The app files sit at the root on purpose. An earlier version kept them in `web/`, and
deploying that folder served `index.html` while every `styles.css` request 404'd — the
page arrived unstyled. Root-level files with relative paths cannot break that way.

**Production runs one way: the app plus the backend, on Supabase PostgreSQL.**
There is no automatic switch to browser storage in a hosted build and no simulated
login. If the API cannot reach its database the app says *"Anvaya CRM is temporarily
unable to connect to its database"* and refuses to sign anyone in — it never invents an
account. The in-browser engine still exists, but only for the single-file demo build,
which sets `meta[name="anvaya-demo"]="true"` explicitly.

Start with [`DEPLOY.md`](DEPLOY.md) for Supabase and Vercel, and
[`docs/SUPABASE-REPAIR.md`](docs/SUPABASE-REPAIR.md) for what was broken and how it was
verified.

---

## What is here

| Path | What it is |
|---|---|
| `index.html` | the application shell |
| `app.js` | the interface: dashboard, leads, deals, 360, tickets, reports… |
| `engine.js` | the local data engine — the same routes, served from the browser |
| `data.js` | the bridge that picks between the engine and the server |
| `styles.css` | the design system |
| `manifest.webmanifest`, `sw.js`, `pwa.js`, `icons/` | makes it installable and offline-capable |
| `backend/` | optional Express + PostgreSQL server, 38 tables, 134 RLS policies |
| `tools/build-single-file.py` | builds one self-contained .html from the same sources |

---

## Run it locally

With Supabase — real database, real accounts (recommended):

```bash
npm ci
cp .env.example .env            # fill DATABASE_URL from Supabase → Settings → Database
npm run db:migrate              # canonical schema, verified
npm run dev                     # http://localhost:3000
npm test                        # 121 checks
```

A laptop with no Supabase project may use the embedded engine instead
(`DB_ALLOW_PGLITE=1`), which is refused in production and on Vercel.

<details>
<summary>Older notes (superseded): running the backend from <code>backend/</code></summary>

This used to be the way to start the server. It is not any more: there is one
manifest at the root and one lockfile, because two of them meant some platforms
installed a dependency tree the code was never written against.

```bash
npm ci                 # from the repository root
SEED_DEMO=1 npm run dev  # http://localhost:3000 with the demo workspace
```

---

## Deploy

### Vercel + Supabase (the production path)

See [`DEPLOY.md`](DEPLOY.md). In short: run `supabase/anvaya-supabase.sql` in the
Supabase SQL editor, set `DATABASE_URL` (pooler, port 6543), `NODE_ENV` and
`DB_USER_ROLE` in Vercel, then `npm run db:migrate` once from your machine.

### The backend — Railway, Render, Fly.io, a VM

Any container host works. It needs the same three variables (`DATABASE_URL`,
`NODE_ENV=production`, `DB_USER_ROLE=authenticated`) and a writable disk is *not*
required — the database is Supabase.

```bash
npm ci && npm run db:migrate && npm start    # PORT from the environment
```

The app is served by the same process, so no `anvaya-api` meta tag is needed when the
frontend and API share an origin. If they do not, set the meta tag and `CORS_ORIGIN`.

### Install it as an app

The same URL installs as a real application — no app store, no signing, no separate
builds:

| Platform | How |
|---|---|
| Windows (Chrome, Edge) | Install icon in the address bar, or menu → Apps → Install this site |
| macOS (Chrome, Edge) | Same as Windows; in Safari, File → Open in Safari, then Share → Add to Dock |
| Android (Chrome) | Menu → Install app (an in-app banner offers it too) |
| iOS / iPadOS (Safari) | Share → Add to Home Screen (Chrome on iOS cannot install PWAs) |

It opens in its own window with its own icon, works offline once opened, and keeps your
records on the device. The **Install app** button in the header walks you through it.

See [`DEPLOY.md`](DEPLOY.md) for the step-by-step of each path, including moving to
Supabase Postgres.

---

## Responsive

One layout, three targets — no separate mobile app, no "view desktop site" fallback.

| | Phone (<=760px) | Tablet (761–1024px) | Desktop (>=1025px) |
|---|---|---|---|
| Navigation | off-canvas drawer + 5-slot bottom bar | drawer, rail when wide | fixed sidebar, collapsible to a rail |
| Tables | one card per record, each field labelled | full table | full table |
| Pipeline | swipeable columns, snap to one stage | 3–4 visible columns | all stages visible |
| Copilot | full screen | side panel | side panel |
| Search | icon in the header | icon in the header | full search field |

Details that make it usable on a phone rather than merely fitting: 38px minimum touch
targets, 16px inputs so iOS does not zoom on focus, `viewport-fit=cover` and
`env(safe-area-inset-*)` padding so the notch and home bar do not overlap content,
`100dvh` so the browser's address bar does not crop the layout, drawer scroll locking,
and drag-and-drop replaced by a stage picker in the deal sheet (HTML5 drag does not
exist on touch).

| | |
|---|---|
| ![Phone](docs/screenshots/phone-home.png) | ![Menu](docs/screenshots/phone-menu.png) |
| Home on a 390px phone | The drawer, with labels and install/theme/help |
| ![Phone leads](docs/screenshots/phone-leads.png) | ![Tablet](docs/screenshots/tablet-home.png) |
| Tables become labelled cards | Tablet: three stats across, drawer navigation |

## What V6 added

| Feature | Status |
|---|---|
| Two-factor authentication (TOTP + backup codes) | Working, 4 tests |
| PDF quotations, tax invoices and receipts | Working, 3 tests |
| Payments, part payments, refunds, credit notes, payment links | Working, 6 tests |
| Invoice numbering, GST split, overdue detection | Working, 5 tests |
| Navigation rebuilt to the seven-group structure, permission-aware | Working |

64 backend tests pass, including all 48 that covered V5 — the regression
evidence that the upgrade did not break the existing product. Read
`docs/V6-ASSESSMENT.md` for the audit and `docs/V6-RELEASE.md` for the feature
status, test report and migration guide. Manuals: `docs/USER-MANUAL.md`,
`docs/ADMIN-MANUAL.md`.

## Where this stands against the big five

The competitive gap list, answered honestly. "Built" means it works and is tested here;
"needs your credentials" means the code is finished but the provider side is yours.

| # | Gap | Status | Notes |
|---|---|---|---|
| 1 | Gmail/Outlook + calendar two-way sync | **Built, needs credentials** | OAuth flow, encrypted token storage, refresh, delta sync, de-duplication. Reading mail/events into activities works; sending is stubbed behind the same token. Set `GOOGLE_CLIENT_ID` / `MS_CLIENT_ID` + `ENCRYPTION_KEY`. |
| 2 | Visual kanban, drag and drop | **Built** | Drag between stages on desktop, tap-to-move on touch, keyboard move, audit entry and automations on every change. |
| 3 | Workflow automation builder | **Built (form-based)** | Trigger → conditions → actions → approval → run log. A node canvas is not built; the engine and logs are. |
| 4 | Web-to-lead + email-to-lead | **Built** | Public form endpoint with honeypot, rate limit and duplicate flag; embeddable snippet; HMAC-signed inbound email that matches an existing contact or creates a lead. |
| 5 | AI summaries + next-best-action | **Built** | Copilot over your records in two modes; per-deal next step on the deal sheet; every run logged. |
| 6 | Custom fields and layouts | **Built (fields)** | Admin-defined fields appear automatically on lead, contact, company, deal and ticket forms and are stored per record. Layout editor not built. |
| 7 | Roles + multi-currency | **Roles built, currency partial** | Nine role templates enforced in the API and in RLS. Currency is stored per deal; rollups convert at a stored rate — the FX admin screen is not built. |
| 8 | User-built reports and saved views | **Saved views built, builder partial** | Views persist per user and can be shared. Report builder is fixed widgets, not drag-your-own-metric. |
| 9 | Mobile offline read/update | **Partial** | The static edition is fully offline. The server edition caches the shell but queues no writes yet. |
| 10 | API + connectors + Zapier/Make | **Built** | REST API with scoped bearer keys, HMAC-signed outbound webhooks, OpenAPI document at `/api/openapi.json`. Zapier/Make consume these without a custom connector. |

## What is built

Working end to end: dashboard, leads (with one-click conversion into company + contact +
deal), contacts and companies, customer 360, multi-stage pipeline with drag and drop,
tasks, support tickets with SLA state, products, quotations, invoices, projects,
campaigns, a workflow engine (trigger → conditions → actions → approval → logs), reports,
settings with members and roles, the copilot, global search and a help panel.

Not built: field operations, the no-code builder, a visual workflow canvas. OAuth
integrations, payment processing, PDF generation and MFA *are* built (see the table
below) but need your provider credentials before they do anything.

## How the app talks to the server

`data.js` probes `GET /api/health` at boot (three attempts, 12s timeout — a serverless
cold start is normal, not a failure) and reports one of four states in the header chip:

| Chip | Meaning | Authentication |
|---|---|---|
| **Live data** | `/api/health` answered `mode: "server"` after a real query | works |
| **Offline** | the server was reachable before and is not now | refused (401) — reads come from cache |
| **Service unavailable** | the API answered 503 because its database is down | refused (503) with a plain message |
| **Demo data** | single-file demo build, no server exists | simulated, local only |

Authentication is never cached, queued or simulated in a hosted build. There is no
code path in which a wrong password, a failed database or a missing server produces a
logged-in user.

## Tests

```bash
npm test        # 121 checks: connectivity, registration, sign-in, recovery, persistence, security
npm run db:doctor   # live diagnosis against a real DATABASE_URL
npm run test:live   # live Supabase checks (skipped without DATABASE_URL)
```

The repair suite (`backend/tests/repair.test.js`) is the one to read: it injects a
database outage, asserts HTTP 503 and that no session or workspace was invented, then
asserts recovery on the next request. The security suite asserts cross-tenant reads
return 404, a deliberately unscoped SQL query returns nothing, and a read-only member is
blocked at both the API and the database.

## What V6 added

| Feature | Status |
|---|---|
| Two-factor authentication (TOTP + backup codes) | Working, 4 tests |
| PDF quotations, tax invoices and receipts | Working, 3 tests |
| Payments, part payments, refunds, credit notes, payment links | Working, 6 tests |
| Invoice numbering, GST split, overdue detection | Working, 5 tests |
| Navigation rebuilt to the seven-group structure, permission-aware | Working |

64 backend tests pass, including all 48 that covered V5 — the regression
evidence that the upgrade did not break the existing product. Read
`docs/V6-ASSESSMENT.md` for the audit and `docs/V6-RELEASE.md` for the feature
status, test report and migration guide. Manuals: `docs/USER-MANUAL.md`,
`docs/ADMIN-MANUAL.md`.

## Where this stands against the big five

The competitive gap list, answered honestly. "Built" means it works and is tested here;
"needs your credentials" means the code is finished but the provider side is yours.

| # | Gap | Status | Notes |
|---|---|---|---|
| 1 | Gmail/Outlook + calendar two-way sync | **Built, needs credentials** | OAuth flow, encrypted token storage, refresh, delta sync, de-duplication. Reading mail/events into activities works; sending is stubbed behind the same token. Set `GOOGLE_CLIENT_ID` / `MS_CLIENT_ID` + `ENCRYPTION_KEY`. |
| 2 | Visual kanban, drag and drop | **Built** | Drag between stages on desktop, tap-to-move on touch, keyboard move, audit entry and automations on every change. |
| 3 | Workflow automation builder | **Built (form-based)** | Trigger → conditions → actions → approval → run log. A node canvas is not built; the engine and logs are. |
| 4 | Web-to-lead + email-to-lead | **Built** | Public form endpoint with honeypot, rate limit and duplicate flag; embeddable snippet; HMAC-signed inbound email that matches an existing contact or creates a lead. |
| 5 | AI summaries + next-best-action | **Built** | Copilot over your records in two modes; per-deal next step on the deal sheet; every run logged. |
| 6 | Custom fields and layouts | **Built (fields)** | Admin-defined fields appear automatically on lead, contact, company, deal and ticket forms and are stored per record. Layout editor not built. |
| 7 | Roles + multi-currency | **Roles built, currency partial** | Nine role templates enforced in the API and in RLS. Currency is stored per deal; rollups convert at a stored rate — the FX admin screen is not built. |
| 8 | User-built reports and saved views | **Saved views built, builder partial** | Views persist per user and can be shared. Report builder is fixed widgets, not drag-your-own-metric. |
| 9 | Mobile offline read/update | **Partial** | The static edition is fully offline. The server edition caches the shell but queues no writes yet. |
| 10 | API + connectors + Zapier/Make | **Built** | REST API with scoped bearer keys, HMAC-signed outbound webhooks, OpenAPI document at `/api/openapi.json`. Zapier/Make consume these without a custom connector. |

## What is built

Working end to end: dashboard, leads (with one-click conversion into company + contact +
deal), contacts and companies, customer 360, multi-stage pipeline with drag and drop,
tasks, support tickets with SLA state, products, quotations, invoices, projects,
campaigns, a workflow engine (trigger → conditions → actions → approval → logs), reports,
settings with members and roles, the copilot, global search and a help panel.

Not built: field operations, the no-code builder, OAuth integrations, payment
processing, PDF generation, MFA. Those are listed as absent rather than shipped as dead
buttons.

## How the app talks to the server

`data.js` probes `GET /api/health` at boot (three attempts, 12s timeout — a serverless
cold start is normal, not a failure) and reports one of four states in the header chip:

| Chip | Meaning | Authentication |
|---|---|---|
| **Live data** | `/api/health` answered `mode: "server"` after a real query | works |
| **Offline** | the server was reachable before and is not now | refused (401) — reads come from cache |
| **Service unavailable** | the API answered 503 because its database is down | refused (503) with a plain message |
| **Demo data** | single-file demo build, no server exists | simulated, local only |

Authentication is never cached, queued or simulated in a hosted build. There is no
code path in which a wrong password, a failed database or a missing server produces a
logged-in user.

## Tests

```bash
npm test                    # 121 checks: connectivity, registration, sign-in, recovery, persistence, security
```

The security tests are the ones worth reading: cross-tenant reads return 404, a
deliberately unscoped SQL query returns nothing, a read-only member is blocked at both
the API and the database, and audit rows cannot be forged.
