// Long-running server (local development, a VM, Docker, Railway, Render).
// Vercel does not use this file; api/index.js is the serverless entry point.

import { createApp } from './app.js';
import { initDb, migrate, verifyConnection, explainDbError, dbStatus, pgliteAllowed, closeDb } from './db.js';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const app = createApp();

async function boot() {
  // Connect once. A failure here is fatal: a server with no database would
  // only serve 503s, and pretending otherwise hides a real misconfiguration.
  try {
    await initDb();
  } catch (err) {
    const info = explainDbError(err);
    console.error(`\n[startup] cannot start: database unavailable (${info.code}/${info.kind})`);
    console.error(`[startup] ${info.message}`);
    const status = dbStatus();
    console.error(`[startup] target: provider=${status.provider} host=${status.host} port=${status.port} `
      + `database=${status.database} pooler=${status.pooler}`);
    if (!pgliteAllowed()) {
      console.error('[startup] DATABASE_URL must be set to a Supabase PostgreSQL connection string in production.');
    }
    process.exit(1);
  }

  const check = await verifyConnection();
  console.log(check.ok
    ? `[db] verified: ${check.database} as ${check.user} (${check.latencyMs}ms, ${check.version})`
    : `[db] verification failed: ${check.error.code}`);

  // Migrations run at boot only for a long-running server, and only when the
  // operator has not turned it off. They are versioned, so a restart is cheap.
  if (process.env.AUTO_MIGRATE !== '0') {
    try {
      const out = await migrate({ log: (m) => console.log(m) });
      console.log(`[db] migrations: ${out.applied.length} applied, ${out.skipped.length} already present`);
    } catch (err) {
      console.error(`[db] MIGRATION FAILED: ${err.message}`);
      console.error('[db] refusing to serve a database whose schema does not match the code');
      process.exit(1);
    }
  }

  // Demo data is a development convenience only, and never in production.
  if (process.env.SEED_DEMO === '1' && pgliteAllowed()) {
    try {
      const { runSeed } = await import('../db/seed.js');
      await runSeed();
      console.log('[db] demo workspace seeded');
    } catch (err) {
      console.error('[db] demo seed failed:', err.message);
    }
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`Anvaya CRM listening on http://${HOST}:${PORT}`);
    console.log(`AI provider: ${process.env.AI_API_KEY ? 'configured' : 'local rules (no model configured)'}`);
    console.log(`Database: ${dbStatus().provider} via ${dbStatus().driver}`);
  });

  const shutdown = async (signal) => {
    console.log(`\n[shutdown] ${signal} received, closing connections`);
    server.close(async () => {
      await closeDb();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

boot().catch((err) => {
  console.error('[startup] failed:', err?.message);
  process.exit(1);
});
