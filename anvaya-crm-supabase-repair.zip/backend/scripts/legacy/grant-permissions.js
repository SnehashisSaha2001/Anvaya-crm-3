import pg from 'pg';

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false }
});

async function main() {
  console.log('[grants] Granting full privileges on public schema to authenticated, anon, service_role...');
  await pool.query(`
    grant usage on schema public to authenticated, anon, service_role;
    grant all privileges on all tables in schema public to authenticated, service_role, anon;
    grant all privileges on all sequences in schema public to authenticated, service_role, anon;
    alter default privileges in schema public grant all privileges on tables to authenticated, service_role, anon;
    alter default privileges in schema public grant all privileges on sequences to authenticated, service_role, anon;
  `);
  console.log('[grants] Privileges granted successfully!');
  await pool.end();
}

main().catch(err => {
  console.error('[grants] Error:', err);
  process.exit(1);
});
