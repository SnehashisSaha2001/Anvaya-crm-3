-- ============================================================================
-- ANVAYA CRM — complete Supabase schema
--
-- GENERATED FILE — do not edit. Source: backend/db/migrations/*.sql
-- Regenerate with: node scripts/build-supabase-sql.mjs
--
-- How to use it: Supabase → SQL Editor → New query → paste this whole file →
-- Run. It is idempotent (create table if not exists / add column if not
-- exists), so running it twice is harmless and it will not drop data.
--
-- It contains no seed data and no demo account. Create your account through
-- the app's registration page, which writes a real user, organisation and
-- workspace.
--
-- Migrations included: 001_schema.sql, 002_rls.sql, 003_growth.sql, 004_mfa.sql, 005_documents_finance.sql, 006_auth_hardening.sql
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 001_schema.sql  (sha256:5f4648ffc5a4)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 001 schema
-- Plain PostgreSQL (13+). Applies unchanged to Supabase.
-- Every organisation-owned table carries org_id and is protected by RLS
-- in 002_rls.sql.
-- ============================================================================

create schema if not exists app;

-- Application role. Requests run as this role so RLS is enforced.
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'app_user') then
    create role app_user nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin;
  end if;
exception when others then
  raise notice 'Could not create application roles; continuing';
end $$;

-- ---------------------------------------------------------------- helpers ---
create or replace function app.current_org() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.org_id', true), '')::uuid
$$;

create or replace function app.current_user() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.user_id', true), '')::uuid
$$;

create or replace function app.perms() returns text[]
  language sql stable as $$
    select coalesce(string_to_array(nullif(current_setting('app.perms', true), ''), ','), '{}'::text[])
$$;

create or replace function app.has_perm(p text) returns boolean
  language sql stable as $$
    select p = any(app.perms()) or '*' = any(app.perms())
$$;

create or replace function app.touch() returns trigger
  language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ----------------------------------------------------------- organisations ---
create table if not exists organisations (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  industry      text,
  currency      char(3) not null default 'INR',
  timezone      text not null default 'Asia/Kolkata',
  locale        text not null default 'en-IN',
  fiscal_start_month int not null default 4 check (fiscal_start_month between 1 and 12),
  working_hours jsonb not null default '{"days":[1,2,3,4,5,6],"start":"09:30","end":"18:30"}',
  logo_url      text,
  plan          text not null default 'professional',
  status        text not null default 'active' check (status in ('active','suspended','deleted')),
  settings      jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create table if not exists workspaces (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  slug       text not null,
  is_default boolean not null default false,
  settings   jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, slug)
);

create table if not exists users (
  id                uuid primary key default gen_random_uuid(),
  email             text not null unique,
  password_hash     text not null,
  full_name         text not null,
  phone             text,
  avatar_initials   text,
  email_verified_at timestamptz,
  mfa_secret        text,
  is_platform_admin boolean not null default false,
  last_login_at     timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table if not exists roles (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  key         text not null,
  name        text not null,
  description text,
  permissions text[] not null default '{}',
  is_system   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, key)
);

create table if not exists members (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid not null references users(id) on delete cascade,
  role_id     uuid not null references roles(id),
  workspace_id uuid references workspaces(id) on delete set null,
  status      text not null default 'active' check (status in ('invited','active','suspended')),
  title       text,
  department  text,
  invited_by  uuid references users(id),
  invited_at  timestamptz,
  joined_at   timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, user_id)
);

create table if not exists sessions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  token_hash text not null unique,
  ip         text,
  user_agent text,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- CRM ---
create table if not exists companies (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  domain         text,
  industry       text,
  size_band      text,
  annual_revenue numeric(16,2),
  phone          text,
  website        text,
  city           text,
  country        text default 'India',
  address        jsonb not null default '{}',
  parent_id      uuid references companies(id) on delete set null,
  owner_id       uuid references members(id) on delete set null,
  health_score   int not null default 60 check (health_score between 0 and 100),
  tags           text[] not null default '{}',
  custom         jsonb not null default '{}',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz
);

create table if not exists contacts (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  company_id   uuid references companies(id) on delete set null,
  first_name   text not null,
  last_name    text,
  email        text,
  phone        text,
  title        text,
  city         text,
  owner_id     uuid references members(id) on delete set null,
  tags         text[] not null default '{}',
  consent      jsonb not null default '{"email":true,"whatsapp":false,"calls":true,"recorded_at":null}',
  health_score int not null default 60 check (health_score between 0 and 100),
  custom       jsonb not null default '{}',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz
);
create index if not exists contacts_org_company on contacts (org_id, company_id);
create index if not exists contacts_email on contacts (org_id, lower(email));

create table if not exists leads (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  name                text not null,
  company_name        text,
  email               text,
  phone               text,
  source              text not null default 'website',
  status              text not null default 'new'
                      check (status in ('new','contacted','qualified','proposal','negotiation','converted','lost')),
  score               int check (score between 0 and 100),
  score_reason        text,
  owner_id            uuid references members(id) on delete set null,
  estimated_value     numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  notes               text,
  converted_contact_id uuid references contacts(id) on delete set null,
  converted_deal_id   uuid,
  lost_reason         text,
  last_contacted_at   timestamptz,
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists leads_org_status on leads (org_id, status);

create table if not exists pipelines (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists stages (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  pipeline_id uuid not null references pipelines(id) on delete cascade,
  name        text not null,
  position    int not null default 0,
  probability int not null default 10 check (probability between 0 and 100),
  is_won      boolean not null default false,
  is_lost     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists deals (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  pipeline_id         uuid not null references pipelines(id),
  stage_id            uuid not null references stages(id),
  company_id          uuid references companies(id) on delete set null,
  contact_id          uuid references contacts(id) on delete set null,
  title               text not null,
  value               numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  probability         int check (probability between 0 and 100),
  expected_close_date date,
  owner_id            uuid references members(id) on delete set null,
  status              text not null default 'open' check (status in ('open','won','lost')),
  lost_reason         text,
  competitor          text,
  source_lead_id      uuid references leads(id) on delete set null,
  stage_changed_at    timestamptz not null default now(),
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists deals_org_status on deals (org_id, status);
create index if not exists deals_org_stage on deals (org_id, stage_id);

create table if not exists activities (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  type        text not null check (type in ('call','email','meeting','note','visit')),
  subject     text not null,
  body        text,
  contact_id  uuid references contacts(id) on delete cascade,
  company_id  uuid references companies(id) on delete cascade,
  deal_id     uuid references deals(id) on delete cascade,
  ticket_id   uuid,
  owner_id    uuid references members(id) on delete set null,
  occurred_at timestamptz not null default now(),
  duration_min int,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists activities_org_contact on activities (org_id, contact_id, occurred_at desc);

create table if not exists tasks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  title        text not null,
  notes        text,
  due_date     date,
  due_time     time,
  priority     text not null default 'medium' check (priority in ('low','medium','high','urgent')),
  status       text not null default 'open' check (status in ('open','in_progress','done','cancelled')),
  assignee_id  uuid references members(id) on delete set null,
  related_type text,
  related_id   uuid,
  recurrence   text,
  completed_at timestamptz,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists tasks_org_assignee on tasks (org_id, assignee_id, status);

-- ------------------------------------------------------------- service ------
create table if not exists tickets (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  subject       text not null,
  description   text,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  priority      text not null default 'medium' check (priority in ('low','medium','high','critical')),
  status        text not null default 'open' check (status in ('open','in_progress','waiting','resolved','closed')),
  category      text,
  assignee_id   uuid references members(id) on delete set null,
  sla_policy    text not null default 'standard',
  sla_due_at    timestamptz,
  first_response_at timestamptz,
  resolved_at   timestamptz,
  csat          int check (csat between 1 and 5),
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);
create index if not exists tickets_org_status on tickets (org_id, status);

create table if not exists ticket_comments (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  ticket_id  uuid not null references tickets(id) on delete cascade,
  author_id  uuid references users(id),
  body       text not null,
  is_internal boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists knowledge_articles (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  title      text not null,
  body       text not null,
  category   text,
  is_public  boolean not null default false,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------ marketing ----
create table if not exists campaigns (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  channel        text not null default 'email' check (channel in ('email','sms','whatsapp')),
  status         text not null default 'draft' check (status in ('draft','scheduled','sending','sent','paused','failed')),
  subject        text,
  body           text,
  audience       jsonb not null default '{}',
  scheduled_at   timestamptz,
  sent_at        timestamptz,
  provider       text,
  provider_ref   text,
  stats          jsonb not null default '{"sent":0,"delivered":0,"opened":0,"clicked":0,"bounced":0}',
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists campaign_recipients (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  campaign_id         uuid not null references campaigns(id) on delete cascade,
  contact_id          uuid references contacts(id) on delete cascade,
  status              text not null default 'queued' check (status in ('queued','sent','delivered','opened','clicked','bounced','failed')),
  provider_message_id text,
  error               text,
  updated_at          timestamptz not null default now(),
  created_at          timestamptz not null default now()
);

-- ------------------------------------------------------------- commerce ----
create table if not exists products (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  sku           text not null,
  name          text not null,
  category      text,
  description   text,
  unit_price    numeric(14,2) not null default 0,
  tax_rate      numeric(5,2) not null default 18,
  stock_qty     numeric(14,2) not null default 0,
  reorder_point numeric(14,2) not null default 0,
  uom           text default 'unit',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, sku)
);

create table if not exists quotations (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','accepted','rejected','expired')),
  issue_date    date not null default current_date,
  valid_until   date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  discount_total numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  notes         text,
  terms         text,
  version       int not null default 1,
  approved_at   timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists quotation_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  quotation_id uuid not null references quotations(id) on delete cascade,
  product_id  uuid references products(id) on delete set null,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  discount    numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists invoices (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  quotation_id  uuid references quotations(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','partially_paid','paid','overdue','cancelled')),
  issue_date    date not null default current_date,
  due_date      date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  amount_paid   numeric(16,2) not null default 0,
  notes         text,
  paid_at       timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists invoice_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid not null references invoices(id) on delete cascade,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists payments (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  invoice_id   uuid not null references invoices(id) on delete cascade,
  amount       numeric(16,2) not null,
  method       text not null default 'bank_transfer',
  provider     text,
  provider_ref text,
  status       text not null default 'succeeded' check (status in ('pending','succeeded','failed','refunded')),
  received_at  timestamptz not null default now(),
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- delivery ----
create table if not exists projects (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  deal_id     uuid references deals(id) on delete set null,
  company_id  uuid references companies(id) on delete set null,
  status      text not null default 'planned' check (status in ('planned','active','on_hold','completed','cancelled')),
  start_date  date,
  end_date    date,
  budget      numeric(16,2) not null default 0,
  spent       numeric(16,2) not null default 0,
  progress    int not null default 0 check (progress between 0 and 100),
  manager_id  uuid references members(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists milestones (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  project_id  uuid not null references projects(id) on delete cascade,
  name        text not null,
  due_date    date,
  completed_at timestamptz,
  position    int not null default 0
);

-- ----------------------------------------------------------- automation ----
create table if not exists workflows (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  description text,
  status      text not null default 'draft' check (status in ('draft','active','paused')),
  version     int not null default 1,
  trigger     jsonb not null,
  conditions  jsonb not null default '[]',
  actions     jsonb not null default '[]',
  run_count   int not null default 0,
  last_run_at timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists workflow_runs (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  workflow_id    uuid not null references workflows(id) on delete cascade,
  workflow_version int not null default 1,
  trigger_entity text,
  trigger_id     uuid,
  status         text not null default 'running' check (status in ('running','succeeded','failed','skipped','awaiting_approval')),
  context        jsonb not null default '{}',
  error          text,
  started_at     timestamptz not null default now(),
  finished_at    timestamptz
);

create table if not exists workflow_steps (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  run_id     uuid not null references workflow_runs(id) on delete cascade,
  step_index int not null default 0,
  node_type  text not null,
  status     text not null default 'succeeded',
  output     jsonb not null default '{}',
  error      text,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- AI ----
create table if not exists ai_runs (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid references users(id),
  agent       text not null default 'copilot',
  provider    text,
  model       text,
  prompt      text,
  response    text,
  status      text not null default 'succeeded' check (status in ('running','succeeded','failed')),
  tokens_in   int not null default 0,
  tokens_out  int not null default 0,
  latency_ms  int,
  error       text,
  created_at  timestamptz not null default now()
);

create table if not exists ai_actions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  run_id       uuid references ai_runs(id) on delete cascade,
  action       text not null,
  target_table text,
  target_id    uuid,
  payload      jsonb not null default '{}',
  status       text not null default 'proposed' check (status in ('proposed','approved','rejected','applied','failed')),
  approved_by  uuid references users(id),
  applied_at   timestamptz,
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- platform ----
create table if not exists custom_fields (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  entity     text not null check (entity in ('lead','contact','company','deal','ticket','project')),
  key        text not null,
  label      text not null,
  type       text not null default 'text' check (type in ('text','number','date','select','multiselect','boolean','url')),
  options    jsonb not null default '[]',
  required   boolean not null default false,
  position   int not null default 0,
  created_at timestamptz not null default now(),
  unique (org_id, entity, key)
);

create table if not exists custom_values (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  field_id   uuid not null references custom_fields(id) on delete cascade,
  record_id  uuid not null,
  value      text,
  updated_at timestamptz not null default now(),
  unique (field_id, record_id)
);

create table if not exists notifications (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid not null references users(id) on delete cascade,
  type       text not null default 'info',
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  actor_id   uuid references users(id),
  actor_name text,
  action     text not null,
  entity     text,
  entity_id  uuid,
  before     jsonb,
  after      jsonb,
  ip         text,
  created_at timestamptz not null default now()
);
create index if not exists audit_org_created on audit_logs (org_id, created_at desc);

create table if not exists subscriptions (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references organisations(id) on delete cascade,
  plan               text not null default 'professional',
  status             text not null default 'trialing' check (status in ('trialing','active','past_due','cancelled')),
  seats              int not null default 5,
  trial_ends_at      timestamptz,
  current_period_end timestamptz,
  usage              jsonb not null default '{"ai_credits":0,"emails":0}',
  limits             jsonb not null default '{"seats":5,"ai_credits":2000,"emails":5000}',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists integrations (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  status       text not null default 'disconnected' check (status in ('disconnected','pending','connected','error')),
  scopes       text[] not null default '{}',
  config       jsonb not null default '{}',
  connected_at timestamptz,
  last_error   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, provider)
);

-- forward reference: leads -> deals (deals is created after leads)
alter table leads drop constraint if exists leads_converted_deal_fk;
alter table leads add constraint leads_converted_deal_fk
  foreign key (converted_deal_id) references deals(id) on delete set null;

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array[
    'organisations','workspaces','users','roles','members','companies','contacts','leads',
    'pipelines','stages','deals','activities','tasks','tickets','knowledge_articles',
    'campaigns','products','quotations','invoices','projects','workflows','custom_fields',
    'subscriptions','integrations'
  ]
  loop
    execute format('drop trigger if exists touch_%1$s on %1$I', t);
    execute format('create trigger touch_%1$s before update on %1$I for each row execute function app.touch()', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- 002_rls.sql  (sha256:ddc1db32ded9)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 002 row level security
--
-- Requests run as the `app_user` role. Every organisation-owned table is
-- scoped to app.current_org(); writes additionally require a permission key.
-- Tenant isolation therefore holds even if application code forgets a WHERE
-- clause, and a read-only user cannot write through a direct SQL path.
-- ============================================================================

grant usage on schema public to app_user, authenticated;
grant usage on schema app to app_user, authenticated;
grant execute on all functions in schema app to app_user, authenticated;

grant select, insert, update, delete on all tables in schema public to app_user, authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to app_user, authenticated;
grant usage, select on all sequences in schema public to app_user, authenticated;
alter default privileges in schema public grant usage, select on sequences to app_user, authenticated;

-- ---------------------------------------------------------------- generic ---
do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('companies','company',true),
      ('contacts','contact',true),
      ('leads','lead',true),
      ('deals','deal',true),
      ('pipelines','pipeline',true),
      ('stages','pipeline',true),
      ('activities','activity',true),
      ('tasks','task',true),
      ('tickets','ticket',true),
      ('ticket_comments','ticket',true),
      ('knowledge_articles','ticket',true),
      ('campaigns','campaign',true),
      ('campaign_recipients','campaign',true),
      ('products','product',true),
      ('quotations','quotation',true),
      ('quotation_items','quotation',true),
      ('invoices','invoice',true),
      ('invoice_items','invoice',true),
      ('payments','payment',false),
      ('projects','project',true),
      ('milestones','project',true),
      ('workflows','workflow',true),
      ('workflow_runs','workflow',false),
      ('workflow_steps','workflow',false),
      ('ai_runs','ai',false),
      ('ai_actions','ai',false),
      ('custom_fields','settings',true),
      ('custom_values','settings',true),
      ('integrations','integration',true),
      ('workspaces','workspace',true),
      ('roles','settings',true),
      ('members','member',true),
      ('subscriptions','billing',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    -- Deliberately NOT "force row level security": on Supabase the connecting
    -- role is not a superuser, and FORCE would apply these policies to the
    -- application's own system connection (auth, migrations, audit). The
    -- session lookup has no policy by design, so forcing it made every login
    -- read zero rows. RLS stays enabled: the owner bypasses it, request
    -- connections (SET ROLE authenticated / app_user) do not.
    execute format('alter table %I no force row level security', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format(
      'create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format(
      'create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');

    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format(
      'create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');

    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format(
        'create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- --------------------------------------------------------------- specials ---

-- organisations: a member sees only their own organisation
alter table organisations enable row level security;
alter table organisations no force row level security;
drop policy if exists organisations_sel on organisations;
create policy organisations_sel on organisations for select
  using (id = app.current_org());
drop policy if exists organisations_upd on organisations;
create policy organisations_upd on organisations for update
  using (id = app.current_org() and app.has_perm('settings.write'))
  with check (id = app.current_org());

-- users: yourself, plus colleagues in the same organisation
alter table users enable row level security;
alter table users no force row level security;
drop policy if exists users_sel on users;
create policy users_sel on users for select
  using (
    id = app.current_user()
    or exists (select 1 from members m where m.user_id = users.id and m.org_id = app.current_org())
  );
drop policy if exists users_upd on users;
create policy users_upd on users for update
  using (id = app.current_user())
  with check (id = app.current_user());

-- notifications: strictly your own
alter table notifications enable row level security;
alter table notifications no force row level security;
drop policy if exists notifications_sel on notifications;
create policy notifications_sel on notifications for select
  using (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_upd on notifications;
create policy notifications_upd on notifications for update
  using (user_id = app.current_user() and org_id = app.current_org())
  with check (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_ins on notifications;
create policy notifications_ins on notifications for insert
  with check (org_id = app.current_org() and app.has_perm('notification.write'));

-- audit_logs: readable, never writable by application users.
-- Rows are written by the system connection so a user cannot forge or erase
-- their own trail.
alter table audit_logs enable row level security;
alter table audit_logs no force row level security;
drop policy if exists audit_sel on audit_logs;
create policy audit_sel on audit_logs for select
  using (org_id = app.current_org() and app.has_perm('audit.read'));

-- sessions: no policy at all. Only the auth layer (system connection) reads
-- them, so a compromised request context cannot enumerate other sessions.
alter table sessions enable row level security;
alter table sessions no force row level security;

-- ---------------------------------------------------------------------------
-- 003_growth.sql  (sha256:079a12f3cd0b)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 003 growth features
-- Capture (web forms, inbound email), API access, outbound webhooks,
-- integration state, saved views and exchange rates.
-- ============================================================================

-- ------------------------------------------------------------- web forms ---
create table if not exists web_forms (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  slug           text not null unique,
  headline       text default 'Talk to us',
  description    text,
  fields         jsonb not null default '["name","email","phone","company_name","message"]',
  required       jsonb not null default '["name"]',
  success_message text not null default 'Thank you — we will be in touch shortly.',
  redirect_url   text,
  default_source text not null default 'web_form',
  owner_id       uuid references members(id) on delete set null,
  is_active      boolean not null default true,
  submission_count int not null default 0,
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists form_submissions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  form_id      uuid not null references web_forms(id) on delete cascade,
  lead_id      uuid references leads(id) on delete set null,
  payload      jsonb not null default '{}',
  ip           text,
  user_agent   text,
  is_duplicate boolean not null default false,
  created_at   timestamptz not null default now()
);
create index if not exists form_submissions_form on form_submissions (form_id, created_at desc);

-- -------------------------------------------------------------- api keys ---
create table if not exists api_keys (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  prefix      text not null,
  key_hash    text not null unique,
  scopes      text[] not null default '{"read"}',
  last_used_at timestamptz,
  request_count int not null default 0,
  created_by  uuid references users(id),
  revoked_at  timestamptz,
  created_at  timestamptz not null default now()
);
create index if not exists api_keys_org on api_keys (org_id) where revoked_at is null;

-- -------------------------------------------------------------- webhooks ---
create table if not exists webhooks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  url          text not null,
  description  text,
  secret       text not null,
  events       text[] not null default '{}',
  is_active    boolean not null default true,
  last_status  text,
  last_error   text,
  last_fired_at timestamptz,
  failure_count int not null default 0,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists webhook_deliveries (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  webhook_id    uuid not null references webhooks(id) on delete cascade,
  event         text not null,
  payload       jsonb not null default '{}',
  status        text not null default 'pending' check (status in ('pending','delivered','failed')),
  response_code int,
  error         text,
  attempts      int not null default 1,
  created_at    timestamptz not null default now()
);
create index if not exists webhook_deliveries_wh on webhook_deliveries (webhook_id, created_at desc);

-- ----------------------------------------------------- integration state ---
alter table integrations add column if not exists tokens       text;   -- AES-256-GCM, never returned by the API
alter table integrations add column if not exists account      text;   -- provider account label, e.g. the mailbox
alter table integrations add column if not exists cursor       text;   -- delta sync marker
alter table integrations add column if not exists sync_state   jsonb not null default '{}';
alter table integrations add column if not exists last_synced_at timestamptz;

-- ----------------------------------------------------------- saved views ---
create table if not exists saved_views (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid references users(id) on delete cascade,
  resource   text not null,
  name       text not null,
  filters    jsonb not null default '{}',
  sort       text,
  is_shared  boolean not null default false,
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------- exchange rates ---
create table if not exists exchange_rates (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  currency    char(3) not null,
  rate_to_org numeric(16,6) not null,
  as_of       date not null default current_date,
  unique (org_id, currency, as_of)
);

-- ------------------------------------------------------------------ RLS ----
do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('web_forms','settings',true),
      ('form_submissions','settings',false),
      ('api_keys','settings',true),
      ('webhooks','settings',true),
      ('webhook_deliveries','settings',false),
      ('saved_views','lead',true),
      ('exchange_rates','settings',true)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- api keys are read by the auth layer on the system connection, so the
-- application role only ever sees its own organisation's keys.

-- ---------------------------------------------------------------------------
-- 004_mfa.sql  (sha256:26757f29bfe9)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 004 multi-factor authentication
--
-- Additive only: no existing column is dropped or retyped, so V5 data and
-- accounts keep working untouched.
-- ============================================================================

-- --------------------------------------------------------------------- MFA ---
alter table users add column if not exists mfa_secret        text;
alter table users add column if not exists mfa_enabled_at    timestamptz;
alter table users add column if not exists mfa_backup_codes  text[] not null default '{}';
alter table users add column if not exists mfa_last_used_at  timestamptz;

-- A session created before the second factor is not usable until it is proven.
alter table sessions add column if not exists mfa_ok boolean not null default true;

-- Organisation-level enforcement lives in organisations.settings->>'require_mfa'.

-- ---------------------------------------------------------------------------
-- 005_documents_finance.sql  (sha256:4b4a05fb6e63)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 005 documents and finance
--
-- Additive only. Existing invoices, quotations and payments keep their rows and
-- their meaning; new columns are nullable or defaulted so V5 data reads the
-- same after the migration.
-- ============================================================================

-- ------------------------------------------------- document numbering -------
create table if not exists document_sequences (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null check (doc_type in ('quotation','invoice','receipt','credit_note','proposal')),
  prefix      text not null,
  next_number int not null default 1,
  padding     int not null default 4,
  unique (org_id, doc_type)
);

-- Every issued document is snapshotted, so a reprint in 2030 shows what the
-- customer was actually sent, not today's edited record.
create table if not exists document_versions (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null,
  entity_id   uuid not null,
  number      text not null,
  version     int not null default 1,
  snapshot    jsonb not null default '{}',
  totals      jsonb not null default '{}',
  issued_by   uuid references users(id),
  issued_at   timestamptz not null default now(),
  unique (org_id, doc_type, entity_id, version)
);
create index if not exists document_versions_entity on document_versions (org_id, doc_type, entity_id, version desc);

-- ------------------------------------------------------------- quotations ----
alter table quotations add column if not exists number        text;
alter table quotations add column if not exists tax_mode      text not null default 'cgst_sgst';
alter table quotations add column if not exists place_of_supply text;
alter table quotations add column if not exists notes         text;
alter table quotations add column if not exists terms         text;

-- --------------------------------------------------------------- invoices ----
alter table invoices add column if not exists number         text;
alter table invoices add column if not exists subtotal       numeric(16,2) not null default 0;
alter table invoices add column if not exists tax_total      numeric(16,2) not null default 0;
alter table invoices add column if not exists discount_total numeric(16,2) not null default 0;
alter table invoices add column if not exists currency       char(3) not null default 'INR';
alter table invoices add column if not exists tax_mode       text not null default 'cgst_sgst';
alter table invoices add column if not exists place_of_supply text;
alter table invoices add column if not exists notes          text;
alter table invoices add column if not exists terms          text;
alter table invoices add column if not exists reminder_sent_at timestamptz;
alter table invoices add column if not exists credited_amount numeric(16,2) not null default 0;

-- A due date already exists; make overdue detectable without a scan of text.
create index if not exists invoices_due on invoices (org_id, due_date) where status <> 'paid';

-- --------------------------------------------------------------- payments ----
alter table payments add column if not exists invoice_id     uuid references invoices(id) on delete set null;
alter table payments add column if not exists currency       char(3) not null default 'INR';
alter table payments add column if not exists provider       text not null default 'manual';
alter table payments add column if not exists provider_ref   text;
alter table payments add column if not exists reference      text;
alter table payments add column if not exists notes          text;
alter table payments add column if not exists recorded_by    uuid references users(id);
alter table payments add column if not exists idempotency_key text;
create unique index if not exists payments_idem on payments (org_id, idempotency_key)
  where idempotency_key is not null;

create table if not exists payment_links (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete cascade,
  contact_id  uuid references contacts(id) on delete set null,
  token       text not null unique,
  amount      numeric(16,2) not null,
  currency    char(3) not null default 'INR',
  provider    text not null default 'manual',
  status      text not null default 'active' check (status in ('active','paid','expired','cancelled')),
  expires_at  timestamptz,
  paid_at     timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now()
);

create table if not exists refunds (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  payment_id  uuid not null references payments(id) on delete cascade,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'pending' check (status in ('pending','processed','failed')),
  provider_ref text,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists credit_notes (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete set null,
  contact_id  uuid references contacts(id) on delete set null,
  number      text not null,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'issued' check (status in ('issued','applied','void')),
  issued_at   timestamptz not null default now(),
  created_by  uuid references users(id)
);

-- --------------------------------------------------------------- webhooks ----
create table if not exists payment_events (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  event_id     text not null,
  type         text not null,
  payload      jsonb not null default '{}',
  status       text not null default 'received' check (status in ('received','processed','failed','ignored')),
  error        text,
  received_at  timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, event_id)
);

-- --------------------------------------------------------------------- RLS ---
do $$
declare spec record;
begin
  for spec in select * from (values
      ('document_sequences','quotation',true),
      ('document_versions','quotation',false),
      ('payment_links','payment',true),
      ('refunds','payment',true),
      ('credit_notes','invoice',true),
      ('payment_events','payment',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_sel', spec.tbl, spec.perm || '.read');
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- 006_auth_hardening.sql  (sha256:650abefbea29)
-- ---------------------------------------------------------------------------

-- ============================================================================
-- Anvaya CRM — 006 authentication and workspace hardening
--
-- Additive and idempotent. Nothing is dropped, nothing is truncated, no
-- customer row is deleted. Safe to run on a live database.
--
-- It fixes four concrete production faults found in the shipped code:
--
--   1. RLS was FORCED on every table. On Supabase the connecting role
--      ("postgres") is NOT a superuser, so FORCE RLS applied the policies to
--      the application's own system connection as well. With no policy on
--      sessions (by design) the auth layer could read zero rows, so every
--      login failed while the schema looked perfectly healthy. FORCE is
--      removed: RLS stays ENABLED, the owner bypasses it, and request
--      connections (SET ROLE authenticated / app_user) are still fully
--      constrained by policy.
--   2. users had no status column, so a suspended account could still sign in.
--   3. Invitations carried a token that was never stored, so anyone who knew
--      an invited email address could set its password. The hash and expiry
--      are now persisted and verified.
--   4. members.workspace_id could be null, leaving a signed-in user with no
--      workspace. Existing rows are repaired to the organisation's default
--      workspace (a pointer, not a data rewrite).
-- ============================================================================

-- ---------------------------------------------------- 1 · RLS enforcement ---
-- Enable everywhere, force nowhere.
do $$
declare t record;
begin
  for t in
    select c.relname
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
     where n.nspname = 'public' and c.relkind = 'r'
       and c.relname <> 'schema_migrations'
  loop
    execute format('alter table public.%I enable row level security', t.relname);
    execute format('alter table public.%I no force row level security', t.relname);
  end loop;
end $$;

-- Re-assert the grants the request role needs. Idempotent; the old bundle
-- granted to app_user only, which does nothing for a Supabase connection that
-- switches to `authenticated`.
do $$
begin
  begin
    execute 'grant usage on schema public to authenticated, app_user';
    execute 'grant usage on schema app to authenticated, app_user';
    execute 'grant select, insert, update, delete on all tables in schema public to authenticated, app_user';
    execute 'grant usage, select on all sequences in schema public to authenticated, app_user';
    execute 'grant execute on all functions in schema app to authenticated, app_user';
  exception when others then
    raise notice 'grant block skipped: %', sqlerrm;
  end;
end $$;

-- app.uid() is the name some tooling expects; keep it as an alias.
create or replace function app.uid() returns uuid
  language sql stable as $$
    select app.current_user()
$$;

-- The active workspace, for policies and diagnostics.
create or replace function app.current_workspace() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.workspace_id', true), '')::uuid
$$;

-- --------------------------------------------------------- 2 · accounts ---
alter table users add column if not exists status text not null default 'active';
alter table users add column if not exists suspended_at timestamptz;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'users_status_check') then
    begin
      alter table users add constraint users_status_check
        check (status in ('active', 'suspended', 'disabled'));
    exception when others then
      raise notice 'users_status_check not added: %', sqlerrm;
    end;
  end if;
end $$;

-- A case-insensitive unique index on email, so "Ada@x.com" and "ada@x.com"
-- cannot both register. The pre-existing unique constraint is case-sensitive.
-- Wrapped: if a live database already holds case-duplicates, the migration
-- reports it and continues instead of blocking every later migration.
do $$
begin
  begin
    create unique index if not exists users_email_lower_uniq on users (lower(email));
  exception when others then
    raise notice 'users_email_lower_uniq not created (existing case-duplicate emails): %', sqlerrm;
  end;
end $$;

-- ------------------------------------------------------ 3 · invitations ---
alter table members add column if not exists invite_token_hash text;
alter table members add column if not exists invite_expires_at timestamptz;
create unique index if not exists members_invite_token_uniq
  on members (invite_token_hash) where invite_token_hash is not null;

-- ----------------------------------------------------------- 4 · sessions ---
alter table sessions add column if not exists last_seen_at timestamptz;
create index if not exists sessions_user_active on sessions (user_id) where revoked_at is null;
create index if not exists sessions_expires on sessions (expires_at);

-- ------------------------------------------------- 5 · workspace pointers ---
alter table workspaces alter column settings set default '{}'::jsonb;

-- Point members that have no workspace at their organisation's default one.
-- This only fills a null pointer; it never overwrites an existing value.
update members m
   set workspace_id = (
     select w.id from workspaces w
      where w.org_id = m.org_id
      order by w.is_default desc, w.created_at
      limit 1)
 where m.workspace_id is null
   and exists (select 1 from workspaces w where w.org_id = m.org_id);

-- Every organisation needs a default workspace for the same reason.
insert into workspaces (org_id, name, slug, is_default)
select o.id, o.name, 'default', true
  from organisations o
 where o.deleted_at is null
   and not exists (select 1 from workspaces w where w.org_id = o.id)
on conflict (org_id, slug) do nothing;

-- --------------------------------------------------------- 6 · pipelines ---
create index if not exists stages_pipeline_position on stages (pipeline_id, position);
create index if not exists pipelines_org_default on pipelines (org_id, is_default);

-- ------------------------------------------------------- 7 · subscriptions ---
-- Non-unique on purpose: an existing database may already hold more than one
-- subscription row per organisation, and a unique index would fail the whole
-- migration for data the application can still handle.
create index if not exists subscriptions_org_idx on subscriptions (org_id);
