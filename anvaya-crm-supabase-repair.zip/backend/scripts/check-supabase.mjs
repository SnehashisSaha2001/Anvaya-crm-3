#!/usr/bin/env node
// ============================================================================
// Anvaya / Supabase connection doctor
//
//   DATABASE_URL="postgresql://postgres.<ref>:<pass>@aws-0-<region>.pooler.supabase.com:6543/postgres" \
//     node backend/scripts/check-supabase.mjs
//
// Eleven checks against the *canonical* schema (backend/db/migrations). Each
// failing check names the fix. Exit 0 means the backend can actually use that
// database: connected, schema complete, migrations recorded, RLS enforcing and
// the request role holding the grants it needs.
//
// It never prints the password or the full URL.
// ============================================================================

const GREEN = '\x1b[32m', RED = '\x1b[31m', DIM = '\x1b[2m', OFF = '\x1b[0m';
const ok = (m) => console.log(`${GREEN}PASS${OFF}  ${m}`);
const bad = (m, fix) => { console.log(`${RED}FAIL${OFF}  ${m}`); if (fix) console.log(`${DIM}      → ${fix}${OFF}`); };

const REQUIRED_TABLES = [
  'users', 'sessions', 'organisations', 'workspaces', 'members', 'roles',
  'pipelines', 'stages', 'subscriptions', 'notifications', 'audit_logs'
];
const REQUIRED_COLUMNS = {
  users: ['email', 'password_hash', 'full_name', 'status', 'is_platform_admin', 'mfa_enabled_at'],
  sessions: ['token_hash', 'expires_at', 'revoked_at', 'mfa_ok'],
  members: ['org_id', 'user_id', 'role_id', 'workspace_id', 'status'],
  workspaces: ['org_id', 'name', 'slug', 'is_default'],
  organisations: ['name', 'slug', 'status', 'settings']
};
const REQUIRED_POLICIES = ['leads_sel', 'organisations_sel', 'users_sel', 'members_sel'];
const EXPECTED_MIGRATION = '006_auth_hardening';

export async function runChecks(client, { log = console.log, role = process.env.DB_USER_ROLE || 'authenticated' } = {}) {
  const results = [];
  const record = (name, pass, detail, fix) => {
    results.push({ name, pass, detail, fix });
    if (pass) ok(name); else bad(name + (detail ? ` — ${detail}` : ''), fix);
  };

  /* 1 · a real connection ------------------------------------------------ */
  let version = null;
  try {
    const r = await client.query('select version() as v, current_database() as db, current_user as usr');
    version = r.rows[0].v.split(' ').slice(0, 2).join(' ');
    record('connected to PostgreSQL', true);
    log(`${DIM}      ${version} · database=${r.rows[0].db} · user=${r.rows[0].usr}${OFF}`);
  } catch (err) {
    record('connected to PostgreSQL', false, err.message,
      'Check DATABASE_URL. Use Supabase → Settings → Database → Connection string. On Vercel use the '
      + 'pooler host (aws-0-<region>.pooler.supabase.com:6543), not db.<ref>.supabase.co (IPv6-only). '
      + 'URL-encode the password (@ becomes %40).');
    return results;
  }

  /* 2 · the schema exists ------------------------------------------------ */
  let tableCount = 0;
  try {
    const t = await client.query(
      `select count(*)::int n from information_schema.tables where table_schema = 'public'`);
    tableCount = t.rows[0].n;
    const missing = [];
    for (const name of REQUIRED_TABLES) {
      const r = await client.query(`select to_regclass($1) as t`, [`public.${name}`]);
      if (!r.rows[0].t) missing.push(name);
    }
    record(`schema present (${tableCount} tables)`, missing.length === 0,
      missing.length ? `missing ${missing.join(', ')}` : null,
      'Run supabase/anvaya-supabase.sql in the Supabase SQL editor (or `npm run db:migrate`). '
      + 'The old supabase/00_*.sql…05_*.sql set is a different schema and must not be used.');
  } catch (err) {
    record('schema present', false, err.message, 'Run supabase/anvaya-supabase.sql.');
  }

  /* 3 · the columns the auth queries name -------------------------------- */
  try {
    const cols = await client.query(
      `select table_name, column_name from information_schema.columns where table_schema = 'public'`);
    const have = new Set(cols.rows.map((r) => `${r.table_name}.${r.column_name}`));
    const missing = [];
    for (const [table, columns] of Object.entries(REQUIRED_COLUMNS)) {
      for (const col of columns) if (!have.has(`${table}.${col}`)) missing.push(`${table}.${col}`);
    }
    record('required columns exist', missing.length === 0,
      missing.length ? `missing ${missing.join(', ')}` : null,
      'Apply the pending migrations: npm run db:migrate (006_auth_hardening adds users.status and the invite columns).');
  } catch (err) {
    record('required columns exist', false, err.message, null);
  }

  /* 4 · migrations recorded ---------------------------------------------- */
  try {
    const r = await client.query(`select to_regclass('public.schema_migrations') as t`);
    if (!r.rows[0].t) {
      record('migration version recorded', false, 'schema_migrations table is absent',
        'npm run db:migrate — it creates schema_migrations and records every file it applies.');
    } else {
      const m = await client.query(`select version from schema_migrations order by version`);
      const versions = m.rows.map((x) => x.version);
      const latest = versions[versions.length - 1] || null;
      record(`migration version recorded (${latest || 'none'})`, versions.includes(EXPECTED_MIGRATION),
        versions.includes(EXPECTED_MIGRATION) ? null : `expected ${EXPECTED_MIGRATION}`,
        'npm run db:migrate');
      log(`${DIM}      applied: ${versions.join(', ') || 'none'}${OFF}`);
    }
  } catch (err) {
    record('migration version recorded', false, err.message, 'npm run db:migrate');
  }

  /* 5 · row level security is enforcing ---------------------------------- */
  try {
    const p = await client.query(`select count(*)::int n from pg_policies where schemaname = 'public'`);
    const names = await client.query(`select policyname from pg_policies where schemaname = 'public'`);
    const have = new Set(names.rows.map((r) => r.policyname));
    const missing = REQUIRED_POLICIES.filter((x) => !have.has(x));
    record(`row-level security policies (${p.rows[0].n})`, p.rows[0].n >= 150 && missing.length === 0,
      missing.length ? `missing ${missing.join(', ')}` : p.rows[0].n < 150 ? 'fewer than expected' : null,
      'Run the RLS section of supabase/anvaya-supabase.sql (002_rls.sql).');
  } catch (err) {
    record('row-level security policies', false, err.message, null);
  }

  /* 6 · RLS enabled, not forced ------------------------------------------
     FORCE RLS applies the policies to the table owner as well. On Supabase the
     connecting role is not a superuser, so forcing it made the auth layer
     unable to read `sessions` (which deliberately has no policy) and every
     login failed. This check is the one that catches that. */
  try {
    const f = await client.query(
      `select count(*)::int as forced from pg_class c join pg_namespace n on n.oid = c.relnamespace
        where n.nspname = 'public' and c.relkind = 'r' and c.relforcerowsecurity`);
    record('RLS not forced on owner (system connection can read)', f.rows[0].forced === 0,
      f.rows[0].forced ? `${f.rows[0].forced} table(s) use FORCE ROW LEVEL SECURITY` : null,
      'Apply 006_auth_hardening.sql: it sets ENABLE without FORCE, so the owner bypasses RLS and '
      + 'request roles are still constrained. Forcing it breaks login.');
  } catch (err) {
    record('RLS not forced on owner', false, err.message, null);
  }

  /* 7 · identity helpers ------------------------------------------------- */
  try {
    const f = await client.query(
      `select proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'app' and proname in ('current_org','current_user','current_workspace','has_perm','perms')`);
    const found = f.rows.map((r) => r.proname);
    const missing = ['current_org', 'current_user', 'has_perm'].filter((x) => !found.includes(x));
    record('identity helpers exist', missing.length === 0,
      missing.length ? `missing ${missing.join(', ')}` : null,
      'Apply 001_schema.sql and 006_auth_hardening.sql.');
  } catch (err) {
    record('identity helpers exist', false, err.message, null);
  }

  /* 8 · the request role holds its grants -------------------------------- */
  try {
    const g = await client.query(
      `select has_table_privilege($1,'public.leads','SELECT') as sel,
              has_table_privilege($1,'public.leads','INSERT') as ins`, [role]);
    const { sel, ins } = g.rows[0];
    record(`${role} role has table privileges`, sel && ins,
      !sel ? 'no SELECT grant' : !ins ? 'no INSERT grant' : null,
      'Apply 006_auth_hardening.sql: it grants SELECT/INSERT/UPDATE/DELETE to authenticated and app_user. '
      + 'Grants to app_user alone do nothing for a Supabase connection that switches to authenticated.');
  } catch (err) {
    record(`${role} role has table privileges`, false, err.message, null);
  }

  /* 9 · the auth tables are readable by the system connection ------------ */
  let users = 0, orgs = 0;
  try {
    const u = await client.query(`select count(*)::int n from users`);
    const s = await client.query(`select count(*)::int n from sessions`);
    const o = await client.query(`select count(*)::int n from organisations`);
    users = u.rows[0].n; orgs = o.rows[0].n;
    record(`auth tables readable (${users} user(s), ${s.rows[0].n} session(s))`, true);
  } catch (err) {
    record('auth tables readable', false, err.message,
      'If this fails with permission denied, RLS is forced or grants are missing — see checks 6 and 8.');
  }

  /* 10 · a workspace to sign into --------------------------------------- */
  try {
    const w = await client.query(
      `select (select count(*) from workspaces)::int as ws,
              (select count(*) from members where status='active')::int as active_members,
              (select count(*) from members where status='active' and workspace_id is null)::int as orphans`);
    const { ws, active_members: members, orphans } = w.rows[0];
    record(`workspace data present (${orgs} org, ${ws} workspace, ${members} active member(s))`,
      orgs > 0 ? ws > 0 && orphans === 0 : true,
      orphans ? `${orphans} active member(s) without a workspace` : orgs === 0 ? 'no organisation yet (register through the app)' : null,
      'Apply 006_auth_hardening.sql — it points workspace-less members at their organisation default.');
  } catch (err) {
    record('workspace data present', false, err.message, null);
  }

  /* 11 · a real user sees exactly their own workspace -------------------- */
  if (users > 0) {
    try {
      const who = await client.query(`select user_id, org_id from members where status = 'active' limit 1`);
      if (who.rows.length) {
        await client.query('begin');
        await client.query(`set local role ${role}`);
        await client.query(`select set_config('app.org_id', $1, true)`, [who.rows[0].org_id]);
        await client.query(`select set_config('app.user_id', $1, true)`, [who.rows[0].user_id]);
        await client.query(`select set_config('app.perms', '*', true)`);
        const own = await client.query(`select count(*)::int n from organisations`);
        const leads = await client.query(`select count(*)::int n from leads`);
        await client.query('rollback');
        record('a signed-in user sees exactly their own organisation through RLS', own.rows[0].n === 1,
          own.rows[0].n === 0 ? 'saw no organisation — identity is not resolving'
            : own.rows[0].n > 1 ? `saw ${own.rows[0].n} organisations — tenant isolation is broken` : null,
          'Check that 002_rls.sql applied and that the request sets app.org_id/app.user_id.');
        log(`${DIM}      that user sees ${leads.rows[0].n} lead(s)${OFF}`);
      }
    } catch (err) {
      await client.query('rollback').catch(() => {});
      record('a signed-in user sees exactly their own organisation through RLS', false, err.message,
        'The request role must be able to SET ROLE and read app.current_org().');
    }
  }

  const failed = results.filter((r) => !r.pass).length;
  log('');
  log(failed === 0
    ? `${GREEN}All ${results.length} checks passed — this backend can use that Supabase database.${OFF}`
    : `${RED}${failed} of ${results.length} checks failed.${OFF} Fix those, then run this again.`);
  return results;
}

/* --------------------------------------------------------------- CLI ------ */
if (import.meta.url === `file://${process.argv[1]}`) {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.log(`${RED}DATABASE_URL is not set.${OFF}`);
    console.log('Supabase → Settings → Database → Connection string → URI, then:');
    console.log('  DATABASE_URL="postgresql://postgres.<ref>:<pass>@aws-0-<region>.pooler.supabase.com:6543/postgres" \\');
    console.log('    node backend/scripts/check-supabase.mjs');
    process.exit(1);
  }

  const { initDb, verifyConnection, driver, closeDb, describeDatabaseUrl, explainDbError } = await import('../src/db.js');
  try {
    await initDb();
  } catch (err) {
    const info = explainDbError(err);
    console.log(`${RED}Could not connect (${info.code}/${info.kind}):${OFF} ${info.message}`);
    process.exit(1);
  }

  const target = describeDatabaseUrl();
  console.log(`\nTarget: ${target.host}:${target.port}/${target.database} · pooler=${target.pooler} · direct=${target.direct}\n`);

  const check = await verifyConnection();
  if (!check.ok) {
    console.log(`${RED}Verification query failed:${OFF} ${check.error.message}`);
    await closeDb();
    process.exit(1);
  }

  const db = (await import('../src/db.js')).db();
  const results = await runChecks(db);
  console.log(`\nDriver in use: ${driver()} (expected: pg)`);
  if (driver() !== 'pg') {
    console.log(`${RED}FAIL${OFF}  the active driver is not pg — this is not a Supabase connection`);
  }
  await closeDb();
  process.exit(results.some((r) => !r.pass) || driver() !== 'pg' ? 1 : 0);
}
