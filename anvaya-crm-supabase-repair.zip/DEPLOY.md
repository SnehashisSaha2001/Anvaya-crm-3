# Deployment — Anvaya CRM on Vercel + Supabase

Anvaya CRM runs as a static frontend served from the Vercel CDN plus one
serverless function (`api/index.js`) that talks to Supabase PostgreSQL.

There is **one** database in production: Supabase. There is no local fallback,
no browser database and no simulated login. If the database is unreachable the
API answers HTTP 503 with a sentence a user can act on, and the UI says so.

---

## 1. Supabase

1. Create (or open) the project. Note the **project ref** — the string in
   `https://<ref>.supabase.co`.
2. **SQL Editor → New query → paste all of `supabase/anvaya-supabase.sql` → Run.**
   That file is generated from `backend/db/migrations/*.sql` (the canonical
   schema) and is idempotent: running it twice is harmless.
   Do **not** use the files in `supabase/legacy/` — that is a different schema.
3. **Settings → Database → Connection string → URI**, and pick the right mode:

   | Where the app runs | Endpoint | Port |
   | --- | --- | --- |
   | Vercel / Lambda (serverless) | `aws-0-<region>.pooler.supabase.com` | **6543** (transaction) |
   | VM / Docker / Railway / Render | `aws-0-<region>.pooler.supabase.com` | 5432 (session) |

   The direct host `db.<ref>.supabase.co:5432` is **IPv6-only**. From Vercel it
   fails intermittently with `ENETUNREACH`/`ETIMEDOUT`, which is one of the
   causes of the random connection failures this project had.

4. URL-encode the password in the URL: `@` → `%40`, `#` → `%23`, `/` → `%2F`,
   `:` → `%3A`.

5. Nothing else is needed — no service-role key, no anon key, no Supabase Auth
   configuration. Anvaya authenticates users itself (scrypt + database
   sessions), so there is exactly one identity system.

---

## 2. Vercel

Project → **Settings → Environment Variables** (Production *and* Preview):

| Variable | Value | Required |
| --- | --- | --- |
| `DATABASE_URL` | the pooler URI from step 1.3 (port 6543) | **yes** |
| `NODE_ENV` | `production` | **yes** |
| `DB_USER_ROLE` | `authenticated` | **yes** |
| `DB_POOL_SIZE` | `3` (connections per instance) | recommended |
| `ENCRYPTION_KEY` | 32+ random characters (`openssl rand -base64 48`) | recommended |
| `SESSION_DAYS` | `7` | optional |
| `DIAGNOSTICS_TOKEN` | a long random string, if you want deep diagnostics without a platform admin | optional |
| `CORS_ORIGIN` | only if the app is served from a different origin | optional |

Do **not** create `VITE_*`, `NEXT_PUBLIC_*` or `PUBLIC_*` variables containing
`DATABASE_URL`, the password, `ENCRYPTION_KEY` or any key: everything with those
prefixes is compiled into the browser bundle. `scripts/verify-env.js` fails the
build if it finds one.

A local `.env` file is **not** read on Vercel. `vercel.json` already sets:

* `buildCommand: npm run build` (static bundle only — it does not touch the database)
* `outputDirectory: dist`
* `/api/(.*)` → `/api/index.js`, everything else → `/index.html`
* `maxDuration: 30` for the function

**`.vercelignore` must never list `api/` or `backend/`.** It did before this
repair, which removed the function and all its imports from the upload: every
`/api/*` request 404'd and the browser received the HTML shell instead of JSON.

---

## 3. Migrations

Run once, from your machine or CI, with the production `DATABASE_URL`:

```bash
npm ci
DATABASE_URL="postgresql://…pooler…:6543/postgres" npm run db:migrate
```

`db:migrate` connects, applies every pending file in `backend/db/migrations`,
records it in `schema_migrations` (version + checksum, under an advisory lock),
then re-verifies the schema and **exits non-zero if anything is missing**. It
never drops a table and never resets the database.

Other useful commands:

```bash
npm run db:check    # report migration state, change nothing (exit 2 = pending)
npm run db:doctor   # 11-point connectivity/schema/RLS/grant diagnosis
npm run db:sql      # regenerate supabase/anvaya-supabase.sql from the migrations
```

Migrations do **not** run on every API request. If you want them at cold start,
set `MIGRATE_ON_BOOT=1` — but the explicit command above is the supported path.

---

## 4. First run

1. Open the deployment. The connection chip should read **Live data**.
2. `GET /api/health` returns `status: "ok"` and `mode: "server"`.
3. Register a real account on the registration page. That creates the user,
   organisation, workspace, owner membership, role set, default pipeline and
   stages, trial subscription and a session — in one transaction.
4. `GET /api/auth/me` returns the same organisation and workspace.

Nothing is seeded automatically. There is no demo account in production.

---

## 5. Operating it

| Symptom | Check |
| --- | --- |
| Chip says **Service unavailable**, API returns 503 | `curl -s https://<app>/api/health \| jq .connectionStatus` — the code tells you which class of failure it is |
| `DB_CONFIG_MISSING` | `DATABASE_URL` is not set for that environment |
| `28P01` | wrong password (or unencoded characters) |
| `ENOTFOUND` | wrong project ref, or the project is paused |
| `ETIMEDOUT` / `ENETUNREACH` | you are on the direct host from Vercel — switch to the pooler |
| `53300` / "too many clients" | lower `DB_POOL_SIZE`, use the pooler, or upgrade the Supabase compute |
| `MIGRATIONS_NOT_APPLIED` | `npm run db:migrate` |
| Login works, `/api/auth/me` is 401 | check the cookie is being stored (https + `Secure`) and that the user has an active membership |

Deep diagnostics: `GET /api/health/diagnostics` as a platform admin, or with
`x-diag-token: $DIAGNOSTICS_TOKEN`.

---

## 6. Local development

```bash
cp .env.example .env      # then fill DATABASE_URL (optional locally)
npm ci
npm run dev               # http://localhost:3000
```

Without `DATABASE_URL`, a laptop may use the embedded PGlite engine
(`DB_ALLOW_PGLITE=1`, data in `backend/.data/`). That is refused in production
and on Vercel — the API exits with `DB_CONFIG_MISSING` instead.

To load the demo workspace locally: `SEED_DEMO=1 npm run dev`.

---

## 7. Other hosts, and what Google AI Studio can and cannot do

The repository installs and runs with a single manifest at the root:

```
package.json          one manifest, one lockfile (package-lock.json)
backend/package.json  a four-line ESM marker ("type": "module") — no dependencies
```

There is deliberately **no second dependency list and no second lockfile**. A
stale `bun.lock` and a `backend/package-lock.json` used to sit next to the root
manifest; any platform that picked one of those up installed a different tree
from the one the code was written against, which is the usual cause of
*"dependency installation failed"*.

The install is deliberately boring: 5 runtime dependencies, **no
devDependencies**, and **no package in the tree runs an install script**
(`npm ci`, `npm install`, `npm ci --omit=dev` and a lockfile-free
`npm install --omit=dev` were all verified).

```bash
npm ci            # or: npm install
npm run dev       # serves the app and the API on http://localhost:3000
```

### Google AI Studio

AI Studio's app builder runs **Vite-style web apps**: it installs dependencies,
runs a build, and serves a static bundle with a dev server. Anvaya's production
mode is a Node server plus a PostgreSQL connection, which that runtime does not
provide — so even with a perfect `package.json`, AI Studio cannot host the API
that login and workspace creation need. It has no way to run
`backend/src/server.js` or to hold a `DATABASE_URL`.

What works:

* **Editing / browsing the code in AI Studio:** fine. The manifests are now
  unambiguous, so the install step succeeds.
* **Running it there without Supabase:** set `DB_ALLOW_PGLITE=1` and AI Studio's
  dev runner can serve the app on the embedded database. That is a development
  database on their container's disk: no Supabase connection, data lost when the
  container is recycled.
* **Actually connecting to Supabase:** deploy to Vercel (sections 2–5). That is
  the supported path and the only one that has been verified end to end.

If AI Studio still reports a dependency failure after this version, the message
it shows is generic; the useful check is to run `npm ci` in the repository root
and read the last 20 lines. There is no native module, no install script and no
private registry involved, so that command only fails for network or Node-version
reasons — `engines` now allows Node 18 or newer.

---

## 8. Static-only / single-file edition

`tools/build-single-file.py` produces `anvaya-crm.html`, one file with no
server. It is a **demo**: it flips `meta[name="anvaya-demo"]` to `true`, which is
the only thing that lets `engine.js` answer authentication routes. The hosted
build keeps that flag at `false`, so it can never fall back to simulated logins.
