# Anvaya CRM — backend

Express + PostgreSQL (PGlite, in-process). Multi-tenant with row level security, session
auth, a workflow engine, an audit trail and a copilot.

Dependencies are installed once at the repository root — `backend/package.json`
here exists only to mark this folder as ESM. Run everything from the root:

```bash
npm ci
npm run db:migrate   # canonical schema, verified
npm run dev          # http://localhost:3000
npm test             # 121 checks
```

`SEED_DEMO=1 npm run dev` creates the demo workspace (development only; there is
no demo account in production).

## Layout

```
src/server.js       boot: migrate, listen
src/app.js          routes
src/db.js           connection, transactions, asUser (RLS context)
src/auth.js         scrypt passwords, hashed session tokens, request context
src/permissions.js  9 role templates → permission keys
src/resources.js    generic CRUD with column allow-lists
src/workflows.js    trigger → conditions → actions → approval → logs
src/intelligence.js analytics + copilot
src/audit.js        append-only audit trail
db/migrations/      001_schema.sql (38 tables), 002_rls.sql (134 policies)
db/seed.js          demo workspace
```

## Notes

- **Paths are anchored to the package**, so `npm start` works from `backend/` or from the
  repo root.
- **The database is embedded**, so this needs a writable disk. It is not serverless —
  deploy it to Railway, Render, Fly.io or a VM. See `../DEPLOY.md`.
- **`GET /api/health` returns `{ "mode": "server" }`**, which is how the web app decides
  to use the API instead of browser storage.
- **`CORS_ORIGIN`** lets a static deployment on another domain call this API.

## Environment

```
PORT=4000
DB_PATH=./.data/anvaya      # writable, persisted
CORS_ORIGIN=                # exact origin of the static site, if it is elsewhere
AI_API_KEY=                 # optional; without it the copilot answers from SQL
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=gpt-4o-mini
```
