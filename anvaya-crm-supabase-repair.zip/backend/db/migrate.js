// Migration runner.
//
//   node backend/db/migrate.js            apply pending migrations, verify, exit
//   node backend/db/migrate.js --check    report state, change nothing
//
// Exit code 0 only when the database is reachable, every migration is applied
// and the schema verifies. A failure exits non-zero — it is never swallowed
// with `|| true`, and it never silently degrades to a local database.

import { initDb, migrate, verifyConnection, migrationStatus, explainDbError, dbStatus, closeDb } from '../src/db.js';
import { getHealth } from '../src/health.js';

const checkOnly = process.argv.includes('--check');

async function main() {
  try {
    await initDb();
  } catch (err) {
    const info = explainDbError(err);
    console.error(`\n[migrate] cannot connect (${info.code}/${info.kind})`);
    console.error(`[migrate] ${info.message}`);
    const s = dbStatus();
    console.error(`[migrate] target: provider=${s.provider} host=${s.host} port=${s.port} database=${s.database} pooler=${s.pooler}`);
    process.exit(1);
  }

  const check = await verifyConnection();
  if (!check.ok) {
    console.error(`\n[migrate] connection verification failed: ${check.error.code} — ${check.error.message}`);
    process.exit(1);
  }
  console.log(`[migrate] connected to ${check.database} as ${check.user} (${check.latencyMs}ms, ${check.version})`);

  if (checkOnly) {
    const status = await migrationStatus();
    console.log(`[migrate] state=${status.state} applied=${status.applied} pending=${status.pending} latest=${status.latest}`);
    await closeDb();
    process.exit(status.state === 'up-to-date' ? 0 : 2);
  }

  try {
    const out = await migrate({ log: (m) => console.log(m) });
    console.log(`[migrate] done: ${out.applied.length} applied, ${out.skipped.length} already present`);
  } catch (err) {
    console.error(`\n[migrate] FAILED: ${err.message}`);
    await closeDb();
    process.exit(1);
  }

  // Verify the result instead of trusting the loop above.
  const health = await getHealth();
  const problems = [];
  if (health.connectionStatus.state !== 'connected') problems.push('connection');
  if (health.schemaStatus.state !== 'ok') {
    problems.push(`schema (missing tables: ${health.schemaStatus.missingTables.join(', ') || 'none'}; `
      + `missing columns: ${health.schemaStatus.missingColumns.slice(0, 8).join(', ') || 'none'})`);
  }
  if (health.migrationStatus.state !== 'up-to-date') problems.push(`migrations (${health.migrationStatus.state})`);
  if (health.rlsStatus.state !== 'ok') problems.push(`rls (missing: ${health.rlsStatus.missingPolicies.join(', ')})`);
  if (health.permissionsStatus.state === 'incomplete') problems.push(`grants (role ${health.permissionsStatus.role})`);

  console.log(`[migrate] schema: ${health.schemaStatus.tables} tables · `
    + `policies: ${health.rlsStatus.policies} · migrations: ${health.migrationStatus.latest}`);

  if (problems.length) {
    console.error(`\n[migrate] VERIFICATION FAILED: ${problems.join('; ')}`);
    await closeDb();
    process.exit(1);
  }

  console.log('[migrate] verified: the database matches the code.');
  await closeDb();
  process.exit(0);
}

main().catch(async (err) => {
  console.error('[migrate] unexpected failure:', err?.message);
  try { await closeDb(); } catch { /* ignore */ }
  process.exit(1);
});
