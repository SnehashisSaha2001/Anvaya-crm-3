-- ============================================================================
-- Anvaya CRM — 003 growth features
-- Capture (web forms, inbound email), API access, outbound webhooks,
-- integration state, saved views and exchange rates.
-- ============================================================================

-- ------------------------------------------------------------- web forms ---
create table if not exists web_forms (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  slug           text not null unique,
  headline       text default 'Talk to us',
  description    text,
  fields         jsonb not null default '["name","email","phone","company_name","message"]',
  required       jsonb not null default '["name"]',
  success_message text not null default 'Thank you — we will be in touch shortly.',
  redirect_url   text,
  default_source text not null default 'web_form',
  owner_id       uuid references members(id) on delete set null,
  is_active      boolean not null default true,
  submission_count int not null default 0,
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists form_submissions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  form_id      uuid not null references web_forms(id) on delete cascade,
  lead_id      uuid references leads(id) on delete set null,
  payload      jsonb not null default '{}',
  ip           text,
  user_agent   text,
  is_duplicate boolean not null default false,
  created_at   timestamptz not null default now()
);
create index if not exists form_submissions_form on form_submissions (form_id, created_at desc);

-- -------------------------------------------------------------- api keys ---
create table if not exists api_keys (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  prefix      text not null,
  key_hash    text not null unique,
  scopes      text[] not null default '{"read"}',
  last_used_at timestamptz,
  request_count int not null default 0,
  created_by  uuid references users(id),
  revoked_at  timestamptz,
  created_at  timestamptz not null default now()
);
create index if not exists api_keys_org on api_keys (org_id) where revoked_at is null;

-- -------------------------------------------------------------- webhooks ---
create table if not exists webhooks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  url          text not null,
  description  text,
  secret       text not null,
  events       text[] not null default '{}',
  is_active    boolean not null default true,
  last_status  text,
  last_error   text,
  last_fired_at timestamptz,
  failure_count int not null default 0,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists webhook_deliveries (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  webhook_id    uuid not null references webhooks(id) on delete cascade,
  event         text not null,
  payload       jsonb not null default '{}',
  status        text not null default 'pending' check (status in ('pending','delivered','failed')),
  response_code int,
  error         text,
  attempts      int not null default 1,
  created_at    timestamptz not null default now()
);
create index if not exists webhook_deliveries_wh on webhook_deliveries (webhook_id, created_at desc);

-- ----------------------------------------------------- integration state ---
alter table integrations add column if not exists tokens       text;   -- AES-256-GCM, never returned by the API
alter table integrations add column if not exists account      text;   -- provider account label, e.g. the mailbox
alter table integrations add column if not exists cursor       text;   -- delta sync marker
alter table integrations add column if not exists sync_state   jsonb not null default '{}';
alter table integrations add column if not exists last_synced_at timestamptz;

-- ----------------------------------------------------------- saved views ---
create table if not exists saved_views (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid references users(id) on delete cascade,
  resource   text not null,
  name       text not null,
  filters    jsonb not null default '{}',
  sort       text,
  is_shared  boolean not null default false,
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------- exchange rates ---
create table if not exists exchange_rates (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  currency    char(3) not null,
  rate_to_org numeric(16,6) not null,
  as_of       date not null default current_date,
  unique (org_id, currency, as_of)
);

-- ------------------------------------------------------------------ RLS ----
do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('web_forms','settings',true),
      ('form_submissions','settings',false),
      ('api_keys','settings',true),
      ('webhooks','settings',true),
      ('webhook_deliveries','settings',false),
      ('saved_views','lead',true),
      ('exchange_rates','settings',true)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- api keys are read by the auth layer on the system connection, so the
-- application role only ever sees its own organisation's keys.
