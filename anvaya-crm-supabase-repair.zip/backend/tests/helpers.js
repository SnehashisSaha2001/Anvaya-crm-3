// Test helpers: boot the real app on an ephemeral port against an in-memory
// Postgres (PGlite), with a tiny cookie-aware fetch client.

process.env.DB_MEMORY = '1';
process.env.NODE_ENV = 'test';

import { once } from 'node:events';
import { initDb, migrate } from '../src/db.js';
import { createApp } from '../src/app.js';

let server;
let base;

export async function boot() {
  if (server) return base;
  await initDb();
  await migrate();
  const app = createApp();
  server = app.listen(0);
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}`;
  return base;
}

export async function shutdown() {
  if (server) await new Promise(r => server.close(r));
  server = null;
}

function mergeCookies(jar, setCookies) {
  for (const raw of setCookies) {
    const [pair] = raw.split(';');
    const eq = pair.indexOf('=');
    const name = pair.slice(0, eq);
    const value = pair.slice(eq + 1);
    if (!value) delete jar[name];
    else jar[name] = value;
  }
  return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
}

/** Returns a client with its own cookie jar. */
export function client() {
  const jar = {};
  const call = async (path, opts = {}) => {
    const headers = { ...(opts.body ? { 'content-type': 'application/json' } : {}), ...(opts.headers || {}) };
    const cookie = mergeCookies(jar, []);
    if (cookie) headers.cookie = cookie;
    const res = await fetch(`${base}${path}`, {
      method: opts.method || (opts.body ? 'POST' : 'GET'),
      headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const setCookies = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    if (setCookies.length) mergeCookies(jar, setCookies);
    const text = await res.text();
    let body;
    try { body = text ? JSON.parse(text) : null; } catch { body = text; }
    return { status: res.status, body, headers: res.headers };
  };
  call.jar = jar;
  return call;
}

let counter = 0;
export function uniqueEmail(prefix = 'user') {
  counter += 1;
  return `${prefix}.${Date.now()}.${counter}@example.test`;
}

/** Register a fresh organisation and return a logged-in client. */
export async function registerOrg({ name = 'Test Co', email, password = 'TestPassword123' } = {}) {
  const api = client();
  const res = await api('/api/auth/register', {
    body: { email: email || uniqueEmail('owner'), password, fullName: 'Test Owner', orgName: name }
  });
  if (res.status !== 201) throw new Error(`register failed: ${res.status} ${JSON.stringify(res.body)}`);
  return { api, email: email || res.body.user.email, password, org: res.body.org };
}
