/* ============================================================================
   Anvaya CRM — data bridge
   ---------------------------------------------------------------------------
   One function the whole UI calls: AnvayaData.api(path, opts).

   Four states, and local storage means something different in each:

     server       A real API answered with mode:'server', which it only sets
                  after a real query against the real database. The server is
                  the source of truth. Every read is cached so the app still
                  opens with no network.

     offline      A server was reached before, but is not now. Reads come from
                  the cache; writes queue in the outbox and replay when the
                  connection returns. Local storage is a backup, never a rival
                  database.

     unavailable  The server answered, but its database is down (HTTP 503).
                  Nothing is cached, nothing is queued, no fake account is
                  created: authentication needs the real database.

     standalone   No server has ever been configured and the build is
                  explicitly a demo (meta name="anvaya-demo" content="true").
                  engine.js serves the routes from this browser.

   Authentication is never served from local state. There is no code path in
   which a wrong password, a failed database or a missing server produces a
   logged-in user.
   ========================================================================== */
(function () {
  'use strict';

  const meta = document.querySelector('meta[name="anvaya-api"]');
  const BASE = (meta && meta.content ? meta.content : '').replace(/\/$/, '');

  /* ------------------------------------------------------- demo gating --- */
  // The demo engine (engine.js) simulates login and workspace creation. It is
  // allowed only when the page says so explicitly AND it is running from a
  // local origin. A production build has meta anvaya-demo="false" and can
  // never fall into it, however the network behaves.
  const demoMeta = document.querySelector('meta[name="anvaya-demo"]');
  const host = location.hostname;
  const isLocalOrigin = location.protocol === 'file:'
    || host === 'localhost' || host === '127.0.0.1' || host === '::1' || host === '';
  const DEMO_REQUESTED = demoMeta ? demoMeta.content === 'true' : false;
  const DEMO_ENABLED = DEMO_REQUESTED && (isLocalOrigin || window.ANVAYA_DEMO_ALLOW_REMOTE === true);
  window.ANVAYA_DEMO_ENABLED = DEMO_ENABLED;

  const SERVICE_UNAVAILABLE = 'Anvaya CRM is temporarily unable to connect to its database. Please try again.';

  const off = window.AnvayaOffline.create({ storage: window.localStorage });
  const listeners = new Set();

  // The tables that live in the local database and sync two-way. Everything
  // else (auth, dashboard, AI, finance) stays a plain request.
  const SYNC_TABLES = ['leads', 'contacts', 'companies', 'deals', 'tasks', 'activities',
    'tickets', 'products', 'quotations', 'invoices', 'projects', 'campaigns'];
  let db = null;          // local IndexedDB
  let sync = null;        // the engine

  function notify() { for (const fn of listeners) { try { fn(D.status()); } catch { /* ignore */ } } }

  function netError(err) {
    // A TypeError from fetch means the request never reached the server.
    return err instanceof TypeError || (err && err.name === 'AbortError');
  }

  const AUTH_PATH = /^\/api\/auth\//;
  const HEALTH_PATH = /^\/api\/health/;

  function serviceUnavailable(code) {
    const err = new Error(SERVICE_UNAVAILABLE);
    err.status = 503;
    err.code = code || 'DB_UNAVAILABLE';
    err.serviceUnavailable = true;
    return err;
  }

  /* --------------------------------------------------- local table reads -- */
  const SYNC_PATH = /^\/api\/([a-z-]+)(?:\/([\w-]+))?(?:\?(.*))?$/;

  function localQuery(rows, params) {
    let out = rows.filter(r => !r._deleted);
    const q = params.get('q');
    if (q) {
      const needle = q.toLowerCase();
      out = out.filter(r => JSON.stringify(r).toLowerCase().includes(needle));
    }
    for (const [k, v] of params.entries()) {
      if (['q', 'limit', 'offset', 'sort', 'updated_since'].includes(k)) continue;
      if (!v || v === 'all') continue;
      out = out.filter(r => String(r[k] ?? '') === v);
    }
    out.sort((a, b) => String(b.updated_at || '').localeCompare(String(a.updated_at || '')));
    const total = out.length;
    const limit = Math.min(Number(params.get('limit')) || 50, 200);
    const offset = Number(params.get('offset')) || 0;
    return { data: out.slice(offset, offset + limit).map(stripMeta), total, limit, offset };
  }

  function stripMeta(row) {
    const out = {};
    for (const [k, v] of Object.entries(row)) {
      if (!['_dirty', '_base', '_deleted', '_queuedAt'].includes(k)) out[k] = v;
    }
    return out;
  }

  async function rawCall(path, opts = {}) {
    const res = await fetch(`${BASE}${path}`, {
      method: opts.method || (opts.body ? 'POST' : 'GET'),
      headers: { ...(opts.body ? { 'content-type': 'application/json' } : {}), ...(opts.headers || {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      credentials: 'same-origin',
      cache: 'no-store'
    });
    const text = await res.text();
    let body = null;
    try { body = text ? JSON.parse(text) : null; } catch { body = text; }

    if (res.status === 503) {
      // The server is up; its database is not. Say so, and do not pretend.
      D.mode = 'unavailable';
      notify();
      const err = serviceUnavailable(body && body.code);
      err.body = body;
      throw err;
    }
    if (!res.ok) {
      const err = new Error((body && body.error) || `Request failed (${res.status})`);
      err.status = res.status;
      err.body = body;
      err.code = body && body.code;
      throw err;
    }
    return body;
  }

  /**
   * Ask the server whether it can serve. Retries, because a serverless cold
   * start legitimately takes a few seconds and the old 2.5s single-shot probe
   * is what pushed the app into its demo fallback.
   */
  async function probe({ attempts = 3, timeoutMs = 12000 } = {}) {
    let sawResponse = false;
    for (let i = 0; i < attempts; i += 1) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      try {
        const res = await fetch(`${BASE}/api/health`, {
          signal: ctrl.signal, cache: 'no-store', credentials: 'same-origin'
        });
        clearTimeout(timer);
        sawResponse = true;
        const body = await res.json().catch(() => null);
        if (res.ok && body && body.mode === 'server') return { state: 'server', body };
        // A response that is not "server" means the API is up but its database
        // is not. That is not a network problem and retrying will not fix it
        // immediately, so stop here and report it honestly.
        if (res.status === 503) return { state: 'unavailable', body };
        if (body && body.status === 'degraded') return { state: 'server', body };
      } catch (err) {
        clearTimeout(timer);
      }
      if (i < attempts - 1) await new Promise(r => setTimeout(r, 400 * (i + 1)));
    }
    return { state: sawResponse ? 'unavailable' : 'unreachable' };
  }

  const D = {
    mode: 'checking',
    base: BASE,
    demoEnabled: DEMO_ENABLED,

    /** Probe once at boot and decide what local storage is for. */
    async init() {
      const uncertain = off.uncertain();
      const result = await probe();

      if (result.state === 'server') {
        D.mode = 'server';
        off.rememberMode('server');
        await D.openLocal();
        notify();
        D.flush().catch(() => {});
        D.startSync();
        return D.mode;
      }

      if (result.state === 'unavailable') {
        // API reachable, database not. Keep the last known mode so a retry can
        // restore it, but never show data as if it were live.
        D.mode = 'unavailable';
        off.rememberMode('server');
        if (uncertain.length) notify();
        D.scheduleRetry();
        return D.mode;
      }

      // Nothing answered at all.
      if (DEMO_ENABLED) {
        D.mode = 'standalone';
        if (uncertain.length) notify();
        return D.mode;
      }
      D.mode = off.rememberedMode() === 'server' ? 'offline' : 'unavailable';
      if (D.mode === 'offline') await D.openLocal();
      if (uncertain.length) notify();
      D.scheduleRetry();
      return D.mode;
    },

    /** Re-probe while offline so the app notices when the network returns. */
    scheduleRetry() {
      if (D._retry) return;
      D._retry = setInterval(async () => {
        const result = await probe({ attempts: 1, timeoutMs: 8000 });
        if (result.state === 'server') {
          clearInterval(D._retry); D._retry = null;
          D.mode = 'server';
          off.rememberMode('server');
          notify();
          await D.flush();
        } else if (result.state === 'unavailable' && D.mode !== 'unavailable') {
          D.mode = 'unavailable';
          notify();
        }
      }, 15000);
    },

    /** Open IndexedDB and attach the sync engine. Safe to call twice. */
    async openLocal() {
      if (db) return db;
      try {
        db = await window.AnvayaDb.open(SYNC_TABLES);
      } catch {
        db = window.AnvayaDb.memory();      // private mode: keep working, in memory
      }
      sync = window.AnvayaSync.create({
        store: db,
        api: (path, opts) => rawCall(path, opts),
        tables: SYNC_TABLES,
        onEvent: (e) => { if (e.type === 'done' || e.type === 'pull') notify(); }
      });
      return db;
    },

    /** Push what is queued, then pull what changed elsewhere. */
    async startSync() {
      if (!sync || D.mode !== 'server') return null;
      try {
        const out = await sync.syncAll();
        notify();
        return out;
      } catch { return null; }
    },

    async conflicts() { return db ? db.conflictList() : []; },

    status() {
      return {
        mode: D.mode,
        pending: D._pending || 0,
        uncertain: off.uncertain().length,
        conflicts: D._conflicts || 0
      };
    },

    async refreshCounts() {
      if (!db) return;
      try {
        D._pending = (await db.outboxList()).length;
        D._conflicts = (await db.conflictList()).length;
        notify();
      } catch { /* ignore */ }
    },

    onStatus(fn) { listeners.add(fn); return () => listeners.delete(fn); },

    async api(path, opts = {}) {
      const method = opts.method || (opts.body ? 'POST' : 'GET');
      const isAuth = AUTH_PATH.test(path);

      /* ------------------------------------------------ authentication --- */
      // Auth is never cached, never queued and never simulated unless this is
      // an explicit local demo. If the database is down the answer is a 503
      // message, not a fabricated session.
      if (isAuth) {
        if (D.mode === 'standalone') {
          if (!DEMO_ENABLED) throw serviceUnavailable('DEMO_DISABLED');
          return window.AnvayaEngine.handle(path, opts);
        }
        if (D.mode === 'unavailable') throw serviceUnavailable();
        try {
          return await rawCall(path, opts);
        } catch (err) {
          if (err.serviceUnavailable) throw err;
          if (err.status) throw err;                 // 401 / 403 / 409 / 429: a real answer
          // The server could not be reached at all. Do not queue a login.
          if (DEMO_ENABLED) {
            D.mode = 'standalone';
            notify();
            return window.AnvayaEngine.handle(path, opts);
          }
          D.mode = 'unavailable';
          notify();
          D.scheduleRetry();
          const e = new Error(SERVICE_UNAVAILABLE);
          e.status = 503;
          e.serviceUnavailable = true;
          throw e;
        }
      }

      /* ------------------------------------------------------ health --- */
      if (HEALTH_PATH.test(path)) return rawCall(path, opts);

      // Syncable tables go through the local database so the app keeps working
      // with no network, and picks up changes made on other devices.
      const match = path.match(SYNC_PATH);
      const table = match && SYNC_TABLES.includes(match[1]) ? match[1] : null;

      if (table && D.mode !== 'standalone') {
        await D.openLocal();
        const id = match[2] || null;
        const params = new URLSearchParams(match[3] || '');

        if (method === 'GET') {
          if (D.mode === 'server') {
            try {
              const body = await rawCall(path, opts);
              const rows = id ? [body] : (body.data || []);
              await db.putMany(table, rows.map(r => ({ ...r, _dirty: 0 })));
              return body;
            } catch (err) {
              if (err.serviceUnavailable) throw err;
              if (err.status) throw err;
              D.mode = 'offline'; notify(); D.scheduleRetry();
            }
          }
          if (D.mode === 'unavailable') throw serviceUnavailable();
          const cached = id ? await db.get(table, id) : null;
          if (id) {
            if (!cached) { const e = new Error('Not saved on this device'); e.offline = true; throw e; }
            return stripMeta(cached);
          }
          return localQuery(await db.all(table), params);
        }

        // ---- writes: local first, server when it answers
        if (D.mode === 'offline') {
          const local = method === 'DELETE'
            ? (await sync.remove(table, id, opts.baseUpdatedAt), null)
            : await sync.save(table, opts.body || {}, id ? 'PATCH' : 'POST', opts.baseUpdatedAt);
          await D.refreshCounts();
          return local ? { ...stripMeta(local), __queued: true } : { ok: true, __queued: true };
        }
        if (D.mode === 'unavailable') throw serviceUnavailable();

        try {
          const body = await rawCall(path, opts);
          if (id && method !== 'DELETE') await db.put(table, { ...body, _dirty: 0 });
          else if (!id && body && body.id) await db.put(table, { ...body, _dirty: 0 });
          else if (method === 'DELETE') await db.remove(table, id);
          return body;
        } catch (err) {
          if (err.serviceUnavailable) throw err;
          if (err.status) throw err;
          const local = method === 'DELETE'
            ? (await sync.remove(table, id, opts.baseUpdatedAt), null)
            : await sync.save(table, opts.body || {}, id ? 'PATCH' : 'POST', opts.baseUpdatedAt);
          await D.refreshCounts();
          D.mode = 'offline'; notify(); D.scheduleRetry();
          return local ? { ...stripMeta(local), __queued: true } : { ok: true, __queued: true };
        }
      }

      if (D.mode === 'standalone') {
        if (!DEMO_ENABLED) throw serviceUnavailable('DEMO_DISABLED');
        if (!window.AnvayaEngine) throw new Error('Data engine missing — reload the page');
        return window.AnvayaEngine.handle(path, opts);
      }

      if (D.mode === 'unavailable') throw serviceUnavailable();

      /* --------------------------------------------------------- reads --- */
      if (method === 'GET') {
        try {
          const body = await rawCall(path, opts);
          off.cachePut(path, body);
          if (D.mode === 'offline') { D.mode = 'server'; notify(); }
          return body;
        } catch (err) {
          if (err.serviceUnavailable) throw err;
          if (err.status) throw err;                    // a real answer: 404, 403…
          const cached = off.cacheGet(path);
          if (cached !== null) {
            D.mode = 'offline';
            notify();
            D.scheduleRetry();
            return cached;                              // last known good copy
          }
          D.mode = 'offline';
          notify();
          D.scheduleRetry();
          const offline = new Error('You are offline and this screen has not been opened before.');
          offline.offline = true;
          throw offline;
        }
      }

      /* -------------------------------------------------------- writes --- */
      const queue = (reason) => {
        const item = off.enqueue({
          path, method, body: opts.body || null,
          label: opts.label || path,
          baseUpdatedAt: opts.baseUpdatedAt || null
        });
        D.mode = 'offline';
        notify();
        D.scheduleRetry();
        // Hand back something shaped like the record so the UI can continue.
        const optimistic = { ...(opts.body || {}), id: `queued-${item.id}`, __queued: true, __reason: reason };
        return optimistic;
      };

      if (D.mode === 'offline') return queue('offline');

      try {
        const body = await rawCall(path, opts);
        // A successful write makes list caches stale; drop them so the next
        // read is fresh rather than quietly wrong.
        if (method !== 'GET') off.clearCache();
        return body;
      } catch (err) {
        if (err.serviceUnavailable) throw err;
        if (err.status) throw err;                      // the server said no
        return queue('network');
      }
    },

    /** Replay queued changes, oldest first, then pull what changed elsewhere. */
    async flush() {
      if (D.mode !== 'server' || !sync) return { done: [], failed: [], conflicts: [] };
      const pushed = await sync.push();
      let pulled = { rows: 0, conflicts: 0 };
      try { pulled = await sync.pull(); } catch { /* pull retries on the next tick */ }
      await D.refreshCounts();
      return {
        done: new Array(pushed.sent || 0),
        failed: new Array(pushed.failed || 0),
        conflicts: new Array((pushed.conflicts || 0) + (pulled.conflicts || 0))
      };
    },

    /** Try the network first: coming back online should not need a reload. */
    async syncNow() {
      if (D.mode !== 'server') {
        const result = await probe({ attempts: 2, timeoutMs: 8000 });
        if (result.state === 'server') {
          D.mode = 'server';
          off.rememberMode('server');
          if (D._retry) { clearInterval(D._retry); D._retry = null; }
          notify();
        } else if (result.state === 'unavailable') {
          D.mode = 'unavailable';
          notify();
          return { done: [], failed: [], conflicts: [], unavailable: true };
        }
      }
      return D.flush();
    },

    info() {
      if (D.mode === 'server') return 'connected to the server';
      if (D.mode === 'offline') return 'offline — showing the last copy saved here';
      if (D.mode === 'unavailable') return 'the server cannot reach its database';
      if (D.mode === 'checking') return 'checking the connection';
      return DEMO_ENABLED ? 'demo mode — saved in this browser' : 'no server configured';
    }
  };

  window.AnvayaData = D;
  window.AnvayaOfflineStore = off;
})();
