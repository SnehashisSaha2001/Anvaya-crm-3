#!/usr/bin/env python3
"""Builds the single-file edition: one .html containing the whole app.

The UI (index.html + styles.css + app.js) is unchanged; only the HTTP layer is
swapped for web/local-api.js, which implements the same routes against data in
the browser. Nothing else is copied, so the two editions cannot drift apart in
look or behaviour.
"""
import re, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(ROOT, '..')

html = open(os.path.join(WEB, 'index.html')).read()
css = open(os.path.join(WEB, 'styles.css')).read()
app = open(os.path.join(WEB, 'app.js')).read()
local_api = open(os.path.join(WEB, 'engine.js')).read()


def strip_func(src, name):
    """Remove a top-level function by name (brace matched)."""
    m = re.search(r'(?:async )?function ' + re.escape(name) + r'\s*\(', src)
    if not m:
        raise SystemExit('function not found: ' + name)
    # skip the parameter list first, otherwise `opts = {}` confuses brace matching
    j = m.end() - 1
    pdepth = 0
    while j < len(src):
        if src[j] == '(':
            pdepth += 1
        elif src[j] == ')':
            pdepth -= 1
            if pdepth == 0:
                break
        j += 1
    i = src.index('{', j)
    depth = 0
    in_str = None
    esc = False
    while i < len(src):
        ch = src[i]
        if in_str:
            if esc:
                esc = False
            elif ch == '\\':
                esc = True
            elif ch == in_str:
                in_str = None
        else:
            if ch in '`"\'':
                in_str = ch
            elif ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return src[:m.start()] + src[i + 1:]
        i += 1
    raise SystemExit('unbalanced braces in ' + name)


# The HTTP client is replaced by the local engine, which defines window.api.
app = strip_func(app, 'api')
app = app.replace("window.AnvayaData.api(path, opts)", "window.AnvayaEngine.handle(path, opts)")

# Inline the stylesheet.
for link in ('<link rel="stylesheet" href="/styles.css">', '<link rel="stylesheet" href="styles.css">'):
    if link in html:
        html = html.replace(link, '<style>\n' + css + '\n</style>')
        break
else:
    raise SystemExit('stylesheet link not found in index.html')

# Inline the engine and the app.
bundle = (
    '<script>\n/* ---- local data engine ---- */\n'
    + local_api
    + '\n</script>\n<script>\n/* ---- application ---- */\n'
    + app
    + '\n</script>'
)
for tag in ('<script src="/app.js"></script>', '<script src="app.js"></script>'):
    if tag in html:
        html = html.replace(tag, bundle)
        break
else:
    raise SystemExit('app.js script tag not found in index.html')

# The single-file edition has no server: it *is* the demo, so flip the demo
# flag that data.js and engine.js both check. Without this the bundled app
# refuses its own auth routes, which is the correct behaviour for the hosted
# build and the wrong one for this file.
html = html.replace('<meta name="anvaya-demo" content="false">',
                    '<meta name="anvaya-demo" content="true">')

# Tell the truth in the header chip, and offer a reset in the sidebar.
html = html.replace(
    '<span class="demo-chip" id="liveChip"><span class="dot"></span>Live data</span>',
    '<span class="demo-chip" id="liveChip" title="This file has no server. Everything you add is saved in this browser.">'
    '<span class="dot"></span>Saved in this browser</span>'
)

html = html.replace('</body>', """
<script>
/* Single-file extras: a reset control and an honest storage note. */
(function () {
  function addReset() {
    var foot = document.querySelector('.sb-foot');
    if (!foot || document.getElementById('resetDemo')) return;
    var btn = document.createElement('button');
    btn.id = 'resetDemo';
    btn.className = 'btn sm ghost';
    btn.style.cssText = 'width:100%;justify-content:center;margin-top:6px;font-size:11px';
    btn.textContent = 'Reset demo data';
    btn.onclick = function () { window.anvayaReset(); };
    foot.appendChild(btn);
    var note = document.createElement('div');
    note.className = 'tiny faint';
    note.style.cssText = 'padding:6px 8px 0;line-height:1.4;font-size:10px';
    note.textContent = window.anvayaStorageInfo();
    foot.appendChild(note);
  }
  var tries = 0;
  var timer = setInterval(function () {
    addReset();
    if (document.getElementById('resetDemo') || ++tries > 40) clearInterval(timer);
  }, 250);
})();
</script>
</body>""")

# Banner comment at the top of the file.
html = html.replace(
    '<!DOCTYPE html>',
    '<!DOCTYPE html>\n<!-- Anvaya CRM — single-file edition. Open this file in any modern browser.\n'
    '     No server, no install, no build step. Data is stored in this browser only.\n'
    '     The multi-user server edition (PostgreSQL + row level security) is in anvaya-crm.zip. -->'
)

out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, '..', 'anvaya-crm.html')
open(out, 'w').write(html)
size = os.path.getsize(out)
print(f'built {out}  ({size/1024:.0f} KB)')
print('external references:', sorted(set(re.findall(r'(?:src|href)="(https?://[^"]+)"', html))) or 'none')
