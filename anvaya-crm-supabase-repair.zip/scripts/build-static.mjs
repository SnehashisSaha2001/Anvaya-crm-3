#!/usr/bin/env node
// Copies the static app into dist/ for the Vercel CDN.
//
// This replaces a one-line `node -e` build that also tried to run the env
// check and the migrations, each ending in `|| true`. That meant a broken
// database, a broken environment or a failed migration all produced a
// "successful" deployment of a frontend with no working API behind it.
// Building the static bundle and migrating the database are now separate,
// separately-failing steps.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(ROOT, 'dist');

const FILES = [
  'index.html', 'app.js', 'engine.js', 'data.js', 'offline.js', 'idb.js', 'sync.js',
  'pwa.js', 'styles.css', 'manifest.webmanifest', 'sw.js', 'favicon.ico'
];

fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(DIST, { recursive: true });

const copied = [];
for (const file of FILES) {
  const from = path.join(ROOT, file);
  if (!fs.existsSync(from)) {
    console.error(`[build] missing required file: ${file}`);
    process.exit(1);
  }
  fs.copyFileSync(from, path.join(DIST, file));
  copied.push(file);
}

for (const dir of ['icons', 'public']) {
  const from = path.join(ROOT, dir);
  if (fs.existsSync(from)) fs.cpSync(from, path.join(DIST, dir), { recursive: true });
}

// The build must not ship a single credential-bearing file.
for (const forbidden of ['.env', 'backend/.env', 'cookies.txt']) {
  if (fs.existsSync(path.join(DIST, forbidden))) {
    console.error(`[build] refusing to ship ${forbidden} in dist/`);
    process.exit(1);
  }
}

console.log(`[build] dist/ ready — ${copied.length} files, ${(fs.statSync(path.join(DIST, 'app.js')).size / 1024).toFixed(0)} KB app.js`);
