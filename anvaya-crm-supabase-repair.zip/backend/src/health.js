// Health and diagnostics.
//
// One rule governs this file: a green health response must mean a real query
// succeeded against the real production database *and* that the schema the
// application queries actually exists. Nothing here reads a cached flag.
//
// It never returns: the database password, the full DATABASE_URL, any key or
// secret, session tokens or password hashes. Errors are reduced to safe codes.

import {
  verifyConnection, dbStatus, migrationStatus, q, one,
  describeDatabaseUrl, supabaseProjectRef, provider, USER_ROLE, explainDbError
} from './db.js';

/** Tables the authentication and workspace flows cannot work without. */
export const REQUIRED_TABLES = [
  'users', 'sessions', 'organisations', 'workspaces', 'members', 'roles',
  'pipelines', 'stages', 'subscriptions', 'notifications', 'audit_logs'
];

/** Columns the auth/workspace queries reference by name. */
export const REQUIRED_COLUMNS = {
  users: ['id', 'email', 'password_hash', 'full_name', 'is_platform_admin', 'mfa_enabled_at', 'status'],
  sessions: ['id', 'user_id', 'token_hash', 'expires_at', 'revoked_at', 'mfa_ok'],
  organisations: ['id', 'name', 'slug', 'status', 'settings', 'currency', 'timezone', 'plan'],
  workspaces: ['id', 'org_id', 'name', 'slug', 'is_default', 'settings'],
  members: ['id', 'org_id', 'user_id', 'role_id', 'workspace_id', 'status'],
  roles: ['id', 'org_id', 'key', 'permissions'],
  pipelines: ['id', 'org_id', 'name', 'is_default'],
  stages: ['id', 'pipeline_id', 'position', 'probability', 'is_won', 'is_lost'],
  subscriptions: ['id', 'org_id', 'plan', 'status']
};

/** Policies whose absence means tenant isolation is not enforced. */
export const REQUIRED_POLICIES = [
  'leads_sel', 'contacts_sel', 'deals_sel', 'organisations_sel', 'users_sel', 'members_sel'
];

/** The schema version this code expects (latest migration file). */
export const EXPECTED_SCHEMA_VERSION = '006_auth_hardening';

async function schemaState() {
  try {
    const tables = await q(`select table_name from information_schema.tables where table_schema = 'public'`);
    const present = new Set(tables.map((t) => t.table_name));
    const missingTables = REQUIRED_TABLES.filter((t) => !present.has(t));

    const wanted = Object.keys(REQUIRED_COLUMNS);
    const cols = await q(
      `select table_name, column_name from information_schema.columns
        where table_schema = 'public' and table_name = any($1::text[])`,
      [wanted]
    );
    const have = new Set(cols.map((c) => `${c.table_name}.${c.column_name}`));
    const missingColumns = [];
    for (const [table, columns] of Object.entries(REQUIRED_COLUMNS)) {
      if (!present.has(table)) continue;                 // already reported as a missing table
      for (const col of columns) {
        if (!have.has(`${table}.${col}`)) missingColumns.push(`${table}.${col}`);
      }
    }

    return {
      state: missingTables.length === 0 && missingColumns.length === 0 ? 'ok' : 'incomplete',
      tables: present.size,
      missingTables,
      missingColumns
    };
  } catch (err) {
    return { state: 'unknown', error: explainDbError(err).code, tables: null, missingTables: [], missingColumns: [] };
  }
}

async function rlsState() {
  try {
    const rows = await q(`select policyname from pg_policies where schemaname = 'public'`);
    const names = new Set(rows.map((r) => r.policyname));
    const missing = REQUIRED_POLICIES.filter((p) => !names.has(p));
    const rls = await one(
      `select count(*)::int as total,
              count(*) filter (where relrowsecurity)::int as enabled,
              count(*) filter (where relforcerowsecurity)::int as forced
         from pg_class c join pg_namespace n on n.oid = c.relnamespace
        where n.nspname = 'public' and c.relkind = 'r'`
    );
    return {
      state: missing.length === 0 && rls.enabled > 0 ? 'ok' : 'incomplete',
      policies: rows.length,
      tablesWithRls: rls?.enabled ?? 0,
      tablesForced: rls?.forced ?? 0,
      missingPolicies: missing
    };
  } catch (err) {
    return { state: 'unknown', error: explainDbError(err).code, policies: null, missingPolicies: [] };
  }
}

async function grantsState() {
  try {
    const res = await one(
      `select has_table_privilege($1, 'public.leads', 'SELECT') as sel,
              has_table_privilege($1, 'public.leads', 'INSERT') as ins,
              has_table_privilege($1, 'public.sessions', 'SELECT') as sess`,
      [USER_ROLE]
    );
    const ok = Boolean(res?.sel && res?.ins);
    return {
      state: ok ? 'ok' : 'incomplete',
      role: USER_ROLE,
      canSelect: Boolean(res?.sel),
      canInsert: Boolean(res?.ins),
      canReadSessions: Boolean(res?.sess)
    };
  } catch (err) {
    return { state: 'unknown', role: USER_ROLE, error: explainDbError(err).code };
  }
}

async function authState(schema) {
  if (schema.missingTables.includes('sessions') || schema.missingTables.includes('users')) {
    return { state: 'blocked', reason: 'SCHEMA_MISSING_AUTH_TABLES' };
  }
  try {
    const s = await one(
      `select count(*)::int as total,
              count(*) filter (where revoked_at is null and expires_at > now())::int as active
         from sessions`
    );
    const u = await one(
      `select count(*)::int as total,
              count(*) filter (where status = 'active')::int as active
         from users`
    );
    return {
      state: 'ok',
      passwordScheme: 'scrypt',
      sessionStore: 'database (sha256 token hash)',
      users: u?.total ?? null,
      usersActive: u?.active ?? null,
      sessions: s?.total ?? null,
      sessionsActive: s?.active ?? null
    };
  } catch (err) {
    return { state: 'error', error: explainDbError(err).code };
  }
}

async function workspaceState(schema) {
  if (schema.missingTables.some((t) => ['organisations', 'workspaces', 'members', 'pipelines'].includes(t))) {
    return { state: 'blocked', reason: 'SCHEMA_MISSING_WORKSPACE_TABLES' };
  }
  try {
    const row = await one(
      `select (select count(*) from organisations)::int as organisations,
              (select count(*) from workspaces)::int as workspaces,
              (select count(*) from members where status = 'active')::int as active_members,
              (select count(*) from pipelines)::int as pipelines,
              (select count(*) from members m where m.status = 'active' and m.workspace_id is null)::int as members_without_workspace`
    );
    const healthy = row.members_without_workspace === 0;
    return {
      state: healthy ? 'ok' : 'degraded',
      organisations: row.organisations,
      workspaces: row.workspaces,
      activeMembers: row.active_members,
      pipelines: row.pipelines,
      membersWithoutWorkspace: row.members_without_workspace
    };
  } catch (err) {
    return { state: 'error', error: explainDbError(err).code };
  }
}

function safeError(err) {
  if (!err) return null;
  const info = explainDbError(err);
  return { code: info.code, kind: info.kind, retryable: info.retryable, message: info.message };
}

/**
 * The health payload. `status` is 'ok' only when the connection is live, the
 * schema is complete, migrations are applied and RLS is in place.
 */
export async function getHealth({ deep = false } = {}) {
  const started = Date.now();
  const connection = await verifyConnection();

  const payload = {
    status: 'unavailable',
    ok: false,
    // Kept for the static app: `mode: 'server'` is what switches it from
    // browser storage to shared, multi-user records. It is only ever set when
    // a real query against the real database just succeeded.
    mode: 'unavailable',
    provider: provider(),
    driver: dbStatus().driver,
    project: supabaseProjectRef(),
    connectionStatus: {
      state: connection.ok ? 'connected' : 'unavailable',
      latencyMs: connection.ok ? connection.latencyMs : null,
      database: connection.ok ? connection.database : dbStatus().database,
      host: dbStatus().host,
      pooler: dbStatus().pooler,
      checkedAt: new Date().toISOString(),
      error: connection.ok ? null : connection.error
    },
    schemaStatus: { state: 'unknown' },
    migrationStatus: { state: 'unknown' },
    authenticationStatus: { state: 'unknown' },
    workspaceStatus: { state: 'unknown' },
    rlsStatus: { state: 'unknown' },
    permissionsStatus: { state: 'unknown' },
    time: new Date().toISOString(),
    durationMs: null
  };

  if (!connection.ok) {
    payload.error = connection.error;
    payload.durationMs = Date.now() - started;
    return payload;
  }

  const [schema, migrations, rls, grants] = await Promise.all([
    schemaState(), migrationStatus(), rlsState(), grantsState()
  ]);
  const [auth, workspace] = await Promise.all([authState(schema), workspaceState(schema)]);

  payload.schemaStatus = schema;
  payload.migrationStatus = {
    state: migrations.state,
    applied: migrations.applied,
    pending: migrations.pending,
    latest: migrations.latest,
    expected: EXPECTED_SCHEMA_VERSION,
    drift: migrations.drift || []
  };
  payload.authenticationStatus = auth;
  payload.workspaceStatus = workspace;
  payload.rlsStatus = rls;
  payload.permissionsStatus = grants;

  const problems = [];
  if (schema.state !== 'ok') problems.push('SCHEMA_INCOMPLETE');
  if (migrations.state !== 'up-to-date') problems.push('MIGRATIONS_NOT_APPLIED');
  if (rls.state !== 'ok') problems.push('RLS_INCOMPLETE');
  if (grants.state === 'incomplete') problems.push('GRANTS_MISSING');
  if (workspace.state === 'degraded') problems.push('MEMBERS_WITHOUT_WORKSPACE');

  payload.status = problems.length === 0 ? 'ok' : 'degraded';
  payload.ok = payload.status === 'ok';
  payload.mode = 'server';
  payload.problems = problems;
  payload.db = connection.database;
  payload.aiProvider = process.env.AI_API_KEY ? 'configured' : 'local-rules';
  payload.capabilities = [
    'web-forms', 'inbound-email', 'api-keys', 'webhooks', 'integrations',
    'saved-views', 'openapi', 'mfa', 'documents', 'payments'
  ];
  payload.inboundEmail = Boolean(process.env.INBOUND_SECRET);
  payload.integrations = {
    google: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    microsoft: Boolean(process.env.MS_CLIENT_ID && process.env.MS_CLIENT_SECRET)
  };

  if (deep) {
    payload.diagnostics = {
      database: dbStatus(),
      target: describeDatabaseUrl(),
      pool: { role: USER_ROLE },
      node: process.version,
      env: process.env.NODE_ENV || 'unknown',
      vercel: Boolean(process.env.VERCEL),
      region: process.env.VERCEL_REGION || null,
      migrations
    };
  }

  payload.durationMs = Date.now() - started;
  return payload;
}

/** Administrator-only deep view: same safe shape, more detail. */
export async function getDiagnostics() {
  const health = await getHealth({ deep: true });
  const sessions = await q(
    `select count(*)::int as total,
            count(*) filter (where revoked_at is null and expires_at > now())::int as active,
            count(*) filter (where expires_at <= now())::int as expired
       from sessions`
  ).catch(() => [{ total: null, active: null, expired: null }]);
  const orgs = await q(
    `select o.id, o.name, o.status, o.plan,
            (select count(*) from workspaces w where w.org_id = o.id)::int as workspaces,
            (select count(*) from members m where m.org_id = o.id and m.status = 'active')::int as members
       from organisations o order by o.created_at desc limit 25`
  ).catch(() => []);
  return { health, sessions: sessions[0], organisations: orgs };
}

export { safeError };
