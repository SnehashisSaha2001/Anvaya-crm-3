import { initDb, q } from '../src/db.js';

async function check() {
  await initDb();
  const orgs = await q('select count(*)::int as c from organisations');
  console.log('Connected DB organisation count:', orgs[0].c);
}
check().catch(console.error);
