-- ============================================================================
-- OPTIONAL — only if the browser will talk to Supabase directly.
--
-- Path A (recommended, what your Express backend needs): leave this file alone.
--   The backend authenticates users itself and sets app.user_id per
--   transaction; the policies in 02_rls.sql already read that.
--
-- Path B (no backend): Supabase Auth issues the JWT, the browser calls the
--   REST API, and app.uid() reads auth.uid(). For that to work, every
--   auth.users row needs a matching public.users row with the same id, because
--   members.user_id points at public.users.
--
-- Run this once if you choose Path B.
-- ============================================================================

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, email, password_hash, full_name)
  values (
    new.id,
    new.email,
    'supabase-auth',                       -- password lives in auth.users, not here
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();

-- Backfill accounts that already exist.
insert into public.users (id, email, password_hash, full_name)
select u.id, u.email, 'supabase-auth',
       coalesce(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1))
  from auth.users u
 where not exists (select 1 from public.users p where p.id = u.id)
on conflict do nothing;
