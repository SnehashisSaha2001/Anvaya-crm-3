// The connection doctor must pass on a database built from the canonical
// schema, and must fail loudly on the faults that actually caused the
// production outages: FORCE RLS (login reads zero sessions), missing grants,
// and the legacy 29-table schema.

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PGlite } from '@electric-sql/pglite';
import { runChecks } from '../scripts/check-supabase.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const quiet = { log: () => {} };

function canonicalSql() {
  return fs.readFileSync(path.join(__dirname, '../../supabase/anvaya-supabase.sql'), 'utf8');
}

async function buildDb(sqlText) {
  const pg = new PGlite();
  await pg.waitReady;
  await pg.exec(`
    do $$ begin if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if; end $$;
  `);
  if (sqlText) await pg.exec(sqlText);
  return { pg, client: { query: (s, p) => (p === undefined ? pg.query(s) : pg.query(s, p)) } };
}

async function seedSchemaMigrations(pg) {
  // The doctor expects the migration ledger; the SQL bundle does not create it
  // (the runner does), so record the versions here the way `npm run db:migrate`
  // would.
  const dir = path.join(__dirname, '../db/migrations');
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  await pg.exec(`create table if not exists schema_migrations (
    version text primary key, checksum text not null,
    applied_at timestamptz not null default now(), duration_ms int)`);
  for (const f of files) {
    await pg.query('insert into schema_migrations (version, checksum) values ($1,$2)', [f.replace(/\.sql$/, ''), 'x']);
  }
}

describe('supabase connection doctor', () => {
  test('passes on a database built from the canonical schema', async () => {
    const { pg, client } = await buildDb(canonicalSql());
    await seedSchemaMigrations(pg);
    await pg.query(`insert into users (email, password_hash, full_name) values ('doc@test.in','x','Doc')`);
    await pg.query(`insert into organisations (name, slug) values ('Doc Co','doc-co')`);
    await pg.query(`insert into workspaces (org_id, name, slug, is_default)
                    select id, 'Doc Co', 'default', true from organisations where slug = 'doc-co'`);
    await pg.query(`insert into roles (org_id, key, name, permissions)
                    select id, 'owner', 'Owner', '{*}' from organisations where slug = 'doc-co'`);
    await pg.query(`insert into members (org_id, user_id, role_id, workspace_id, status)
                    select o.id, u.id, r.id, w.id, 'active'
                      from organisations o, users u, roles r, workspaces w
                     where o.slug = 'doc-co' and r.org_id = o.id and w.org_id = o.id`);

    const results = await runChecks(client, { ...quiet, role: 'authenticated' });
    const failed = results.filter((r) => !r.pass);
    assert.deepEqual(failed.map((r) => r.name), [], `unexpected failures: ${JSON.stringify(failed)}`);
    assert.ok(results.length >= 10, `expected at least 10 checks, got ${results.length}`);
  });

  test('fails the migration check when the ledger is empty', async () => {
    const { pg, client } = await buildDb(canonicalSql());
    await pg.exec(`create table if not exists schema_migrations (
      version text primary key, checksum text not null,
      applied_at timestamptz not null default now(), duration_ms int)`);
    const results = await runChecks(client, quiet);
    const m = results.find((r) => r.name.includes('migration version'));
    assert.equal(m.pass, false);
    assert.match(m.fix, /db:migrate/);
  });

  test('fails the schema check when the auth tables are missing', async () => {
    // This is the real production fault: the file operators were told to paste
    // into Supabase (the old anvaya-supabase.sql) had 29 tables and no
    // `sessions` table at all, so registration and login could never work.
    const { pg, client } = await buildDb(canonicalSql());
    await seedSchemaMigrations(pg);
    await pg.exec('drop table if exists sessions cascade; drop table if exists subscriptions cascade;');
    const results = await runChecks(client, quiet);
    const schema = results.find((r) => r.name.includes('schema present'));
    assert.equal(schema.pass, false, 'a database without the auth tables must not be accepted');
    assert.match(schema.detail, /sessions/);
  });

  test('fails when RLS is FORCED (the bug that broke login on Supabase)', async () => {
    const { pg, client } = await buildDb(canonicalSql());
    await seedSchemaMigrations(pg);
    await pg.exec(`alter table sessions force row level security;
                   alter table users force row level security;`);
    const results = await runChecks(client, quiet);
    const forced = results.find((r) => r.name.includes('RLS not forced'));
    assert.equal(forced.pass, false);
    assert.match(forced.fix, /006_auth_hardening/);
  });

  test('fails the grants check when the request role lost its privileges', async () => {
    const { pg, client } = await buildDb(canonicalSql());
    await seedSchemaMigrations(pg);
    await pg.exec(`revoke all on all tables in schema public from authenticated;`);
    const results = await runChecks(client, { ...quiet, role: 'authenticated' });
    const grants = results.find((r) => r.name.includes('table privileges'));
    assert.equal(grants.pass, false);
    assert.match(grants.fix, /006_auth_hardening/);
  });
});
