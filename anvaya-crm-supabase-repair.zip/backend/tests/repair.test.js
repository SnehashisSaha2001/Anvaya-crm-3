// Repair regression suite — Tests A to F from the engineering brief.
//
// Everything here runs against the real HTTP API and real SQL, on the `pg`
// code path (PG_SHIM=1 makes the pg adapter talk to PGlite, so transactions,
// SET LOCAL ROLE, set_config and multi-statement exec are all exercised).
// The only thing this cannot prove is the wire protocol to Supabase itself;
// that is what `npm run db:doctor` and tests/live-supabase.test.js are for.

process.env.NODE_ENV = 'test';
process.env.PG_SHIM = '1';
process.env.DB_USER_ROLE = 'app_user';
process.env.ENCRYPTION_KEY = 'test-encryption-key-32-characters-long';

import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { boot, shutdown, client, registerOrg, uniqueEmail } from './helpers.js';
import { q, one, driver, dbStatus, backoffDelay, classifyDbError, __testing } from '../src/db.js';
import { hit } from '../src/security.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..', '..');

let base;
before(async () => { base = await boot(); });
after(async () => { await shutdown(); });

/* ====================================================================== A == */
describe('A · Supabase connectivity and connection lifecycle', () => {
  test('A1 the active driver is pg', () => {
    // The shim stands in for the `pg` module so this suite can run without a
    // database server; the adapter, transactions and SQL are production code.
    assert.equal(driver(), 'pg');
    assert.equal(dbStatus().driver, 'pg');
  });

  test('A2 /api/health performs a real query and reports the full structure', async () => {
    const res = await fetch(`${base}/api/health`);
    const body = await res.json();
    assert.equal(res.status, 200, JSON.stringify(body));
    for (const key of ['status', 'provider', 'driver', 'connectionStatus', 'schemaStatus',
      'migrationStatus', 'authenticationStatus', 'workspaceStatus']) {
      assert.ok(key in body, `health is missing ${key}`);
    }
    assert.equal(body.status, 'ok');
    assert.equal(body.mode, 'server');
    assert.equal(body.driver, 'pg');
    assert.equal(body.connectionStatus.state, 'connected');
    assert.ok(body.connectionStatus.latencyMs >= 0, 'the connection was measured, not assumed');
    assert.equal(body.schemaStatus.state, 'ok');
    assert.deepEqual(body.schemaStatus.missingTables, []);
    assert.equal(body.migrationStatus.state, 'up-to-date');
    assert.equal(body.rlsStatus.state, 'ok');
    assert.equal(body.permissionsStatus.state, 'ok');
  });

  test('A3 health never leaks the URL, password, key or a token', async () => {
    const res = await fetch(`${base}/api/health`);
    const text = await res.text();
    assert.doesNotMatch(text, /postgres(ql)?:\/\//i, 'no connection string');
    assert.doesNotMatch(text, /password_hash/i, 'no password hash');
    assert.doesNotMatch(text, /"password"\s*:/i, 'no password field');
    assert.doesNotMatch(text, /service_role/i);
    assert.doesNotMatch(text, /eyJhbGciOi/, 'no JWT');
    const body = JSON.parse(text);
    assert.equal(body.connectionStatus.error, null);
  });

  test('A4 the schema the auth flow needs actually exists', async () => {
    const tables = await q(`select table_name from information_schema.tables where table_schema='public'`);
    const names = new Set(tables.map((t) => t.table_name));
    for (const t of ['users', 'sessions', 'organisations', 'workspaces', 'members', 'roles',
      'pipelines', 'stages', 'subscriptions', 'notifications']) {
      assert.ok(names.has(t), `missing table ${t}`);
    }
    const cols = await q(`select column_name from information_schema.columns
                           where table_schema='public' and table_name='sessions'`);
    const colNames = new Set(cols.map((c) => c.column_name));
    for (const c of ['token_hash', 'expires_at', 'revoked_at', 'mfa_ok']) assert.ok(colNames.has(c), `sessions.${c}`);
  });

  test('A5 a missing DATABASE_URL in production is a configuration error, not a PGlite fallback', () => {
    // A separate process, because the module caches its connection.
    const script = `
      process.env.NODE_ENV = 'production';
      delete process.env.DATABASE_URL;
      delete process.env.PG_SHIM;
      delete process.env.VERCEL;
      const { initDb, driver } = await import('./backend/src/db.js');
      try {
        await initDb();
        console.log(JSON.stringify({ threw: false, driver: driver() }));
      } catch (err) {
        console.log(JSON.stringify({ threw: true, name: err.name, code: err.code, status: err.status, driver: driver() }));
      }
    `;
    const out = spawnSync(process.execPath, ['--input-type=module', '-e', script], {
      cwd: ROOT, encoding: 'utf8', timeout: 60_000
    });
    const line = (out.stdout || '').trim().split('\n').filter(Boolean).pop();
    assert.ok(line, `no output. stderr: ${out.stderr}`);
    const result = JSON.parse(line);
    assert.equal(result.threw, true, 'production must refuse to start without DATABASE_URL');
    assert.equal(result.code, 'DB_CONFIG_MISSING');
    assert.equal(result.status, 503);
    assert.equal(result.driver, null, 'it must not fall back to PGlite');
  });

  test('A6 error classification: transient is retried, a bad password is not', () => {
    assert.deepEqual(
      { retryable: classifyDbError({ code: '28P01' }).retryable, kind: classifyDbError({ code: '28P01' }).kind },
      { retryable: false, kind: 'credentials' }
    );
    assert.equal(classifyDbError({ code: '3D000' }).retryable, false, 'missing database is permanent');
    assert.equal(classifyDbError({ code: 'ENOTFOUND' }).retryable, false, 'wrong host is permanent');
    assert.equal(classifyDbError({ code: 'ETIMEDOUT' }).retryable, true);
    assert.equal(classifyDbError({ code: 'ECONNRESET' }).retryable, true);
    assert.equal(classifyDbError({ code: '57P03' }).retryable, true, 'cannot_connect_now is transient');
    assert.equal(classifyDbError({ message: 'too many clients already' }).retryable, true);
  });

  test('A7 backoff is bounded, exponential in the ceiling, and jittered', () => {
    const samples = Array.from({ length: 200 }, () => backoffDelay(3, { baseMs: 100, maxMs: 1000 }));
    assert.ok(Math.max(...samples) <= 400, 'attempt 3 ceiling is 4x the base');
    assert.ok(new Set(samples).size > 5, 'jitter is present');
    const capped = Array.from({ length: 200 }, () => backoffDelay(20, { baseMs: 100, maxMs: 1000 }));
    assert.ok(Math.max(...capped) <= 1000, 'never exceeds the cap');
  });

  test('A8 concurrent requests share one pool and one initialisation', async () => {
    const before = dbStatus().initAttempts;
    const results = await Promise.all(Array.from({ length: 20 }, () => fetch(`${base}/api/health`)));
    assert.equal(results.filter((r) => r.status === 200).length, 20);
    assert.equal(dbStatus().initAttempts, before, 'no second pool was created');
  });
});

/* ====================================================================== B == */
describe('B · registration and workspace creation', () => {
  test('B1 a registration writes user, organisation, workspace, membership, roles, pipeline and session', async () => {
    const email = uniqueEmail('b1');
    const api = client();
    const res = await api('/api/auth/register', {
      body: {
        email, password: 'StrongPassword123', fullName: 'B One',
        orgName: 'Brightline Interiors', industry: 'Interior design'
      }
    });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    assert.equal(res.body.ok, true);
    assert.ok(res.body.org.id && res.body.workspace.id && res.body.user.id);

    const user = await one('select * from users where email = $1', [email]);
    assert.ok(user, 'user row exists');
    assert.match(user.password_hash, /^scrypt\$/, 'password is hashed with scrypt, never stored in clear');
    assert.equal(user.status, 'active');

    const org = await one('select * from organisations where id = $1', [res.body.org.id]);
    assert.equal(org.name, 'Brightline Interiors');
    assert.equal(org.industry, 'Interior design');

    const ws = await one('select * from workspaces where id = $1', [res.body.workspace.id]);
    assert.equal(ws.org_id, org.id);
    assert.equal(ws.is_default, true);
    assert.ok(ws.settings && typeof ws.settings === 'object', 'workspace settings were written');

    const member = await one('select * from members where user_id = $1', [user.id]);
    assert.equal(member.org_id, org.id);
    assert.equal(member.workspace_id, ws.id, 'the owner is attached to the workspace');
    assert.equal(member.status, 'active');

    const role = await one('select * from roles where id = $1', [member.role_id]);
    assert.equal(role.key, 'owner');
    assert.deepEqual(role.permissions, ['*']);
    assert.ok((await q('select id from roles where org_id = $1', [org.id])).length >= 5, 'role templates provisioned');

    const pipeline = await one('select * from pipelines where org_id = $1 and is_default', [org.id]);
    assert.ok(pipeline, 'default pipeline created');
    const stages = await q('select * from stages where pipeline_id = $1 order by position', [pipeline.id]);
    assert.equal(stages.length, 6, 'default stages created');
    assert.equal(stages[0].name, 'Discovery');
    assert.equal(stages.find((s) => s.is_won).name, 'Closed won');

    const sub = await one('select * from subscriptions where org_id = $1', [org.id]);
    assert.equal(sub.status, 'trialing');
    assert.ok((await q('select id from notifications where org_id = $1', [org.id])).length === 1);

    const session = await one('select * from sessions where user_id = $1', [user.id]);
    assert.ok(session, 'a session row exists');
    assert.match(session.token_hash, /^[0-9a-f]{64}$/, 'only the token hash is stored');
    assert.equal(session.revoked_at, null);
    assert.ok(new Date(session.expires_at) > new Date());
  });

  test('B2 registration logs the user straight in and opens that workspace', async () => {
    const { api, org } = await registerOrg({ name: 'Auto Login Co' });
    const me = await api('/api/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.body.org.id, org.id);
    assert.ok(me.body.workspace.id, 'the workspace is part of the session context');
    const ws = await one('select id from workspaces where org_id = $1', [org.id]);
    assert.equal(me.body.workspace.id, ws.id);
    assert.equal(me.body.role.key, 'owner');
    assert.equal(api.jar.anvaya_session !== undefined, true, 'the session cookie was set');
  });

  test('B3 a duplicate email is rejected and creates nothing', async () => {
    const email = uniqueEmail('dupe');
    const first = await registerOrg({ name: 'Dupe Co', email });
    assert.ok(first.org.id);

    const orgsBefore = (await one('select count(*)::int n from organisations')).n;
    const usersBefore = (await one('select count(*)::int n from users')).n;

    const again = await client()('/api/auth/register', {
      body: { email, password: 'StrongPassword123', fullName: 'Dupe', orgName: 'Dupe Co 2' }
    });
    assert.equal(again.status, 409, JSON.stringify(again.body));

    assert.equal((await q('select id from users where lower(email) = lower($1)', [email])).length, 1);
    assert.equal((await one('select count(*)::int n from organisations')).n, orgsBefore, 'no orphan organisation');
    assert.equal((await one('select count(*)::int n from users')).n, usersBefore, 'no orphan user');
  });

  test('B4 a failure halfway through registration rolls back every earlier step', async () => {
    // Force a genuine failure at step 9 of 11 (the subscription insert) with a
    // constraint that only rejects new rows. Everything before it — user,
    // organisation, roles, workspace, owner membership, pipeline, stages — has
    // already been written when the failure fires.
    await q(`alter table subscriptions add constraint tmp_reject_trial
             check (status <> 'trialing') not valid`);

    const email = uniqueEmail('rollback');
    let res;
    try {
      res = await client()('/api/auth/register', {
        body: { email, password: 'StrongPassword123', fullName: 'Roll Back', orgName: 'Rollback Co' }
      });
    } finally {
      await q('alter table subscriptions drop constraint if exists tmp_reject_trial');
    }

    assert.notEqual(res.status, 201, 'a failed registration must not report success');
    assert.equal(res.status, 500);
    assert.equal((await q('select id from users where lower(email) = lower($1)', [email])).length, 0, 'no user row');
    assert.equal((await q('select id from organisations where name = $1', ['Rollback Co'])).length, 0, 'no organisation');
    assert.equal((await q(`select id from workspaces w where not exists
                            (select 1 from organisations o where o.id = w.org_id)`)).length, 0, 'no orphan workspace');
    assert.equal((await q(`select id from members m where not exists
                            (select 1 from users u where u.id = m.user_id)`)).length, 0, 'no orphan membership');
    assert.equal((await q(`select id from pipelines p where not exists
                            (select 1 from organisations o where o.id = p.org_id)`)).length, 0, 'no orphan pipeline');
    assert.equal((await q(`select id from sessions s where not exists
                            (select 1 from users u where u.id = s.user_id)`)).length, 0, 'no session without a user');

    // And the same registration succeeds once the injected fault is gone.
    const ok = await client()('/api/auth/register', {
      body: { email, password: 'StrongPassword123', fullName: 'Roll Back', orgName: 'Rollback Co' }
    });
    assert.equal(ok.status, 201, JSON.stringify(ok.body));
  });

  test('B5 a session is never created without a user', async () => {
    const orphans = await q(
      `select s.id from sessions s left join users u on u.id = s.user_id where u.id is null`);
    assert.deepEqual(orphans, []);
    const memberless = await q(
      `select m.id from members m left join users u on u.id = m.user_id
        where u.id is null or m.role_id is null`);
    assert.deepEqual(memberless, []);
  });
});

/* ====================================================================== C == */
describe('C · sign-in, sign-out and session persistence', () => {
  test('C1 correct credentials return 200 and a usable session', async () => {
    const email = uniqueEmail('c1');
    const owner = await registerOrg({ name: 'C1 Co', email });
    const api = client();
    const res = await api('/api/auth/login', { body: { email, password: 'TestPassword123' } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.ok, true);
    assert.equal(res.body.user.email, email);
    const me = await api('/api/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.body.org.id, owner.org.id);
  });

  test('C2 a wrong password is 401 and creates no session', async () => {
    const email = uniqueEmail('c2');
    await registerOrg({ name: 'C2 Co', email });
    const sessionsBefore = (await one('select count(*)::int n from sessions')).n;

    const api = client();
    const res = await api('/api/auth/login', { body: { email, password: 'WrongPassword123' } });
    assert.equal(res.status, 401);
    assert.match(res.body.error, /Incorrect email or password/);
    assert.equal(api.jar.anvaya_session, undefined, 'no cookie was issued');
    assert.equal((await one('select count(*)::int n from sessions')).n, sessionsBefore, 'no session row');
    assert.equal((await api('/api/auth/me')).status, 401, 'no access to the dashboard');
  });

  test('C3 an unknown account is 401 with the same message', async () => {
    const res = await client()('/api/auth/login', {
      body: { email: 'nobody.here@example.test', password: 'SomePassword123' }
    });
    assert.equal(res.status, 401);
    assert.match(res.body.error, /Incorrect email or password/);
  });

  test('C4 a suspended account cannot sign in', async () => {
    const email = uniqueEmail('c4');
    await registerOrg({ name: 'C4 Co', email });
    await q(`update users set status = 'suspended' where email = $1`, [email]);
    const res = await client()('/api/auth/login', { body: { email, password: 'TestPassword123' } });
    assert.equal(res.status, 403);
    assert.match(res.body.error, /suspended/i);
    await q(`update users set status = 'active' where email = $1`, [email]);
  });

  test('C5 an expired session is refused', async () => {
    const email = uniqueEmail('c5');
    const { api } = await registerOrg({ name: 'C5 Co', email });
    assert.equal((await api('/api/auth/me')).status, 200);
    await q(`update sessions set expires_at = now() - interval '1 minute' where user_id =
             (select id from users where email = $1)`, [email]);
    assert.equal((await api('/api/auth/me')).status, 401, 'an expired session is not authenticated');
  });

  test('C6 logout revokes the session in the database', async () => {
    const email = uniqueEmail('c6');
    const { api } = await registerOrg({ name: 'C6 Co', email });
    const token = api.jar.anvaya_session;
    const out = await api('/api/auth/logout', { method: 'POST' });
    assert.equal(out.status, 200);
    assert.equal(api.jar.anvaya_session, undefined, 'the cookie was cleared');
    assert.equal((await api('/api/auth/me')).status, 401);

    // The same cookie must not work even if a client kept a copy.
    const replay = client();
    replay.jar.anvaya_session = token;
    assert.equal((await replay('/api/auth/me')).status, 401, 'the revoked token is dead server-side');
    const row = await one(`select revoked_at from sessions where user_id =
                           (select id from users where email = $1)`, [email]);
    assert.ok(row.revoked_at, 'revoked_at is recorded');
  });

  test('C7 the session survives a "browser restart" (cookie replayed on a new client)', async () => {
    const email = uniqueEmail('c7');
    const { api, org } = await registerOrg({ name: 'C7 Co', email });
    const cookie = api.jar.anvaya_session;
    const orgCookie = api.jar.anvaya_org;

    const reopened = client();
    reopened.jar.anvaya_session = cookie;
    reopened.jar.anvaya_org = orgCookie;
    const me = await reopened('/api/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.body.user.email, email);
    assert.equal(me.body.org.id, org.id, 'the same workspace is restored');
  });

  test('C8 the correct organisation is restored after a second login', async () => {
    const email = uniqueEmail('c8');
    const { org, api: first } = await registerOrg({ name: 'C8 Co', email });
    await first('/api/auth/logout', { method: 'POST' });

    const api = client();
    await api('/api/auth/login', { body: { email, password: 'TestPassword123' } });
    const me = await api('/api/auth/me');
    assert.equal(me.body.org.id, org.id);
    assert.equal(me.body.memberships.length, 1);
  });
});

/* ====================================================================== D == */
describe('D · failure recovery', () => {
  test('D1 a database outage is a JSON 503, not a fake login or a fake workspace', async () => {
    const { api, org, email } = await registerOrg({ name: 'Outage Co' });
    const leadsBefore = (await one('select count(*)::int n from leads where org_id = $1', [org.id])).n;
    const orgsBefore = (await one('select count(*)::int n from organisations')).n;

    // Fault injection at the driver boundary: every query fails the way a
    // dropped connection fails.
    const client_ = __testing.state.client;
    const realQuery = client_.query;
    const realExec = client_.exec;
    const realTransaction = client_.transaction;
    const boom = async () => { throw Object.assign(new Error('Connection terminated unexpectedly'), { code: 'ECONNRESET' }); };
    client_.query = boom;
    client_.exec = boom;
    client_.transaction = boom;

    try {
      const health = await fetch(`${base}/api/health`);
      const healthBody = await health.json();
      assert.equal(health.status, 503, 'health reports the outage');
      assert.equal(healthBody.status, 'unavailable');
      assert.equal(healthBody.mode, 'unavailable');
      assert.equal(healthBody.connectionStatus.state, 'unavailable');
      assert.ok(healthBody.error && healthBody.error.code, 'a safe diagnostic code is present');
      assert.doesNotMatch(JSON.stringify(healthBody), /postgres(ql)?:\/\//i);

      const login = await client()('/api/auth/login', { body: { email, password: 'TestPassword123' } });
      assert.equal(login.status, 503);
      assert.match(login.body.error, /temporarily unable to connect to its database/);

      const reg = await client()('/api/auth/register', {
        body: { email: uniqueEmail('d1'), password: 'StrongPassword123', fullName: 'D One', orgName: 'D1 Co' }
      });
      assert.equal(reg.status, 503, 'registration during an outage is not reported as success');

      const me = await api('/api/auth/me');
      assert.equal(me.status, 503, 'authenticated requests are refused while the database is down');
    } finally {
      client_.query = realQuery;
      client_.exec = realExec;
      client_.transaction = realTransaction;
    }

    // Nothing was invented while the database was down.
    assert.equal((await one('select count(*)::int n from organisations')).n, orgsBefore, 'no fake workspace');
    assert.equal((await one('select count(*)::int n from leads where org_id = $1', [org.id])).n, leadsBefore);
  });

  test('D2 the next request recovers once the database answers again', async () => {
    const health = await fetch(`${base}/api/health`);
    const body = await health.json();
    assert.equal(health.status, 200, JSON.stringify(body));
    assert.equal(body.status, 'ok');
    assert.equal(body.connectionStatus.state, 'connected');

    const email = uniqueEmail('d2');
    const res = await client()('/api/auth/register', {
      body: { email, password: 'StrongPassword123', fullName: 'D Two', orgName: 'D2 Co' }
    });
    assert.equal(res.status, 201, 'registration works again without a restart');
  });
});

/* ====================================================================== E == */
describe('E · persistence', () => {
  test('E1 a CRM record survives logout, sign-in and a new client', async () => {
    const email = uniqueEmail('e1');
    const { api, org } = await registerOrg({ name: 'Persist Co', email });
    const made = await api('/api/leads', { body: { name: 'Persistent Lead', company_name: 'Acme' } });
    assert.equal(made.status, 201);

    await api('/api/auth/logout', { method: 'POST' });

    const back = client();
    const login = await back('/api/auth/login', { body: { email, password: 'TestPassword123' } });
    assert.equal(login.status, 200);
    const me = await back('/api/auth/me');
    assert.equal(me.body.org.id, org.id, 'the same workspace opens');

    const list = await back('/api/leads?q=Persistent');
    assert.equal(list.status, 200);
    assert.equal(list.body.total, 1);
    assert.equal(list.body.data[0].name, 'Persistent Lead');
  });

  test('E2 records live in PostgreSQL, not in the browser or on local disk', async () => {
    const { org } = await registerOrg({ name: 'Disk Check Co' });
    const row = await one('select count(*)::int n from organisations where id = $1', [org.id]);
    assert.equal(row.n, 1, 'the row is in the database the app queries');
    // A redeploy of the serverless function cannot erase this: there is no
    // local file the app writes to, and PGlite is refused in production (A5).
    assert.equal(driver(), 'pg', 'the row lives in the SQL database, not in browser storage');
  });
});

/* ====================================================================== F == */
describe('F · security', () => {
  test('F1 one organisation cannot read another organisation\'s records', async () => {
    const a = await registerOrg({ name: 'Iso Alpha' });
    const b = await registerOrg({ name: 'Iso Beta' });
    const lead = await a.api('/api/leads', { body: { name: 'Alpha Only', company_name: 'Alpha' } });
    assert.equal(lead.status, 201);

    const list = await b.api('/api/leads');
    assert.equal(list.body.total, 0);
    assert.equal((await b.api(`/api/leads/${lead.body.id}`)).status, 404);
    assert.equal((await b.api(`/api/leads/${lead.body.id}`, { method: 'PATCH', body: { status: 'lost' } })).status, 404);
    assert.equal((await b.api(`/api/leads/${lead.body.id}`, { method: 'DELETE' })).status, 404);

    const switchOrg = await b.api('/api/auth/switch-org', { body: { orgId: a.org.id } });
    assert.equal(switchOrg.status, 403, 'you cannot switch into an organisation you do not belong to');
  });

  test('F2 an invalid or forged session token is rejected', async () => {
    const forged = client();
    forged.jar.anvaya_session = 'f'.repeat(64);
    assert.equal((await forged('/api/auth/me')).status, 401);
    const empty = client();
    assert.equal((await empty('/api/auth/me')).status, 401);
  });

  test('F3 the session cookie is HttpOnly, SameSite=Lax and correctly scoped', async () => {
    const email = uniqueEmail('f3');
    const res = await fetch(`${base}/api/auth/register`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email, password: 'StrongPassword123', fullName: 'F Three', orgName: 'F3 Co' })
    });
    assert.equal(res.status, 201);
    const setCookies = res.headers.getSetCookie();
    const session = setCookies.find((c) => c.startsWith('anvaya_session='));
    assert.ok(session, 'the session cookie was set');
    assert.match(session, /HttpOnly/i);
    assert.match(session, /SameSite=Lax/i);
    assert.match(session, /Path=\//i);
    assert.match(session, /Expires=/i, 'it is persistent, not a session cookie');
    // Served over plain http here: marking it Secure would make the browser
    // drop it, which is exactly the bug that made login "not stick" locally.
    assert.doesNotMatch(session, /;\s*Secure/i);
  });

  test('F4 cross-site state changes are blocked', async () => {
    const { api } = await registerOrg({ name: 'CSRF Co' });
    const res = await fetch(`${base}/api/auth/logout`, {
      method: 'POST',
      headers: { origin: 'https://evil.example', cookie: `anvaya_session=${api.jar.anvaya_session}` }
    });
    assert.equal(res.status, 403);
    const body = await res.json();
    assert.equal(body.code, 'CROSS_SITE_BLOCKED');
    assert.equal((await api('/api/auth/me')).status, 200, 'the session was not touched');
  });

  test('F5 the login rate limiter stops credential stuffing', () => {
    const key = `login:${Math.random()}`;
    const results = Array.from({ length: 12 }, () => hit(key, 10, 60_000));
    assert.equal(results.filter((r) => r.allowed).length, 10);
    assert.equal(results[11].allowed, false);
    assert.ok(results[11].retryAfter > 0);
  });

  test('F6 no secret is exposed in the browser files', () => {
    const files = ['index.html', 'app.js', 'data.js', 'engine.js', 'offline.js', 'sync.js', 'idb.js', 'pwa.js'];
    for (const file of files) {
      const text = fs.readFileSync(path.join(ROOT, file), 'utf8');
      assert.doesNotMatch(text, /postgres(ql)?:\/\/[^\s'"]*:[^\s'"]*@/, `${file} must not contain a connection string`);
      assert.doesNotMatch(text, /service_role/, `${file} must not mention a service-role key`);
      assert.doesNotMatch(text, /eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9/, `${file} must not contain a JWT`);
      assert.doesNotMatch(text, /DATABASE_URL\s*=/, `${file} must not contain DATABASE_URL`);
    }
  });

  test('F7 production builds cannot fall into demo authentication', () => {
    const index = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    assert.match(index, /<meta name="anvaya-demo" content="false">/, 'the hosted build is not a demo');

    const engine = fs.readFileSync(path.join(ROOT, 'engine.js'), 'utf8');
    assert.match(engine, /ANVAYA_DEMO_ENABLED !== true/, 'the engine refuses auth routes unless demo mode is explicit');

    const data = fs.readFileSync(path.join(ROOT, 'data.js'), 'utf8');
    assert.match(data, /demoMeta\.content === 'true'/, 'demo requires an explicit flag');
    assert.match(data, /isLocalOrigin/, 'demo requires a local origin');
    assert.match(data, /serviceUnavailable/, 'a database outage produces a service-unavailable error, not a fallback');
  });
});
