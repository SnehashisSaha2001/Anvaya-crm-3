# Anvaya CRM V6 — release notes, test report and feature status

## 1. What this increment delivers

| # | Feature | Status | Evidence |
|---|---|---|---|
| P0-A | Multi-factor authentication | **Complete** | TOTP enrolment, 6-digit verification, 10 single-use backup codes, disable-with-password, pending sessions refused, org-level enforcement flag, audit entries. 4 tests. |
| P0-B | PDF documents | **Complete** | Quotation, tax invoice and payment receipt PDFs generated from real records with branding, GST split, totals and version snapshots. 3 tests, one asserting the bytes are a real PDF. |
| P0-C | Payment management | **Complete for manual + gateway webhooks** | Record payment, partial payments, refunds, credit notes, payment links, provider-agnostic adapter, HMAC-verified webhook with replay protection. 6 tests. |
| P0-D | Invoice enhancement | **Complete** | Server-side numbering (`INV-YYYY-0001`), GST/discount breakdown, due dates, overdue detection, outstanding balance, credit notes. 5 tests. |
| §9 | Navigation architecture | **Complete** | Seven groups exactly as specified, permission-filtered, verified in a browser. |

## 2. What is not complete, and why

| Feature | Status | Reason |
|---|---|---|
| Live Razorpay / Stripe checkout | **Adapter written, unverified** | Needs your merchant keys. The manual provider and signed webhooks work today; the redirect-to-gateway path cannot be exercised without an account. |
| Gmail / Outlook sending, templates, inbox | **Partial** | OAuth, encrypted tokens, refresh and mail→activity sync exist. Sending needs a verified OAuth app. |
| Advanced report builder | **Not started** | Saved views and fixed reports exist. The builder is a separate project. |
| Visual workflow canvas | **Partial** | Engine, conditions, actions, approvals and run history all work; the canvas is UI only. |
| Offline write queue | **Partial** | The static edition is fully offline; the server edition does not queue writes. |
| Layout builder, dashboard customisation | **Not started** | Requires a form-schema layer. |
| Multi-currency administration | **Partial** | Currency per record and an exchange-rate table exist; no admin screen, no automated rates. |

Nothing above is marked complete on the strength of a screen.

## 3. Test report

`cd backend && npm test` — **64 tests, 64 passing, 0 failing.**

| Suite | Tests | Covers |
|---|---|---|
| `api.test.js` | 15 | registration, login, lead CRUD, conversion, stage moves, dashboard, search |
| `security.test.js` | 15 | tenant isolation, forged cookies, permission enforcement, audit immutability, input handling |
| `growth.test.js` | 14 | web forms, inbound email, API keys, webhooks, saved views, integration plumbing, OpenAPI |
| `frontend.test.js` | 4 | app shell served, assets, SPA fallback |
| `v6.test.js` | 16 | MFA, documents, finance (new) |

Regression: all 48 pre-existing tests still pass unchanged, which is the evidence
that V5 behaviour survived the upgrade.

### Specific assertions worth knowing

- A session that has not cleared MFA returns 401 on `/api/leads`.
- A backup code used twice returns 401 the second time.
- 40 × 2,500 + 48,000 = 148,000; 18% = 26,640; total 174,640 — computed server-side.
- A 10,000 invoice with a 1,000 discount is taxed on 9,000, not 10,000.
- The same idempotency key twice yields one payment, not two.
- A replayed gateway webhook does not double-charge.
- An unsigned webhook is refused with 503 when no secret is configured, 401 when the signature is wrong.
- `INV-2026-0001` numbering is allocated inside a transaction.

## 4. Database migration guide

```bash
cd backend
npm install
npm run migrate      # applies 004_mfa.sql and 005_documents_finance.sql
```

Both migrations are additive and idempotent (`if not exists`). To verify before
touching production, run `npm run migrate` against a copy:

```bash
pg_dump "$PROD_URL" > backup.sql      # always take this first
psql "$STAGING_URL" -f backup.sql
DATABASE_URL="$STAGING_URL" npm run migrate
```

Rollback is a drop of the six new tables plus the added columns; no V5 column was
modified, so a rollback cannot lose V5 records.

## 5. Configuration

See `backend/.env.example`. New in V6:

```
ENCRYPTION_KEY=            # required for MFA secrets and provider tokens (32+ chars)
PAYMENT_WEBHOOK_SECRET=    # required before any gateway webhook is accepted
RAZORPAY_KEY_ID=           # optional, enables live Razorpay links
RAZORPAY_KEY_SECRET=
STRIPE_SECRET_KEY=         # optional, enables live Stripe links
PUBLIC_APP_URL=            # used to build payment links
```

Nothing in the frontend reads these; they are server-side only.

## 5a. Layout fix in 6.1

Reported: the interface did not fit a laptop screen. Two causes, both fixed:

1. **The sidebar was not constrained to the viewport.** It measured 969px inside
   a 640px screen, so its user footer sat below the fold and the nav could not
   scroll. Grid and flex children now carry `min-height: 0`, so the sidebar is
   exactly the viewport height, the nav scrolls, and the footer stays pinned.
2. **Vertical rhythm assumed a tall screen.** At ≤820px of height the top bar,
   page padding, card padding, stat sizes and the start card now run in a
   compact density; the pipeline columns shrink so all six stages fit at
   1366px wide instead of needing a sideways scroller.

Verified at 1280×600, 1366×640 and 1440×780: no horizontal overflow anywhere,
sidebar footer visible, all six pipeline stages on screen, no clipped tables.

## 5b. Schema alignment (v6.3)

The Supabase setup file was compared table-by-table and column-by-column against
what the frontend and API expect: 51 tables, identical columns, no drift. What
did surface was three columns the schema requires with no default that the
create path did not fill — the API returned 500 on each:

| Table | Required column | Before | Now |
|---|---|---|---|
| tickets | `number` | 500 error | generated `TKT-2026-0001` |
| products | `sku` | 500 error | generated `SKU-2026-0001` |
| quotations | `number` | 500 error | generated `QTN-2026-0001` |

Identifiers are now generated per organisation in `createResource`, and an
explicit value from a client still wins. The three forms no longer force a user
to invent one — the field says "leave blank and one is generated".

Verified by building the database from the supplied setup file, booting the real
app on it, and driving all 20 screens in a browser: every view rendered, no
failed API calls, no page errors. Also fixed: the revenue chart drew a 1/1/0
axis for an organisation with no won deals; it now shows an empty state.

## 5c. Supabase link

`backend/scripts/check-supabase.mjs` verifies in one command whether a backend
can use a given Supabase project: connection, schema, policies, identity
helpers, grants to `authenticated`, a seeded workspace, and a live RLS read as a
signed-in user. Three tests cover it — it passes on a correct database and fails
specifically on the wrong-grants case that broke the first bundle.

Full instructions: `docs/SUPABASE-LINK.md`.

## 5d. Local storage is a backup (v6.6)

Local storage no longer acts as a second database once a server is reachable.
Three states, and the header chip names which one is live:

| State | Reads | Writes | Local storage |
|---|---|---|---|
| **Live data** | server | server | a cache of what was read |
| **Offline** | last cached copy | queued in the outbox | the queue itself |
| **Saved in this browser** | the browser engine | the browser engine | the only store (no server configured) |

Rules that make it safe rather than dangerous:

- The server is the source of truth the moment one is reached. The browser
  engine is used only when no server has ever answered.
- A cached read is served **only when the request actually failed**. A 403 or a
  404 still surfaces as an error; a dead network does not.
- A queued change is marked `sending` before the request leaves, so a crash
  mid-flight can never replay it twice — it is held back and shown for review.
- A queued edit is dropped when the server row changed after the edit was made,
  rather than overwriting a colleague's work.
- The queue stops at the first network failure and keeps everything.

Verified in a real browser: online (8 leads, Live data) → offline reload (chip
Offline, banner shown, 8 leads from cache, still signed in) → edit while offline
(queued, banner "1 change waiting to sync") → back online and sync (queue
drained, banner gone, the lead reached the database). 5 unit tests cover the
cache and outbox rules; 78 tests pass in total.

**Bug found and fixed while testing this:** a form submits `null` for every
field left empty, and on insert that overrode the column default — so any
`NOT NULL DEFAULT 0` column (estimated_value, probability, score) failed with a
500. Creates now omit nulls and let the database apply its default.

## 5e. IndexedDB local database and two-way sync (v6.7)

The local store is now a real database, not a response cache:

- **`idb.js`** — one IndexedDB object store per CRM table, plus `meta`
  (sync cursors), `outbox` and `conflicts`. Every row carries `_dirty`,
  `_base` and `_deleted`, stripped before anything is sent.
- **`sync.js`** — `pull()` asks each table for rows changed since its cursor;
  `push()` replays the queue oldest first; `syncAll()` does both.
- **`data.js`** — the twelve syncable tables read and write through the local
  database. Everything else (auth, dashboard, AI, finance) stays a plain
  request.

**Conflict rule.** A local edit is applied only if the server row has not moved
since the edit's base. If it has, the server version keeps the record and the
local version is filed under `conflicts` and shown in a review sheet — both
versions side by side. Nothing is silently lost, nothing silently overwrites.

**Delta sync.** The list endpoint now accepts `updated_since`, so a device pulls
only what changed rather than re-downloading every table.

Verified in two browser contexts at once (two "devices"):

```
device A 8 leads · device B 8 leads
A offline, adds a lead      → queued, banner "1 change waiting to sync"
A back online, syncs        → banner cleared, LIVE DATA
B syncs                     → 9 → 10 rows, the lead from A present by name
```

9 unit tests cover pull, push, conflict, refusal, network stop and ordering.
87 tests pass in total.

## 6. Known limitations

1. Payment links fall back to an internal `/pay/<token>` URL when no gateway is
   configured — the note in the API response says so explicitly.
2. PDFs are rendered on demand from a stored snapshot; there is no queue for
   very large batches.
3. MFA is per user. Organisation enforcement is a flag
   (`organisations.settings.require_mfa`) that prompts enrolment; it does not
   yet lock out a user who ignores it.
4. The audit log records who and what, not before/after diffs for every field.
