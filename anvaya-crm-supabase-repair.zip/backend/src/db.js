// Database access layer — the single, canonical connection module.
//
// Rules this file exists to enforce:
//
//   1. Supabase PostgreSQL is the only production database. There is no
//      silent fallback: if DATABASE_URL is missing in production the process
//      reports a configuration error and the API answers 503. It never
//      switches drivers behind the operator's back and it never deletes
//      DATABASE_URL to "make things work".
//   2. Exactly one pool per process/instance. initDb() is idempotent and
//      concurrency-safe: every caller awaits the same promise.
//   3. A failed initialisation is recoverable: the promise is cleared, so the
//      next request retries — after a short cooldown for permanent errors, so
//      bad credentials do not produce an infinite retry storm.
//   4. Retries are bounded, exponential and jittered, and only for errors that
//      can actually be transient (network, DNS, pool exhaustion, 57P03 …).
//      Credential and configuration errors are never retried.
//   5. Tenant context (SET LOCAL ROLE + set_config) fails closed. If the role
//      switch does not take effect the request is aborted instead of quietly
//      running as the pool owner with RLS bypassed.
//   6. Migrations are versioned, checksummed, advisory-locked and recorded in
//      schema_migrations. They never run per API request.
//
// Two drivers exist, and only two:
//   DATABASE_URL set                 → PostgreSQL (Supabase / RDS / Neon) via `pg`
//   DATABASE_URL unset and allowed   → PGlite, for local development and tests
// PGlite is allowed only when NODE_ENV is development/test, or DB_ALLOW_PGLITE=1,
// and never on Vercel.

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const PKG_ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');

/* ------------------------------------------------------------------ errors -- */

/** Raised when the database cannot be reached or is not usable. Maps to HTTP 503. */
export class DbUnavailableError extends Error {
  constructor(message, { code = 'DB_UNAVAILABLE', retryable = true, cause } = {}) {
    super(message);
    this.name = 'DbUnavailableError';
    this.code = code;
    this.status = 503;
    this.retryable = retryable;
    this.cause = cause;
  }
}

/** Raised when configuration (not connectivity) is wrong. Maps to HTTP 503 too. */
export class DbConfigError extends DbUnavailableError {
  constructor(message, code = 'DB_CONFIG_INVALID') {
    super(message, { code, retryable: false });
    this.name = 'DbConfigError';
  }
}

/**
 * Raised when a request's tenant context cannot be established.
 * The request must abort: continuing would run with RLS not applied.
 */
export class TenantContextError extends Error {
  constructor(message, { cause } = {}) {
    super(message);
    this.name = 'TenantContextError';
    this.code = 'TENANT_CONTEXT_FAILED';
    this.status = 500;
    this.cause = cause;
  }
}

/* ------------------------------------------------------------ environment -- */

export const isVercel = Boolean(process.env.VERCEL);
export const isProduction = process.env.NODE_ENV === 'production';
export const isTest = process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'testing';

/**
 * PGlite is a development/test convenience, never a production database.
 * It is refused on Vercel and in production unless explicitly unlocked.
 */
export function pgliteAllowed() {
  if (process.env.DB_ALLOW_PGLITE === '1') return true;
  if (isVercel) return false;
  if (isProduction) return false;
  return true;
}

/**
 * Loads a .env file only when the process was given nothing at all.
 * Never overwrites a variable that is already set, never runs in production
 * (Vercel supplies real environment variables) and never runs under test, so
 * a stray .env cannot redirect the test suite at a live database.
 */
function loadDotEnvOnce() {
  if (isProduction || isTest || isVercel) return;
  if (process.env.DATABASE_URL) return;
  for (const envPath of [
    path.join(PKG_ROOT, '../.env'),
    path.join(PKG_ROOT, '.env'),
    path.join(process.cwd(), '.env')
  ]) {
    try {
      if (!fs.existsSync(envPath)) continue;
      const content = fs.readFileSync(envPath, 'utf8');
      for (const line of content.split('\n')) {
        const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
        if (!match || match[1].startsWith('#')) continue;
        let val = match[2] || '';
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        if (!process.env[match[1]]) process.env[match[1]] = val;
      }
      return envPath;
    } catch { /* unreadable .env is not fatal */ }
  }
  return null;
}
loadDotEnvOnce();

/* ------------------------------------------------------- connection string -- */

/** Trimmed, quote-stripped, scheme-normalised DATABASE_URL. Secrets intact. */
export function getSanitizedDatabaseUrl() {
  let raw = (process.env.DATABASE_URL || '').trim().replace(/^["']|["']$/g, '');
  if (!raw) return '';
  if (!/^postgres(ql)?:\/\//i.test(raw)) {
    // A bare "user:pass@host:5432/db" string is a common paste mistake.
    if (raw.includes('@')) raw = `postgresql://${raw}`;
  }
  return raw;
}

/**
 * Everything we know about the target without ever exposing the password.
 * `host`, `port`, `user`, `database` are safe to log and to return to an
 * authenticated operator; the password and the full URL never leave this file.
 */
export function describeDatabaseUrl() {
  const raw = getSanitizedDatabaseUrl();
  if (!raw) {
    return { configured: false, host: null, port: null, user: null, database: null, pooler: false, direct: false };
  }
  try {
    const url = new URL(raw);
    const host = url.hostname;
    const port = url.port ? Number(url.port) : 5432;
    const pooler = /pooler\.supabase\.com$/i.test(host) || port === 6543;
    const direct = /^db\.[a-z0-9]+\.supabase\.co$/i.test(host);
    return {
      configured: true,
      host,
      port,
      user: decodeURIComponent(url.username || ''),
      database: decodeURIComponent((url.pathname || '/postgres').replace(/^\//, '')) || 'postgres',
      pooler,
      direct,
      // PgBouncer in transaction mode cannot carry session-level state, so the
      // connection pool below must not rely on it.
      pgbouncer: pooler
    };
  } catch {
    return { configured: true, host: null, port: null, user: null, database: null, pooler: false, direct: false, malformed: true };
  }
}

/** Supabase project ref, when the host is a Supabase host. */
export function supabaseProjectRef() {
  const info = describeDatabaseUrl();
  if (!info.host) return null;
  const direct = info.host.match(/^db\.([a-z0-9]+)\.supabase\.co$/i);
  if (direct) return direct[1];
  const user = (info.user || '').match(/^postgres\.([a-z0-9]+)$/i);
  if (user) return user[1];
  const pooler = info.host.match(/^([a-z0-9-]+)\.pooler\.supabase\.com$/i);
  return pooler ? user || null : null;
}

/** Which provider this URL points at, for diagnostics. */
export function provider() {
  const info = describeDatabaseUrl();
  if (!info.configured) return pgliteAllowed() ? 'pglite' : 'none';
  if (!info.host) return 'postgres';
  if (/supabase\.(co|com|in)$/i.test(info.host)) return 'supabase';
  if (/neon\.tech$/i.test(info.host)) return 'neon';
  return 'postgres';
}

/* -------------------------------------------------------- error classing --- */

const PERMANENT_CODES = new Set([
  '28P01', // invalid_password
  '28000', // invalid_authorization_specification
  '3D000', // invalid_catalog_name (database does not exist)
  '42501', // insufficient_privilege
  'ENOTFOUND', // host does not resolve at all — a wrong host is permanent
  'DB_CONFIG_MISSING',
  'DB_CONFIG_INVALID'
]);

const TRANSIENT_CODES = new Set([
  'ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN', 'ENETUNREACH',
  'EHOSTUNREACH', 'EPIPE', 'EPROTO', 'ENETDOWN', 'EHOSTDOWN',
  '08000', '08001', '08003', '08004', '08006', '08007', '08P01',
  '57P01', '57P02', '57P03', // admin shutdown, crash shutdown, cannot_connect_now
  '53300', // too_many_connections
  'XX000'  // internal error — worth one retry
]);

/**
 * Classify a connection error. This is what stops the old behaviour of
 * retrying a wrong password forever (and of deleting DATABASE_URL when the
 * network blipped).
 */
export function classifyDbError(err) {
  const code = err?.code || err?.errno || '';
  const message = String(err?.message || '');
  if (err instanceof DbConfigError) return { code: err.code, retryable: false, kind: 'configuration' };
  if (PERMANENT_CODES.has(code)) {
    return {
      code,
      retryable: false,
      kind: code === '28P01' || code === '28000' ? 'credentials'
        : code === '3D000' ? 'database_missing'
        : code === 'ENOTFOUND' ? 'dns'
        : 'permission'
    };
  }
  if (TRANSIENT_CODES.has(code)) return { code, retryable: true, kind: 'network' };
  if (/timeout|timed out/i.test(message)) return { code: code || 'TIMEOUT', retryable: true, kind: 'timeout' };
  if (/too many clients|remaining connection slots|pool (is )?exhausted/i.test(message)) {
    return { code: code || 'POOL_EXHAUSTED', retryable: true, kind: 'pool' };
  }
  if (/terminating connection|server closed the connection|Connection terminated/i.test(message)) {
    return { code: code || 'CONNECTION_TERMINATED', retryable: true, kind: 'network' };
  }
  if (/password authentication failed|no pg_hba\.conf entry/i.test(message)) {
    return { code: code || '28P01', retryable: false, kind: 'credentials' };
  }
  if (/getaddrinfo|ENOTFOUND|name or service not known/i.test(message)) {
    return { code: code || 'ENOTFOUND', retryable: false, kind: 'dns' };
  }
  return { code: code || 'UNKNOWN', retryable: false, kind: 'unknown' };
}

/** A short, safe, human-readable explanation for an operator. Never contains secrets. */
export function explainDbError(err) {
  const { code, kind, retryable } = classifyDbError(err);
  const map = {
    credentials: 'The database rejected the username or password. Check the DATABASE_URL password (URL-encode it) and that the Supabase project is not paused.',
    database_missing: 'The database named in DATABASE_URL does not exist on that host. Supabase databases are called "postgres".',
    dns: 'The database host does not resolve. A paused or deleted Supabase project, or a wrong project ref, looks exactly like this.',
    permission: 'The database user lacks a required privilege. Check the GRANT block and that the role exists.',
    network: 'The database host was not reachable from this runtime. On Vercel use the Supabase pooler host (port 6543); the direct host is IPv6-only.',
    timeout: 'The connection attempt timed out. On serverless use the pooler endpoint and keep the pool small.',
    pool: 'The database refused a new connection because its connection limit is reached. Lower DB_POOL_SIZE or use the pooler.',
    configuration: 'The database configuration is incomplete or invalid.',
    unknown: 'The database connection failed.'
  };
  return { code, kind, retryable, message: map[kind] || map.unknown };
}

/* ---------------------------------------------------------------- backoff --- */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Bounded exponential backoff with full jitter.
 * attempt 1 → 0..base, attempt 2 → 0..2*base, capped at maxMs.
 */
export function backoffDelay(attempt, { baseMs = 250, maxMs = 4000 } = {}) {
  const ceiling = Math.min(maxMs, baseMs * 2 ** Math.max(0, attempt - 1));
  return Math.round(Math.random() * ceiling);
}

/* ------------------------------------------------------------------ state --- */

const state = {
  client: null,
  driver: null,
  initPromise: null,
  initError: null,
  permanentFailure: null,   // { at, code } — blocks retries for a cooldown
  initialisedAt: null,
  generation: 0,
  attempts: 0,
  lastError: null,
  lastVerifiedAt: null
};

/** The role a request runs as, so RLS applies. Supabase calls it `authenticated`. */
export const USER_ROLE = process.env.DB_USER_ROLE
  || (getSanitizedDatabaseUrl() || process.env.PG_SHIM === '1' ? 'authenticated' : 'app_user');

/* --------------------------------------------------------------- adapters --- */

function pgliteAdapter(c) {
  return {
    driver: 'pglite',
    query: (sql, params) => c.query(sql, params),
    exec: (sql) => c.exec(sql),
    transaction: (fn) => c.transaction(fn),
    close: () => c.close(),
    raw: c
  };
}

function pgAdapter(pool) {
  return {
    driver: 'pg',
    pool,
    query: (sql, params) => pool.query(sql, params),
    // No parameters → the simple protocol, which allows several statements.
    exec: (sql) => pool.query(sql),
    async transaction(fn) {
      const conn = await pool.connect();
      try {
        await conn.query('begin');
        const out = await fn({
          query: (sql, params) => conn.query(sql, params),
          exec: (sql) => conn.query(sql)
        });
        await conn.query('commit');
        return out;
      } catch (err) {
        try { await conn.query('rollback'); } catch { /* connection already gone */ }
        throw err;
      } finally {
        conn.release();
      }
    },
    close: () => pool.end(),
    raw: pool
  };
}

/* ------------------------------------------------------------ pool options -- */

function poolOptions(connectionString) {
  const info = describeDatabaseUrl();
  const serverless = isVercel || Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME);
  // One serverless instance may serve many concurrent requests but must not
  // open many connections: Supabase's pooler is the shared budget.
  const defaultMax = serverless ? 3 : 10;
  const max = Math.max(1, Math.min(Number(process.env.DB_POOL_SIZE) || defaultMax, 20));

  const sslDisabled = process.env.DATABASE_SSL === '0'
    || /sslmode=disable/i.test(connectionString)
    || /^localhost$|^127\.0\.0\.1$/.test(info.host || '');

  const ssl = sslDisabled
    ? false
    : { rejectUnauthorized: process.env.DATABASE_SSL_STRICT === '1' };

  return {
    connectionString,
    max,
    min: 0,
    // Serverless: never hold a socket open for an idle instance.
    idleTimeoutMillis: Number(process.env.DB_IDLE_TIMEOUT_MS) || (serverless ? 5000 : 30000),
    connectionTimeoutMillis: Number(process.env.DB_CONNECT_TIMEOUT_MS) || (serverless ? 10000 : 5000),
    maxUses: Number(process.env.DB_MAX_USES) || 750,
    allowExitOnIdle: serverless,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10000,
    application_name: 'anvaya-crm',
    // A stuck query must not hold a serverless invocation open.
    statement_timeout: Number(process.env.DB_STATEMENT_TIMEOUT_MS) || 15000,
    query_timeout: Number(process.env.DB_QUERY_TIMEOUT_MS) || 20000,
    ssl
  };
}

async function createPgPool(connectionString) {
  if (process.env.PG_SHIM === '1') {
    const shim = await import('../tests/pg-shim.mjs');
    return new shim.Pool(poolOptions(connectionString));
  }
  const { default: pg } = await import('pg');
  const pool = new pg.Pool(poolOptions(connectionString));
  // Without this, a backend-side disconnect crashes the whole instance.
  pool.on('error', (err) => {
    const info = explainDbError(err);
    console.error(`[db] idle client error (${info.code}/${info.kind}) — the pool will recover on the next request`);
    state.lastError = { code: info.code, kind: info.kind, at: new Date().toISOString(), phase: 'idle-client' };
  });
  return pool;
}

/* --------------------------------------------------------------- init ------- */

/**
 * Connect (once) and prove the connection with a real query.
 * Concurrency-safe: all callers share one promise.
 */
export async function initDb({ force = false } = {}) {
  if (state.client && !force) return state.client;
  if (state.initPromise && !force) return state.initPromise;

  state.initPromise = (async () => {
    state.attempts += 1;

    const connectionString = getSanitizedDatabaseUrl();

    if (!connectionString) {
      if (process.env.PG_SHIM === '1') {
        // Test harness: the pg shim needs no URL. Never reachable in production.
        return await connectViaShim();
      }
      if (!pgliteAllowed()) {
        throw new DbConfigError(
          'DATABASE_URL is not set. Production requires a Supabase PostgreSQL connection string; '
          + 'there is no local database fallback.',
          'DB_CONFIG_MISSING'
        );
      }
      return await connectViaPglite();
    }

    if (describeDatabaseUrl().malformed) {
      throw new DbConfigError('DATABASE_URL is not a valid PostgreSQL connection string.', 'DB_CONFIG_INVALID');
    }

    // A permanent failure blocks retries for a cooldown so a wrong password
    // does not produce a retry storm across every request.
    if (state.permanentFailure) {
      const age = Date.now() - state.permanentFailure.at;
      const cooldown = Number(process.env.DB_PERMANENT_COOLDOWN_MS) || 30000;
      if (age < cooldown) {
        throw new DbUnavailableError(
          `Database connection is misconfigured (${state.permanentFailure.code}); retrying in ${Math.ceil((cooldown - age) / 1000)}s.`,
          { code: state.permanentFailure.code, retryable: false }
        );
      }
      state.permanentFailure = null;
    }

    const maxAttempts = Math.max(1, Number(process.env.DB_CONNECT_RETRIES) || 3);
    let lastErr = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      let pool = null;
      try {
        pool = await createPgPool(connectionString);
        // A real query — the only acceptable proof of a working connection.
        const started = Date.now();
        const res = await pool.query('select current_database() as db, current_user as usr, now() as now');
        const latency = Date.now() - started;
        state.client = pgAdapter(pool);
        state.driver = 'pg';
        state.initialisedAt = new Date().toISOString();
        state.lastVerifiedAt = new Date().toISOString();
        state.initError = null;
        state.lastError = null;
        const info = describeDatabaseUrl();
        console.log(
          `[db] connected: ${info.host}:${info.port}/${info.database} as ${info.user} `
          + `(driver=pg, pooler=${info.pooler}, max=${poolOptions(connectionString).max}, `
          + `attempt=${attempt}, ${latency}ms)`
        );
        if (info.direct && (isVercel || process.env.AWS_LAMBDA_FUNCTION_NAME)) {
          console.warn(
            '[db] WARNING: DATABASE_URL points at the direct Supabase host (db.<ref>.supabase.co). '
            + 'That host is IPv6-only and fails intermittently from Vercel. Use the Session/Transaction '
            + 'pooler host (aws-0-<region>.pooler.supabase.com:6543) in production.'
          );
        }
        return state.client;
      } catch (err) {
        lastErr = err;
        if (pool) { try { await pool.end(); } catch { /* already dead */ } }
        const info = explainDbError(err);
        state.lastError = {
          code: info.code, kind: info.kind, retryable: info.retryable,
          at: new Date().toISOString(), phase: 'connect', attempt
        };
        console.error(`[db] connection attempt ${attempt}/${maxAttempts} failed (${info.code}/${info.kind}): ${info.message}`);

        if (!info.retryable) {
          state.permanentFailure = { at: Date.now(), code: info.code };
          throw new DbUnavailableError(info.message, { code: info.code, retryable: false, cause: err });
        }
        if (attempt < maxAttempts) {
          const delay = backoffDelay(attempt);
          console.warn(`[db] transient failure — retrying in ${delay}ms`);
          await sleep(delay);
        }
      }
    }

    const info = explainDbError(lastErr);
    throw new DbUnavailableError(info.message, { code: info.code, retryable: true, cause: lastErr });
  })();

  try {
    const client = await state.initPromise;
    state.initPromise = null;
    return client;
  } catch (err) {
    // Clear the promise so a later request can recover from a transient fault.
    state.initPromise = null;
    state.initError = err;
    state.client = null;
    state.driver = null;
    throw err;
  }
}

async function connectViaShim() {
  const connectionString = 'postgresql://shim/shim';
  const pool = await createPgPool(connectionString);
  await pool.query('select 1');
  state.client = pgAdapter(pool);
  state.driver = 'pg';
  state.initialisedAt = new Date().toISOString();
  state.lastVerifiedAt = new Date().toISOString();
  console.log('[db] connected via pg shim (test harness only)');
  return state.client;
}

async function connectViaPglite() {
  if (state.client) return state.client;
  const { PGlite } = await import('@electric-sql/pglite');
  const DATA_DIR = process.env.DB_PATH || path.join(PKG_ROOT, '.data', 'anvaya');
  let pg;
  if (process.env.DB_MEMORY === '1') {
    pg = new PGlite();
  } else {
    fs.mkdirSync(path.dirname(DATA_DIR), { recursive: true });
    pg = new PGlite(DATA_DIR);
  }
  await pg.waitReady;
  try {
    await pg.exec(`
      do $$
      begin
        if not exists (select 1 from pg_roles where rolname = 'app_user') then
          create role app_user nologin;
        end if;
        if not exists (select 1 from pg_roles where rolname = 'authenticated') then
          create role authenticated nologin;
        end if;
      exception when others then null;
      end $$;
    `);
  } catch { /* roles are best effort in the local engine */ }
  state.client = pgliteAdapter(pg);
  state.driver = 'pglite';
  state.initialisedAt = new Date().toISOString();
  state.lastVerifiedAt = new Date().toISOString();
  console.warn(
    '[db] using PGlite (local development/test database). '
    + 'This is NOT production: data lives on this machine only.'
  );
  return state.client;
}

export function db() {
  if (!state.client) throw new DbUnavailableError('Database is not initialised', { code: 'DB_NOT_INITIALISED' });
  return state.client;
}

async function ready() {
  if (!state.client) await initDb();
  return state.client;
}

export function driver() {
  return state.client ? state.client.driver : null;
}

/**
 * A real round trip, every time. Used by /api/health so a cached "connected"
 * flag can never be mistaken for a working database.
 */
export async function verifyConnection({ timeoutMs = 5000 } = {}) {
  try {
    await ready();
    const started = Date.now();
    const run = state.client.query('select current_database() as db, current_user as usr, now() as now, version() as version');
    const res = await Promise.race([
      run,
      sleep(timeoutMs).then(() => { throw Object.assign(new Error('verification query timed out'), { code: 'ETIMEDOUT' }); })
    ]);
    state.lastVerifiedAt = new Date().toISOString();
    return {
      ok: true,
      latencyMs: Date.now() - started,
      database: res.rows[0].db,
      user: res.rows[0].usr,
      serverTime: res.rows[0].now,
      version: String(res.rows[0].version || '').split(' ').slice(0, 2).join(' ')
    };
  } catch (err) {
    const info = explainDbError(err);
    state.lastError = { code: info.code, kind: info.kind, at: new Date().toISOString(), phase: 'verify' };
    return { ok: false, error: { code: info.code, kind: info.kind, message: info.message } };
  }
}

/** Safe status snapshot for diagnostics. No URL, no password, no tokens. */
export function dbStatus() {
  const info = describeDatabaseUrl();
  return {
    configured: info.configured,
    provider: provider(),
    driver: state.driver,
    host: info.host,
    port: info.port,
    database: info.database,
    user: info.user,
    pooler: info.pooler,
    direct: info.direct,
    userRole: USER_ROLE,
    poolMax: info.configured ? poolOptions(getSanitizedDatabaseUrl() || 'postgresql://x/y').max : null,
    initialisedAt: state.initialisedAt,
    lastVerifiedAt: state.lastVerifiedAt,
    initAttempts: state.attempts,
    lastError: state.lastError,
    permanentFailure: state.permanentFailure
      ? { code: state.permanentFailure.code, at: new Date(state.permanentFailure.at).toISOString() }
      : null
  };
}

/* ------------------------------------------------------------------ query --- */

/**
 * Convert a driver-level connection failure into DbUnavailableError, so the
 * HTTP layer can answer 503 instead of a generic 500. A SQL error (unique
 * violation, missing column, permission denied on a row) is a bug in the
 * request, not an outage, and is left alone.
 */
function wrapDriverError(err) {
  if (err instanceof DbUnavailableError || err instanceof TenantContextError) return err;
  const info = classifyDbError(err);
  if (info.retryable) {
    state.lastError = { code: info.code, kind: info.kind, at: new Date().toISOString(), phase: 'query' };
    return new DbUnavailableError(info.message, { code: info.code, retryable: true, cause: err });
  }
  return err;
}

/** System query — bypasses RLS. Only for auth, migrations and audit writes. */
export async function q(sql, params = []) {
  await ready();
  try {
    const res = await db().query(sql, params);
    return res.rows;
  } catch (err) {
    throw wrapDriverError(err);
  }
}

export async function one(sql, params = []) {
  const rows = await q(sql, params);
  return rows[0] || null;
}

/** System transaction. */
export async function tx(fn) {
  await ready();
  try {
    return await db().transaction(async (t) => fn({
      q: async (sql, params = []) => (await t.query(sql, params)).rows,
      one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null,
      exec: async (sql) => t.exec(sql)
    }));
  } catch (err) {
    throw wrapDriverError(err);
  }
}

/**
 * Run a callback inside a transaction acting as a given user.
 * ctx = { orgId, userId, perms: string[], workspaceId? }
 *
 * Fails closed: if the role switch cannot be established on a real PostgreSQL
 * connection, the transaction is rolled back and the request is aborted. The
 * old behaviour (swallow the error, keep going as the pool owner) silently
 * disabled row level security.
 */
export async function asUser(ctx, fn) {
  if (!ctx || !ctx.orgId || !ctx.userId) throw new Error('asUser requires orgId and userId');
  const perms = (ctx.perms || []).join(',');
  await ready();

  try {
    return await db().transaction(async (t) => {
      if (state.driver === 'pg') {
        try {
          await t.query(`set local role ${USER_ROLE}`);
        } catch (err) {
          throw new TenantContextError(
            `Could not assume the application role "${USER_ROLE}"; refusing to run the request without row level security.`,
            { cause: err }
          );
        }
        // Prove the switch actually took effect before trusting the transaction.
        const who = await t.query('select current_user as usr');
        if (who.rows?.[0]?.usr !== USER_ROLE) {
          throw new TenantContextError(
            `Application role "${USER_ROLE}" did not take effect (current_user=${who.rows?.[0]?.usr}); aborting.`
          );
        }
      }
      await t.query(`select set_config('app.org_id', $1, true)`, [ctx.orgId]);
      await t.query(`select set_config('app.user_id', $1, true)`, [ctx.userId]);
      await t.query(`select set_config('app.perms', $1, true)`, [perms]);
      if (ctx.workspaceId) {
        await t.query(`select set_config('app.workspace_id', $1, true)`, [ctx.workspaceId]);
      }
      return fn({
        q: async (sql, params = []) => (await t.query(sql, params)).rows,
        one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null,
        exec: async (sql) => t.exec(sql)
      });
    });
  } catch (err) {
    throw wrapDriverError(err);
  }
}

/* ---------------------------------------------------------------- closing -- */

export async function closeDb() {
  const client = state.client;
  state.client = null;
  state.driver = null;
  state.initPromise = null;
  state.generation += 1;
  if (client && client.close) {
    try { await client.close(); } catch { /* already closed */ }
  }
}

/* -------------------------------------------------------------- migrations -- */

const MIGRATIONS_DIR = path.join(PKG_ROOT, 'db', 'migrations');

function checksum(text) {
  return crypto.createHash('sha256').update(text).digest('hex').slice(0, 16);
}

function migrationFiles(dir) {
  return fs.readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort()
    .map((file) => {
      const sql = fs.readFileSync(path.join(dir, file), 'utf8');
      return { version: file.replace(/\.sql$/, ''), file, sql, checksum: checksum(sql) };
    });
}

/**
 * Versioned, checksummed migrations.
 *  - recorded in schema_migrations, so a restart does not replay them
 *  - guarded by an advisory lock, so two instances cannot race
 *  - refused when an applied file changed (drift is a bug, not a warning)
 *  - never destructive: the files are additive and idempotent
 */
export async function migrate({ dir = MIGRATIONS_DIR, log = console.log } = {}) {
  await ready();
  const files = migrationFiles(dir);

  await db().exec(`
    create table if not exists schema_migrations (
      version    text primary key,
      checksum   text not null,
      applied_at timestamptz not null default now(),
      duration_ms int
    );
  `);

  const lockKey = 728_119_337;
  let locked = false;
  if (state.driver === 'pg' && process.env.PG_SHIM !== '1') {
    await q('select pg_advisory_lock($1)', [lockKey]);
    locked = true;
  }

  const applied = [];
  const skipped = [];
  const drift = [];
  try {
    const rows = await q('select version, checksum from schema_migrations');
    const seen = new Map(rows.map((r) => [r.version, r.checksum]));

    for (const m of files) {
      const previous = seen.get(m.version);
      if (previous === m.checksum) { skipped.push(m.version); continue; }
      if (previous && previous !== m.checksum) {
        drift.push({ version: m.version, applied: previous, onDisk: m.checksum });
        continue;
      }
      const started = Date.now();
      try {
        await db().exec(m.sql);
      } catch (err) {
        throw new Error(`Migration ${m.file} failed: ${err.message}`);
      }
      const duration = Date.now() - started;
      await q(
        `insert into schema_migrations (version, checksum, duration_ms) values ($1,$2,$3)
         on conflict (version) do update set checksum = excluded.checksum, applied_at = now()`,
        [m.version, m.checksum, duration]
      );
      applied.push(m.version);
      log(`[migrate] applied ${m.file} (${duration}ms)`);
    }

    if (drift.length) {
      throw new Error(
        `Schema drift detected: ${drift.map((d) => d.version).join(', ')} changed after being applied. `
        + 'Add a new migration file instead of editing an applied one.'
      );
    }
  } finally {
    if (locked) { try { await q('select pg_advisory_unlock($1)', [lockKey]); } catch { /* ignore */ } }
  }

  return { applied, skipped, files: files.map((f) => f.version) };
}

/** Migration state for diagnostics — never throws. */
export async function migrationStatus() {
  try {
    await ready();
    const exists = await one(`select to_regclass('public.schema_migrations') as t`);
    if (!exists?.t) {
      return { state: 'not-run', applied: 0, pending: migrationFiles(MIGRATIONS_DIR).length, latest: null, drift: [] };
    }
    const rows = await q('select version, applied_at from schema_migrations order by version');
    const files = migrationFiles(MIGRATIONS_DIR);
    const appliedVersions = new Set(rows.map((r) => r.version));
    const pending = files.filter((f) => !appliedVersions.has(f.version)).map((f) => f.version);
    const appliedChecks = new Map(rows.map((r) => [r.version, null]));
    void appliedChecks;
    const checks = await q('select version, checksum from schema_migrations');
    const byVersion = new Map(checks.map((r) => [r.version, r.checksum]));
    const drift = files
      .filter((f) => byVersion.has(f.version) && byVersion.get(f.version) !== f.checksum)
      .map((f) => f.version);
    return {
      state: pending.length === 0 && drift.length === 0 ? 'up-to-date' : drift.length ? 'drift' : 'pending',
      applied: rows.length,
      pending: pending.length,
      pendingVersions: pending,
      latest: rows.length ? rows[rows.length - 1].version : null,
      drift
    };
  } catch (err) {
    return { state: 'unknown', error: explainDbError(err).code };
  }
}

export const __testing = { state, poolOptions, resetForTests: () => { state.permanentFailure = null; } };
