// Verifies the server actually serves the built frontend and that the SPA
// fallback works, so "it runs" is a checked claim rather than an assumption.

import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { boot, shutdown } from './helpers.js';

let base;
before(async () => { base = await boot(); });
after(async () => { await shutdown(); });

test('index.html is served at the root', async () => {
  const res = await fetch(base + '/');
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /Anvaya CRM/);
  assert.match(html, /id="app"/);
  assert.match(html, /app\.js/);
});

test('stylesheet and script are served with correct types', async () => {
  const css = await fetch(base + '/styles.css');
  assert.equal(css.status, 200);
  assert.match(css.headers.get('content-type'), /text\/css/);
  const cssText = await css.text();
  assert.ok(cssText.includes('--brand'), 'design tokens are present');

  const js = await fetch(base + '/app.js');
  assert.equal(js.status, 200);
  assert.match(js.headers.get('content-type'), /javascript/);
  const jsText = await js.text();
  assert.ok(jsText.includes('/api/dashboard'), 'frontend calls the real API');
});

test('unknown non-api routes fall back to the app shell', async () => {
  const res = await fetch(base + '/leads');
  assert.equal(res.status, 200);
  assert.match(await res.text(), /Anvaya CRM/);
});

test('unknown api routes do not fall back to HTML', async () => {
  const res = await fetch(base + '/api/nope');
  assert.equal(res.status, 404);
});
