import dns from 'node:dns/promises';
import pg from 'pg';

async function run() {
  const addresses = await dns.resolve4('db.pduywbweuxlvcatvesff.supabase.co');
  console.log('IPv4 addresses:', addresses);
  const ip = addresses[0];
  const pool = new pg.Pool({
    connectionString: process.env.DATABASE_URL || `postgresql://postgres@${ip}:5432/postgres`,
    ssl: { rejectUnauthorized: false, servername: 'db.pduywbweuxlvcatvesff.supabase.co' }
  });
  const res = await pool.query('select 1');
  console.log('Connected successfully via IPv4!', res.rows);
  await pool.end();
}
run().catch(console.error);
