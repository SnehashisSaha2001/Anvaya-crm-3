// Vercel serverless entry point.
//
// The rules this file follows:
//
//   * One initialisation per instance. Every request awaits the same promise,
//     so a cold start cannot open two pools or run two migrations.
//   * Initialisation is never per-request work: migrations do not run here
//     unless MIGRATE_ON_BOOT=1 is set deliberately (run `npm run db:migrate`
//     in CI or from a shell instead).
//   * A failed initialisation is cleared, so the next request retries. A
//     transient network blip therefore heals without a redeploy.
//   * A database outage is answered with a JSON 503 that says so, never with
//     an HTML page, never with a stack trace and never with a secret.
//   * There is no local-database fallback. If DATABASE_URL is missing this
//     deployment is misconfigured, and it says that plainly.

import serverless from 'serverless-http';
import { createApp } from '../backend/src/app.js';
import { initDb, migrate, DbUnavailableError, explainDbError, dbStatus } from '../backend/src/db.js';

const app = createApp();
const handler = serverless(app, {
  // The static files are served by the CDN, not by this function.
  binary: false
});

let initPromise = null;
let initState = 'pending';     // pending | ready | failed
let lastInitError = null;

function ensureInitialised() {
  if (initState === 'ready') return Promise.resolve();
  if (initPromise) return initPromise;

  initPromise = (async () => {
    await initDb();
    if (process.env.MIGRATE_ON_BOOT === '1') {
      const out = await migrate({ log: (m) => console.log(m) });
      if (out.applied.length) console.log(`[api] migrations applied: ${out.applied.join(', ')}`);
    }
    initState = 'ready';
    lastInitError = null;
  })();

  initPromise.catch((err) => {
    // Leave the state as 'failed' and clear the promise: the next request
    // gets a fresh attempt, and db.js applies its own backoff/cooldown.
    initState = 'failed';
    lastInitError = err;
    initPromise = null;
  });

  return initPromise;
}

/**
 * Raw Node response. The handler below sits *outside* Express (serverless-http
 * adapts it later), so there is no res.status().json() at this level.
 */
function sendJson(res, status, payload) {
  if (res.headersSent) return;
  const body = JSON.stringify(payload);
  res.statusCode = status;
  res.setHeader('content-type', 'application/json; charset=utf-8');
  res.setHeader('cache-control', 'no-store');
  res.end(body);
}

function unavailable(res, err) {
  const info = explainDbError(err);
  const status = dbStatus();
  // Safe, operator-useful log line. No URL, no password, no token.
  console.error(
    `[api] database unavailable (${info.code}/${info.kind}) `
    + `provider=${status.provider} driver=${status.driver} host=${status.host} pooler=${status.pooler}`
  );
  return sendJson(res, 503, {
    status: 'unavailable',
    ok: false,
    mode: 'unavailable',
    error: 'Anvaya CRM is temporarily unable to connect to its database. Please try again.',
    code: info.code || 'DB_UNAVAILABLE',
    retryable: info.retryable !== false
  });
}

export default async function (req, res) {
  const path = (req.url || '').split('?')[0];

  // Static assets never need the database; let the CDN handle them.
  if (!path.startsWith('/api')) return handler(req, res);

  try {
    await ensureInitialised();
  } catch (err) {
    if (err instanceof DbUnavailableError || err?.code?.startsWith?.('DB_')) return unavailable(res, err);
    console.error('[api] initialisation failed:', err?.code || '', err?.message);
    return sendJson(res, 503, {
      status: 'unavailable',
      ok: false,
      mode: 'unavailable',
      error: 'Anvaya CRM is temporarily unable to connect to its database. Please try again.',
      code: 'DB_INIT_FAILED'
    });
  }

  try {
    return await handler(req, res);
  } catch (err) {
    if (err instanceof DbUnavailableError) return unavailable(res, err);
    console.error('[api] unhandled error:', err?.code || '', err?.message);
    return sendJson(res, 500, { error: 'Something went wrong', code: 'INTERNAL_ERROR' });
  }
}

/** Exposed for a warm-up probe or a test harness. */
export { lastInitError };
