import { initDb, q } from '../src/db.js';
import { dashboard } from '../src/intelligence.js';

async function run() {
  await initDb();
  const org = await q('select id from organisations limit 1');
  const user = await q('select id from users limit 1');
  const member = await q('select id from members limit 1');
  const role = await q('select permissions from roles limit 1');
  
  const ctx = {
    orgId: org[0].id,
    userId: user[0].id,
    memberId: member[0].id,
    perms: role[0].permissions
  };
  
  const data = await dashboard(ctx);
  console.log('Dashboard query succeeded! KPI:', data.kpi);
}
run().catch(console.error);
