import pg from 'pg';

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false }
});

async function main() {
  console.log('[rls] Disabling RLS on all public tables as requested...');
  await pool.query(`
    DO $$ 
    DECLARE 
        r RECORD;
    BEGIN 
        FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') 
        LOOP
            EXECUTE 'ALTER TABLE public.' || quote_ident(r.tablename) || ' DISABLE ROW LEVEL SECURITY;';
        END LOOP;
    END $$;
  `);
  console.log('[rls] RLS successfully disabled on all public tables!');
  await pool.end();
}

main().catch(err => {
  console.error('[rls] Error:', err);
  process.exit(1);
});
