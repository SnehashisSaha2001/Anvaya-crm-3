# Supabase schema — one canonical source

`anvaya-supabase.sql` in the parent folder is **generated** from
`backend/db/migrations/*.sql`. Paste it into the Supabase SQL Editor once and
the database matches the code exactly.

```bash
node scripts/build-supabase-sql.mjs          # regenerate after adding a migration
node scripts/build-supabase-sql.mjs --check  # CI: fail if it is stale
```

## Why `legacy/` exists

The files in this folder are the *other* schema this project used to ship:
`00_helpers.sql`, `01_schema.sql`, `02_rls.sql`, `03_seed.sql`,
`04_optional_supabase_auth.sql`, `05_functions.sql`, plus their README.

They are a different design, not an older version of the same one:

* no `sessions` table at all — the backend's login is built on it;
* no `subscriptions`, `notifications`, `members.workspace_id`,
  `organisations.currency/timezone/settings`;
* different column names (`members.manager_id` instead of `workspace_id` +
  `joined_at`), so `insert into members (…, workspace_id, joined_at)` fails;
* 29 tables where the application expects 51.

An operator who pasted *that* file into Supabase got a database where
registration failed on a missing column and login failed on a missing table,
while `/api/health` still said the connection was fine. That is the schema
drift this repair removes.

Do not run the legacy files. Do not mix them with the canonical schema.
