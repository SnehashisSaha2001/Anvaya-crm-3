-- ============================================================================
-- Anvaya CRM — 006 authentication and workspace hardening
--
-- Additive and idempotent. Nothing is dropped, nothing is truncated, no
-- customer row is deleted. Safe to run on a live database.
--
-- It fixes four concrete production faults found in the shipped code:
--
--   1. RLS was FORCED on every table. On Supabase the connecting role
--      ("postgres") is NOT a superuser, so FORCE RLS applied the policies to
--      the application's own system connection as well. With no policy on
--      sessions (by design) the auth layer could read zero rows, so every
--      login failed while the schema looked perfectly healthy. FORCE is
--      removed: RLS stays ENABLED, the owner bypasses it, and request
--      connections (SET ROLE authenticated / app_user) are still fully
--      constrained by policy.
--   2. users had no status column, so a suspended account could still sign in.
--   3. Invitations carried a token that was never stored, so anyone who knew
--      an invited email address could set its password. The hash and expiry
--      are now persisted and verified.
--   4. members.workspace_id could be null, leaving a signed-in user with no
--      workspace. Existing rows are repaired to the organisation's default
--      workspace (a pointer, not a data rewrite).
-- ============================================================================

-- ---------------------------------------------------- 1 · RLS enforcement ---
-- Enable everywhere, force nowhere.
do $$
declare t record;
begin
  for t in
    select c.relname
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
     where n.nspname = 'public' and c.relkind = 'r'
       and c.relname <> 'schema_migrations'
  loop
    execute format('alter table public.%I enable row level security', t.relname);
    execute format('alter table public.%I no force row level security', t.relname);
  end loop;
end $$;

-- Re-assert the grants the request role needs. Idempotent; the old bundle
-- granted to app_user only, which does nothing for a Supabase connection that
-- switches to `authenticated`.
do $$
begin
  begin
    execute 'grant usage on schema public to authenticated, app_user';
    execute 'grant usage on schema app to authenticated, app_user';
    execute 'grant select, insert, update, delete on all tables in schema public to authenticated, app_user';
    execute 'grant usage, select on all sequences in schema public to authenticated, app_user';
    execute 'grant execute on all functions in schema app to authenticated, app_user';
  exception when others then
    raise notice 'grant block skipped: %', sqlerrm;
  end;
end $$;

-- app.uid() is the name some tooling expects; keep it as an alias.
create or replace function app.uid() returns uuid
  language sql stable as $$
    select app.current_user()
$$;

-- The active workspace, for policies and diagnostics.
create or replace function app.current_workspace() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.workspace_id', true), '')::uuid
$$;

-- --------------------------------------------------------- 2 · accounts ---
alter table users add column if not exists status text not null default 'active';
alter table users add column if not exists suspended_at timestamptz;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'users_status_check') then
    begin
      alter table users add constraint users_status_check
        check (status in ('active', 'suspended', 'disabled'));
    exception when others then
      raise notice 'users_status_check not added: %', sqlerrm;
    end;
  end if;
end $$;

-- A case-insensitive unique index on email, so "Ada@x.com" and "ada@x.com"
-- cannot both register. The pre-existing unique constraint is case-sensitive.
-- Wrapped: if a live database already holds case-duplicates, the migration
-- reports it and continues instead of blocking every later migration.
do $$
begin
  begin
    create unique index if not exists users_email_lower_uniq on users (lower(email));
  exception when others then
    raise notice 'users_email_lower_uniq not created (existing case-duplicate emails): %', sqlerrm;
  end;
end $$;

-- ------------------------------------------------------ 3 · invitations ---
alter table members add column if not exists invite_token_hash text;
alter table members add column if not exists invite_expires_at timestamptz;
create unique index if not exists members_invite_token_uniq
  on members (invite_token_hash) where invite_token_hash is not null;

-- ----------------------------------------------------------- 4 · sessions ---
alter table sessions add column if not exists last_seen_at timestamptz;
create index if not exists sessions_user_active on sessions (user_id) where revoked_at is null;
create index if not exists sessions_expires on sessions (expires_at);

-- ------------------------------------------------- 5 · workspace pointers ---
alter table workspaces alter column settings set default '{}'::jsonb;

-- Point members that have no workspace at their organisation's default one.
-- This only fills a null pointer; it never overwrites an existing value.
update members m
   set workspace_id = (
     select w.id from workspaces w
      where w.org_id = m.org_id
      order by w.is_default desc, w.created_at
      limit 1)
 where m.workspace_id is null
   and exists (select 1 from workspaces w where w.org_id = m.org_id);

-- Every organisation needs a default workspace for the same reason.
insert into workspaces (org_id, name, slug, is_default)
select o.id, o.name, 'default', true
  from organisations o
 where o.deleted_at is null
   and not exists (select 1 from workspaces w where w.org_id = o.id)
on conflict (org_id, slug) do nothing;

-- --------------------------------------------------------- 6 · pipelines ---
create index if not exists stages_pipeline_position on stages (pipeline_id, position);
create index if not exists pipelines_org_default on pipelines (org_id, is_default);

-- ------------------------------------------------------- 7 · subscriptions ---
-- Non-unique on purpose: an existing database may already hold more than one
-- subscription row per organisation, and a unique index would fail the whole
-- migration for data the application can still handle.
create index if not exists subscriptions_org_idx on subscriptions (org_id);
