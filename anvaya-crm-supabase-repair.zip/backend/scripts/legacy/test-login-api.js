import { createApp } from '../src/app.js';
import { initDb } from '../src/db.js';
import http from 'node:http';

async function run() {
  await initDb();
  const app = createApp();
  const server = http.createServer(app);
  server.listen(0, async () => {
    const port = server.address().port;
    try {
      const resp = await fetch(`http://localhost:${port}/api/auth/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email: 'sneha@brightline.in', password: 'AnvayaDemo2026' })
      });
      const data = await resp.json();
      console.log('Login response status:', resp.status);
      console.log('Login response body:', data);
      console.log('Set-Cookie headers:', resp.headers.getSetCookie?.() || resp.headers.get('set-cookie'));
    } catch (err) {
      console.error('Login test failed:', err);
    } finally {
      server.close();
    }
  });
}
run();
