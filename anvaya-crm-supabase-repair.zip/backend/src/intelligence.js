// Analytics and the AI layer.
//
// Two modes for the copilot, and it says which one it is using:
//   provider — an OpenAI-compatible endpoint is configured (AI_API_KEY +
//              AI_BASE_URL). The model gets a permission-scoped context.
//   local    — no provider configured. Answers are computed from SQL over the
//              caller's own records. No model is called and nothing is invented.
//
// Either way the run is logged in ai_runs, and any write the copilot suggests
// is stored in ai_actions as 'proposed' until a human approves it.

import { asUser, q, one } from './db.js';
import { writeAudit } from './audit.js';

// ------------------------------------------------------------- analytics ---
export async function dashboard(ctx) {
  return asUser(ctx, async (t) => {
    const kpi = await t.one(`
      with open_deals as (
        select * from deals where status = 'open' and deleted_at is null
      ), won as (
        select * from deals where status = 'won' and deleted_at is null
          and updated_at >= date_trunc('quarter', now())
      ), lost as (
        select * from deals where status = 'lost' and deleted_at is null
          and updated_at >= date_trunc('quarter', now())
      )
      select
        (select coalesce(sum(value),0) from open_deals) as pipeline_value,
        (select count(*) from open_deals) as open_deals,
        (select coalesce(sum(value * coalesce(probability,0)/100.0),0) from open_deals) as weighted_value,
        (select coalesce(sum(value),0) from won) as won_value,
        (select count(*) from won) as won_count,
        (select count(*) from lost) as lost_count,
        (select coalesce(avg(value),0) from open_deals) as avg_deal,
        (select count(*) from leads where deleted_at is null and status in ('new','contacted')) as new_leads,
        (select count(*) from leads where deleted_at is null) as total_leads,
        (select count(*) from tickets where status not in ('resolved','closed')) as open_tickets,
        (select count(*) from tickets where status not in ('resolved','closed') and sla_due_at < now()) as sla_breaches,
        (select count(*) from tasks where status in ('open','in_progress')) as open_tasks,
        (select count(*) from tasks where status in ('open','in_progress') and due_date < current_date) as overdue_tasks,
        (select coalesce(sum(total - amount_paid),0) from invoices where status in ('sent','partially_paid','overdue')) as outstanding
    `);

    const stages = await t.q(`
      select s.id, s.name, s.position, s.probability, s.is_won, s.is_lost,
             count(d.id)::int as deals, coalesce(sum(d.value),0) as value
        from stages s
        left join deals d on d.stage_id = s.id and d.deleted_at is null
       group by s.id order by s.position`);

    const revenue = await t.q(`
      select to_char(date_trunc('month', coalesce(expected_close_date, updated_at::date)), 'YYYY-MM') as month,
             coalesce(sum(value),0) as value
        from deals
       where status = 'won' and deleted_at is null
         and coalesce(expected_close_date, updated_at::date) > current_date - interval '12 months'
       group by 1 order by 1`);

    const sources = await t.q(`
      select source, count(*)::int as n from leads where deleted_at is null group by 1 order by n desc`);

    const team = await t.q(`
      select u.full_name, count(d.id)::int as won,
             coalesce(sum(d.value),0) as value
        from deals d
        join members m on m.id = d.owner_id
        join users u on u.id = m.user_id
       where d.status = 'won' and d.deleted_at is null
       group by 1 order by value desc`);

    const recent = await t.q(`
      select a.id, a.type, a.subject, a.occurred_at,
             (ct.first_name || ' ' || coalesce(ct.last_name,'')) as contact_name
        from activities a left join contacts ct on ct.id = a.contact_id
       order by a.occurred_at desc limit 8`);

    return { kpi, stages, revenue, sources, team, recent };
  });
}

// ---------------------------------------------------------------- copilot ---
const INTENTS = [
  { key: 'at_risk', match: /(risk|lose|losing|stalled)/i },
  { key: 'stale', match: /(not contacted|no contact|inactive|stale|gone quiet)/i },
  { key: 'qualified', match: /(qualified|hot lead|best lead)/i },
  { key: 'overdue', match: /(overdue|follow.?up task|create tasks)/i },
  { key: 'summary', match: /(summar|brief|tell me about|360)/i },
  { key: 'forecast', match: /(forecast|report|pipeline|revenue|month)/i },
  { key: 'tickets', match: /(ticket|support|sla)/i }
];

export function detectIntent(message) {
  for (const i of INTENTS) if (i.match.test(message)) return i.key;
  return 'forecast';
}

async function gather(ctx, intent, message) {
  return asUser(ctx, async (t) => {
    if (intent === 'at_risk') {
      return t.q(`
        select d.id, d.title, d.value, s.name as stage,
               extract(day from now() - d.stage_changed_at)::int as days_in_stage,
               coalesce(c.name,'—') as company
          from deals d join stages s on s.id = d.stage_id
          left join companies c on c.id = d.company_id
         where d.status = 'open' and d.deleted_at is null
           and (extract(day from now() - d.stage_changed_at) > 14
                or (d.expected_close_date < current_date + 7 and d.probability < 50))
         order by d.value desc limit 10`);
    }
    if (intent === 'stale') {
      return t.q(`
        select c.id, (c.first_name || ' ' || coalesce(c.last_name,'')) as name,
               coalesce(co.name,'—') as company, c.health_score,
               max(a.occurred_at) as last_activity,
               extract(day from now() - coalesce(max(a.occurred_at), c.created_at))::int as days_since
          from contacts c
          left join companies co on co.id = c.company_id
          left join activities a on a.contact_id = c.id
         where c.deleted_at is null
         group by c.id, co.name
        having coalesce(max(a.occurred_at), c.created_at) < now() - interval '7 days'
         order by days_since desc limit 12`);
    }
    if (intent === 'qualified') {
      return t.q(`
        select id, name, company_name, score, status, estimated_value, owner_id
          from leads where deleted_at is null and status in ('qualified','proposal')
         order by score desc nulls last limit 12`);
    }
    if (intent === 'overdue') {
      return t.q(`
        select t.id, t.title, t.due_date, t.priority, u.full_name as assignee
          from tasks t left join members m on m.id = t.assignee_id
          left join users u on u.id = m.user_id
         where t.status in ('open','in_progress') and t.due_date < current_date
         order by t.due_date limit 12`);
    }
    if (intent === 'summary') {
      const contactId = message.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0];
      const rows = await t.q(`
        select c.id, (c.first_name || ' ' || coalesce(c.last_name,'')) as name,
               coalesce(co.name,'—') as company, c.title, c.health_score,
               c.tags, c.consent
          from contacts c left join companies co on co.id = c.company_id
         where c.deleted_at is null ${contactId ? 'and c.id = $1' : ''}
         order by c.health_score asc limit 1`, contactId ? [contactId] : []);
      if (!rows.length) return [];
      const c = rows[0];
      const acts = await t.q(`
        select type, subject, occurred_at from activities
         where contact_id = $1 order by occurred_at desc limit 8`, [c.id]);
      const deals = await t.q(`
        select title, value, status from deals where contact_id = $1 and deleted_at is null`, [c.id]);
      const tickets = await t.q(`
        select number, subject, status, priority from tickets where contact_id = $1`, [c.id]);
      return [{ contact: c, activities: acts, deals, tickets }];
    }
    if (intent === 'tickets') {
      return t.q(`
        select t.number, t.subject, t.priority, t.status,
               case when t.sla_due_at < now() then true else false end as sla_breached,
               u.full_name as assignee
          from tickets t left join members m on m.id = t.assignee_id
          left join users u on u.id = m.user_id
         where t.status not in ('resolved','closed')
         order by case t.priority when 'critical' then 0 when 'high' then 1 else 2 end limit 12`);
    }
    return t.q(`
      select d.id, d.title, d.value, d.probability, s.name as stage, c.name as company
        from deals d join stages s on s.id = d.stage_id
        left join companies c on c.id = d.company_id
       where d.status = 'open' and d.deleted_at is null
       order by d.value * coalesce(d.probability,0) desc limit 12`);
  });
}

function money(n) {
  const v = Number(n || 0);
  if (v >= 1e7) return `₹${(v / 1e7).toFixed(2)} Cr`;
  if (v >= 1e5) return `₹${(v / 1e5).toFixed(1)} L`;
  return `₹${Math.round(v).toLocaleString('en-IN')}`;
}

function composeAnswer(intent, rows, ctx) {
  const n = rows.length;
  switch (intent) {
    case 'at_risk':
      return {
        text: n
          ? `${n} open deal${n === 1 ? '' : 's'} show risk signals — more than 14 days without a stage change, or a close date inside a week with confidence under 50%. Combined value ${money(rows.reduce((a, r) => a + Number(r.value), 0))}.`
          : 'No open deal is currently stalled past 14 days or closing inside a week at low confidence.',
        bullets: rows.map(r => `${r.title} · ${r.company} · ${money(r.value)} · ${r.days_in_stage}d in ${r.stage}`),
        basis: 'Rule: stage_changed_at older than 14 days, or expected_close_date within 7 days with probability below 50. This is a filter over your records, not a prediction.'
      };
    case 'stale':
      return {
        text: n
          ? `${n} contact${n === 1 ? '' : 's'} have no logged activity in the last 7 days. The longest silence is ${rows[0].days_since} days.`
          : 'Every contact has activity logged in the last 7 days.',
        bullets: rows.map(r => `${r.name} · ${r.company} · ${r.days_since}d since last activity · health ${r.health_score}`),
        basis: 'Derived from the activities table. Days counted from the most recent call, email, meeting or note.'
      };
    case 'qualified':
      return {
        text: n
          ? `${n} qualified or proposal-stage lead${n === 1 ? '' : 's'}, worth ${money(rows.reduce((a, r) => a + Number(r.estimated_value), 0))} in estimated value.`
          : 'There are no qualified or proposal-stage leads right now.',
        bullets: rows.map(r => `${r.name} · ${r.company_name} · score ${r.score ?? '—'} · ${money(r.estimated_value)}`),
        basis: 'Leads with status qualified or proposal, ordered by score. Scores are heuristic, not calibrated probabilities.'
      };
    case 'overdue':
      return {
        text: n
          ? `${n} task${n === 1 ? '' : 's'} are past their due date. I can create follow-up tasks for the linked records once you approve.`
          : 'No tasks are overdue.',
        bullets: rows.map(r => `${r.title} · due ${String(r.due_date).slice(0, 10)} · ${r.priority}`),
        basis: 'Tasks with status open or in progress and a due date before today.'
      };
    case 'summary': {
      if (!n) return { text: 'I could not find a contact to summarise.', bullets: [], basis: '' };
      const { contact, activities, deals, tickets } = rows[0];
      return {
        text: `${contact.name} — ${contact.title || 'contact'} at ${contact.company}. Health score ${contact.health_score}. ${deals.length} deal(s), ${tickets.length} ticket(s), ${activities.length} recent activities.`,
        bullets: [
          ...activities.slice(0, 4).map(a => `${a.type}: ${a.subject} (${String(a.occurred_at).slice(0, 10)})`),
          ...deals.map(d => `deal: ${d.title} · ${money(d.value)} · ${d.status}`),
          ...tickets.map(t => `ticket: ${t.number} ${t.subject} · ${t.status}`)
        ],
        basis: 'Composed from recorded activities, deals and tickets. Any interpretation here is yours to verify — the records are the source of truth.'
      };
    }
    case 'tickets':
      return {
        text: n ? `${n} ticket${n === 1 ? '' : 's'} are still open, ${rows.filter(r => r.sla_breached).length} past SLA.` : 'No open tickets.',
        bullets: rows.map(r => `${r.number} · ${r.subject} · ${r.priority} · ${r.assignee || 'unassigned'}`),
        basis: 'Tickets not resolved or closed, ordered by priority.'
      };
    default:
      return {
        text: `Open pipeline: ${money(rows.reduce((a, r) => a + Number(r.value), 0))} across ${n} deals. Weighted by stage probability: ${money(rows.reduce((a, r) => a + Number(r.value) * Number(r.probability || 0) / 100, 0))}.`,
        bullets: rows.slice(0, 6).map(r => `${r.title} · ${r.company} · ${money(r.value)} · ${r.probability}%`),
        basis: 'Weighted value = deal value × stage probability. An estimate, not a commitment.'
      };
  }
}

async function callProvider(systemPrompt, userPrompt) {
  const base = process.env.AI_BASE_URL || 'https://api.openai.com/v1';
  const model = process.env.AI_MODEL || 'gpt-4o-mini';
  const started = Date.now();
  const res = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${process.env.AI_API_KEY}`
    },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
    })
  });
  if (!res.ok) throw new Error(`AI provider ${res.status}: ${(await res.text()).slice(0, 200)}`);
  const json = await res.json();
  return {
    text: json.choices?.[0]?.message?.content || '',
    model,
    provider: base.includes('openai') ? 'openai-compatible' : base,
    latency: Date.now() - started,
    tokensIn: json.usage?.prompt_tokens || 0,
    tokensOut: json.usage?.completion_tokens || 0
  };
}

export async function ask(ctx, message, { contactId } = {}) {
  const intent = detectIntent(message);
  const rows = await gather(ctx, intent, message);
  const local = composeAnswer(intent, rows, ctx);
  const provider = process.env.AI_API_KEY ? 'provider' : 'local';

  let answer = local.text;
  let bullets = local.bullets;
  let basis = local.basis;
  let meta = { provider, model: 'rules+sql', latency: 0, tokensIn: 0, tokensOut: 0, error: null };

  if (provider === 'provider') {
    try {
      const system = [
        'You are Anvaya, a CRM copilot. Answer only from the RECORDS JSON supplied.',
        'If the records do not contain the answer, say so plainly. Never invent names, amounts or dates.',
        'Be concise: at most 4 sentences, then up to 4 bullet points prefixed with "- ".',
        `Workspace currency is ${ctx.currency}. Today is ${new Date().toISOString().slice(0, 10)}.`
      ].join(' ');
      const out = await callProvider(system, `Question: ${message}\n\nRECORDS:\n${JSON.stringify(rows).slice(0, 12000)}`);
      if (out.text) {
        answer = out.text;
        bullets = [];
        basis = 'Generated by the configured model from the records shown. Verify before acting.';
        meta = { provider: out.provider, model: out.model, latency: out.latency, tokensIn: out.tokensIn, tokensOut: out.tokensOut, error: null };
      }
    } catch (err) {
      meta.error = err.message;
      basis = `${local.basis} (Model call failed: ${err.message}. Fell back to the deterministic answer.)`;
    }
  }

  // Proposed writes are stored, never applied, until a human approves.
  const proposed = [];
  if (intent === 'overdue' && rows.length) {
    const action = await asUser(ctx, (t) => t.one(
      `insert into ai_actions (org_id, action, target_table, payload, status)
       values ($1,'create_followup_tasks','tasks',$2,'proposed') returning id, action, status`,
      [ctx.orgId, JSON.stringify({ count: Math.min(rows.length, 5), taskIds: rows.slice(0, 5).map(r => r.id) })]
    ));
    proposed.push(action);
  }

  const run = await asUser(ctx, (t) => t.one(
    `insert into ai_runs (org_id, user_id, agent, provider, model, prompt, response, status, tokens_in, tokens_out, latency_ms)
     values ($1,$2,'copilot',$3,$4,$5,$6,'succeeded',$7,$8,$9) returning id, created_at`,
    [ctx.orgId, ctx.userId, meta.provider, meta.model, message,
      [answer, ...bullets].join('\n'), meta.tokensIn, meta.tokensOut, meta.latency]
  ));

  await writeAudit(ctx, { action: 'ai.copilot', entity: 'ai_run', entityId: run.id, after: { intent, provider: meta.provider } });

  return {
    runId: run.id,
    intent,
    mode: meta.provider,
    answer,
    bullets,
    basis,
    model: meta.model,
    records: rows.length,
    proposedActions: proposed,
    degraded: Boolean(meta.error),
    degradedReason: meta.error || undefined
  };
}

export async function approveAction(ctx, actionId, decision) {
  // Note: the audit write happens after the transaction closes. Writing on the
  // system connection while a transaction is open would deadlock the single
  // PGlite connection.
  const { row, applied } = await asUser(ctx, async (t) => {
    const action = await t.one(`select * from ai_actions where id = $1`, [actionId]);
    if (!action) throw Object.assign(new Error('Action not found'), { status: 404 });
    if (action.status !== 'proposed') throw Object.assign(new Error(`Action already ${action.status}`), { status: 409 });

    if (decision === 'reject') {
      const rejected = await t.one(
        `update ai_actions set status='rejected', approved_by=$2 where id=$1 returning *`,
        [actionId, ctx.userId]
      );
      return { row: rejected, applied: false };
    }

    if (action.action === 'create_followup_tasks') {
      const ids = (action.payload || {}).taskIds || [];
      for (const taskId of ids) {
        const src = await t.one(`select title, assignee_id, related_type, related_id from tasks where id = $1`, [taskId]);
        if (!src) continue;
        await t.q(
          `insert into tasks (org_id, title, notes, due_date, priority, assignee_id, related_type, related_id, created_by)
           values ($1,$2,$3, current_date + 2, 'high', $4, $5, $6, $7)`,
          [ctx.orgId, `Follow up: ${src.title}`, 'Created from an approved copilot suggestion.',
            src.assignee_id, src.related_type, src.related_id, ctx.userId]
        );
      }
    }

    const updated = await t.one(
      `update ai_actions set status='applied', approved_by=$2, applied_at=now() where id=$1 returning *`,
      [actionId, ctx.userId]
    );
    return { row: updated, applied: true };
  });

  await writeAudit(ctx, {
    action: applied ? 'ai.action_applied' : 'ai.action_rejected',
    entity: 'ai_action', entityId: actionId, after: row
  });
  return row;
}

export async function recentRuns(ctx, limit = 20) {
  return asUser(ctx, (t) => t.q(
    `select id, agent, provider, model, prompt, status, tokens_in, tokens_out, latency_ms, created_at
       from ai_runs order by created_at desc limit $1`, [limit]
  ));
}
