import pg from 'pg';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false }
});

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$16384$8$1$${salt}$${hash}`;
}

async function main() {
  console.log('[setup] Connecting to Supabase database...');
  await pool.query('select 1');
  console.log('[setup] Connected successfully to Supabase!');

  console.log('[setup] Resetting public schema for pristine installation...');
  await pool.query('drop schema if exists public cascade; create schema public;');
  await pool.query('grant usage on schema public to authenticated, anon, service_role; grant create on schema public to postgres, authenticated, service_role;');

  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const migrationsDir = path.join(__dirname, '../db/migrations');
  
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    console.log(`[setup] Applying migration: ${file}...`);
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    try {
      await pool.query(sql);
      console.log(`[setup] Applied ${file}`);
    } catch (err) {
      console.error(`[setup] Error in ${file}:`, err.message);
      throw err;
    }
  }

  console.log('[setup] Running database seed...');
  const email = 'sneha@brightline.in';
  const passwordHash = hashPassword('AnvayaDemo2026');

  const client = await pool.connect();
  try {
    await client.query('begin');

    const userRes = await client.query(
      `insert into users (email, password_hash, full_name, email_verified_at)
       values ($1, $2, $3, now()) returning id`,
      [email, passwordHash, 'Snehasis Saha']
    );
    const userId = userRes.rows[0].id;

    const orgRes = await client.query(
      `insert into organisations (name, slug, industry, currency, timezone, plan)
       values ('Brightline Security Solutions', 'brightline-security', 'Security systems integrator', 'INR', 'Asia/Kolkata', 'professional')
       returning id`
    );
    const orgId = orgRes.rows[0].id;

    const wsRes = await client.query(
      `insert into workspaces (org_id, name, slug, is_default) values ($1, 'Brightline Security', 'default', true) returning id`,
      [orgId]
    );
    const wsId = wsRes.rows[0].id;

    const roleRes = await client.query(
      `insert into roles (org_id, key, name, description, permissions, is_system)
       values ($1, 'owner', 'Owner', 'Full access', '{*}'::text[], true) returning id`,
      [orgId]
    );
    const roleId = roleRes.rows[0].id;

    await client.query(
      `insert into members (org_id, user_id, role_id, workspace_id, status, title, joined_at)
       values ($1, $2, $3, $4, 'active', 'Managing Director', now())`,
      [orgId, userId, roleId, wsId]
    );

    const pipelineRes = await client.query(
      `insert into pipelines (org_id, name, is_default) values ($1, 'Sales pipeline', true) returning id`,
      [orgId]
    );
    const pipelineId = pipelineRes.rows[0].id;

    const stages = [
      ['Discovery', 1, 20, false, false],
      ['Site survey', 2, 35, false, false],
      ['Proposal sent', 3, 55, false, false],
      ['Negotiation', 4, 75, false, false],
      ['Closed won', 5, 100, true, false],
      ['Closed lost', 6, 0, false, true]
    ];

    for (const [name, pos, prob, won, lost] of stages) {
      await client.query(
        `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
         values ($1, $2, $3, $4, $5, $6, $7)`,
        [orgId, pipelineId, name, pos, prob, won, lost]
      );
    }

    await client.query('commit');
    console.log('[setup] Supabase database setup and seeding completed successfully!');
  } catch (err) {
    await client.query('rollback');
    console.error('[setup] Seeding failed:', err);
    throw err;
  } finally {
    client.release();
  }

  await pool.end();
}

main().catch(err => {
  console.error('[setup] Fatal error:', err);
  process.exit(1);
});
