-- ============================================================================
-- Anvaya — 05 functions
--
-- The logic that cannot live in a REST query: transactions, numbering,
-- recalculation, aggregation. With these in the database, a frontend can talk
-- to Supabase directly and still get correct behaviour, with no Express server
-- in between.
--
-- Every function is SECURITY INVOKER on purpose: the caller's JWT decides what
-- they can touch, and row-level security applies inside the function exactly as
-- it does outside. There is no privileged back door here.
-- ============================================================================

-- ---------------------------------------------------------------- numbering --
create or replace function app.next_number(p_type text)
returns text
language plpgsql
as $$
declare
  v_prefix text;
  v_seq int;
  v_pad int;
  v_year text := to_char(now(), 'YYYY');
begin
  if app.current_org() is null then
    raise exception 'No organisation in context';
  end if;

  insert into document_sequences (org_id, doc_type, prefix, next_number)
  values (app.current_org(), p_type,
          case p_type when 'invoice' then 'INV' when 'quotation' then 'QTN'
                      when 'credit_note' then 'CRN' when 'receipt' then 'RCT'
                      else upper(left(p_type, 3)) end,
          2)
  on conflict (org_id, doc_type)
    do update set next_number = document_sequences.next_number + 1
  returning prefix, next_number - 1, padding into v_prefix, v_seq, v_pad;

  return v_prefix || '-' || v_year || '-' || lpad(v_seq::text, v_pad, '0');
end $$;

-- --------------------------------------------------------------- invoices ----
-- Totals are computed here, never sent by the client.
create or replace function app.recalculate_invoice(p_invoice uuid)
returns jsonb
language plpgsql
as $$
declare
  v_inv invoices%rowtype;
  v_paid numeric := 0;
  v_refunded numeric := 0;
  v_credited numeric := 0;
  v_outstanding numeric;
  v_status text;
begin
  select * into v_inv from invoices where id = p_invoice;
  if not found then
    raise exception 'Invoice % not found', p_invoice using errcode = 'P0002';
  end if;

  select coalesce(sum(amount), 0) into v_paid
    from payments where invoice_id = p_invoice and status = 'succeeded';

  select coalesce(sum(r.amount), 0) into v_refunded
    from refunds r join payments p on p.id = r.payment_id
   where p.invoice_id = p_invoice and r.status = 'processed';

  select coalesce(sum(amount), 0) into v_credited
    from credit_notes where invoice_id = p_invoice and status <> 'void';

  v_paid := greatest(v_paid - v_refunded, 0);
  v_outstanding := greatest(round(v_inv.total - v_paid - v_credited, 2), 0);

  v_status := case
    when v_outstanding <= 0.009 then 'paid'
    when v_paid > 0 then 'partially_paid'
    when v_inv.due_date is not null and v_inv.due_date < current_date then 'overdue'
    when v_inv.status = 'draft' then 'draft'
    else 'sent'
  end;

  update invoices
     set amount_paid = v_paid, credited_amount = v_credited, status = v_status, updated_at = now()
   where id = p_invoice;

  return jsonb_build_object(
    'amount', v_inv.total, 'paid', v_paid, 'credited', v_credited,
    'outstanding', v_outstanding, 'status', v_status, 'currency', v_inv.currency
  );
end $$;

create or replace function app.create_invoice(
  p_items jsonb,
  p_contact uuid default null,
  p_company uuid default null,
  p_tax_mode text default 'cgst_sgst',
  p_discount numeric default 0,
  p_due_date date default null,
  p_notes text default null
) returns jsonb
language plpgsql
as $$
declare
  v_item jsonb;
  v_gross numeric := 0;
  v_tax numeric := 0;
  v_subtotal numeric := 0;
  v_total numeric;
  v_line_taxable numeric;
  v_qty numeric;
  v_rate numeric;
  v_tax_rate numeric;
  v_disc numeric;
  v_number text;
  v_id uuid;
  v_pos int := 0;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'An invoice needs at least one line item' using errcode = '22023';
  end if;

  v_number := app.next_number('invoice');

  insert into invoices (org_id, contact_id, company_id, number, status, issue_date, due_date,
                        total, subtotal, tax_total, discount_total, currency, tax_mode, notes, amount_paid)
  values (app.current_org(), p_contact, p_company, v_number, 'sent', current_date,
          coalesce(p_due_date, current_date + 15), 0, 0, 0, coalesce(p_discount, 0), 'INR', p_tax_mode, p_notes, 0)
  returning id into v_id;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_pos := v_pos + 1;
    v_qty := coalesce((v_item->>'quantity')::numeric, 1);
    v_rate := coalesce((v_item->>'unit_price')::numeric, 0);
    v_tax_rate := coalesce((v_item->>'tax_rate')::numeric, 0);
    v_disc := coalesce((v_item->>'discount')::numeric, 0);

    v_gross := v_gross + v_qty * v_rate;
    v_line_taxable := greatest(v_qty * v_rate - v_disc, 0);
    v_subtotal := v_subtotal + v_line_taxable;
    v_tax := v_tax + round(v_line_taxable * v_tax_rate, 2) / 100;

    insert into invoice_items (org_id, invoice_id, description, qty, unit_price, tax_rate, line_total, position)
    values (app.current_org(), v_id, coalesce(v_item->>'description', 'Item'),
            v_qty, v_rate, v_tax_rate, v_line_taxable, v_pos);
  end loop;

  -- An order-level discount reduces the taxable value, so tax follows it.
  if coalesce(p_discount, 0) > 0 and v_subtotal > 0 then
    v_tax := round(v_tax * greatest(v_subtotal - p_discount, 0) / v_subtotal, 2);
  end if;

  v_total := round(v_subtotal - coalesce(p_discount, 0) + v_tax, 2);

  update invoices
     set subtotal = v_subtotal, tax_total = v_tax, total = v_total
   where id = v_id;

  return jsonb_build_object(
    'id', v_id, 'number', v_number, 'subtotal', v_subtotal,
    'tax_total', v_tax, 'discount_total', coalesce(p_discount, 0), 'total', v_total,
    'balance', app.recalculate_invoice(v_id)
  );
end $$;

-- ------------------------------------------------------------ lead convert ---
-- One call does what the "Turn into deal" button does: company, contact, deal
-- and an activity, atomically.
create or replace function app.convert_lead(p_lead uuid)
returns jsonb
language plpgsql
as $$
declare
  v_lead leads%rowtype;
  v_company uuid;
  v_contact uuid;
  v_deal uuid;
  v_pipeline uuid;
  v_stage uuid;
begin
  select * into v_lead from leads where id = p_lead;
  if not found then
    raise exception 'Lead % not found', p_lead using errcode = 'P0002';
  end if;
  if v_lead.converted_deal_id is not null then
    raise exception 'That lead has already been converted' using errcode = '23505';
  end if;

  if v_lead.company_name is not null then
    select id into v_company from companies where lower(name) = lower(v_lead.company_name) limit 1;
    if v_company is null then
      insert into companies (org_id, name, owner_id)
      values (app.current_org(), v_lead.company_name, v_lead.owner_id)
      returning id into v_company;
    end if;
  end if;

  if v_lead.email is not null then
    select id into v_contact from contacts where lower(email) = lower(v_lead.email) limit 1;
  end if;
  if v_contact is null then
    insert into contacts (org_id, first_name, last_name, email, phone, company_id, owner_id)
    values (app.current_org(),
            split_part(coalesce(v_lead.name, 'Unknown'), ' ', 1),
            nullif(substr(coalesce(v_lead.name, ''), position(' ' in coalesce(v_lead.name, '')) + 1), ''),
            v_lead.email, v_lead.phone, v_company, v_lead.owner_id)
    returning id into v_contact;
  end if;

  select id into v_pipeline from pipelines where is_default = true limit 1;
  select id into v_stage from stages where pipeline_id = v_pipeline order by position limit 1;

  insert into deals (org_id, pipeline_id, stage_id, company_id, contact_id, title, value, owner_id,
                     probability, expected_close_date, status, source_lead_id)
  values (app.current_org(), v_pipeline, v_stage, v_company, v_contact,
          coalesce(v_lead.company_name, v_lead.name, 'New deal'),
          coalesce(v_lead.estimated_value, 0), v_lead.owner_id,
          coalesce((select probability from stages where id = v_stage), 20),
          current_date + 30, 'open', v_lead.id)
  returning id into v_deal;

  insert into activities (org_id, type, subject, body, contact_id, company_id, deal_id, occurred_at)
  values (app.current_org(), 'note', 'Lead converted',
          'Created from the lead: ' || coalesce(v_lead.name, ''), v_contact, v_company, v_deal, now());

  update leads
     set status = 'converted', converted_contact_id = v_contact, converted_deal_id = v_deal
   where id = p_lead;

  return jsonb_build_object('contact_id', v_contact, 'company_id', v_company, 'deal_id', v_deal);
end $$;

-- ---------------------------------------------------------------- dashboard --
-- One round trip instead of six, for the home screen.
create or replace function app.dashboard()
returns jsonb
language sql
stable
as $$
  with d as (
    select * from deals
  )
  select jsonb_build_object(
    'open_deals', (select count(*) from d where status = 'open'),
    'pipeline_value', (select coalesce(sum(value), 0) from d where status = 'open'),
    'won_value', (select coalesce(sum(value), 0) from d where status = 'won'),
    'won_count', (select count(*) from d where status = 'won'),
    'new_leads', (select count(*) from leads where status = 'new'),
    'open_tickets', (select count(*) from tickets where resolved_at is null),
    'sla_breaches', (select count(*) from tickets where resolved_at is null and sla_due_at < now()),
    'open_tasks', (select count(*) from tasks where status <> 'done'),
    'overdue_tasks', (select count(*) from tasks where status <> 'done' and due_date < current_date),
    'outstanding', (select coalesce(sum(total - amount_paid - credited_amount), 0)
                      from invoices where status <> 'paid')
  )
$$;

-- ------------------------------------------------------------- permissions ---
grant execute on function app.next_number(text) to authenticated;
grant execute on function app.recalculate_invoice(uuid) to authenticated;
grant execute on function app.create_invoice(jsonb, uuid, uuid, text, numeric, date, text) to authenticated;
grant execute on function app.convert_lead(uuid) to authenticated;
grant execute on function app.dashboard() to authenticated;
