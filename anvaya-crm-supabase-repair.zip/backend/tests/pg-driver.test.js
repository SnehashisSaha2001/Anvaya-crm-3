// Proves the backend runs unchanged on the `pg` code path, which is the one
// Supabase uses. The shim supplies the client; every query, transaction and
// SET LOCAL ROLE below is the production code.

process.env.PG_SHIM = '1';
process.env.DB_USER_ROLE = 'app_user';   // the local migrations create this role
process.env.ENCRYPTION_KEY = 'test-encryption-key-32-characters-long';

import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { boot, shutdown, registerOrg, client } from './helpers.js';
import { driver, q, asUser, one } from '../src/db.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

describe('postgres driver', () => {
  test('the pg adapter is the one in use', () => {
    assert.equal(driver(), 'pg');
  });

  test('migrations ran through the adapter', async () => {
    const t = await q(`select count(*)::int n from information_schema.tables where table_schema='public'`);
    assert.ok(t[0].n >= 51, `expected the full schema, found ${t[0].n} tables`);
  });

  test('a full request works: register, create a lead, read it back', async () => {
    const { api } = await registerOrg({ name: 'PG Co' });
    const made = await api('/api/leads', { body: { name: 'Driver Lead', company_name: 'Acme' } });
    assert.equal(made.status, 201);
    const list = await api('/api/leads');
    assert.equal(list.body.total, 1);
  });

  test('RLS still isolates tenants through SET LOCAL ROLE', async () => {
    const a = await registerOrg({ name: 'Tenant A' });
    const b = await registerOrg({ name: 'Tenant B' });
    await a.api('/api/leads', { body: { name: 'A only' } });
    await b.api('/api/leads', { body: { name: 'B only' } });

    const seenA = await a.api('/api/leads');
    assert.deepEqual(seenA.body.data.map((r) => r.name), ['A only']);
    const seenB = await b.api('/api/leads');
    assert.deepEqual(seenB.body.data.map((r) => r.name), ['B only']);
  });

  test('a failed transaction rolls back instead of half-writing', async () => {
    const { org, email } = await registerOrg({ name: 'Rollback Co' });
    const user = await one(`select id from users where email = $1`, [email]);
    const ctx = { orgId: org.id, userId: user.id, perms: ['*'] };

    const before = await q(`select count(*)::int n from leads`);

    await assert.rejects(
      () => asUser(ctx, async (t) => {
        await t.q(`insert into leads (org_id, name) values ($1,'Should vanish')`, [ctx.orgId]);
        throw new Error('deliberate failure after the write');
      }),
      /deliberate failure/
    );

    const after = await q(`select count(*)::int n from leads`);
    assert.equal(after[0].n, before[0].n, 'the insert must be rolled back');
  });
});
