// Live Supabase checks. These only run when DATABASE_URL is set, because they
// talk to a real database over the wire — the one thing the rest of the suite
// cannot prove.
//
//   DATABASE_URL="postgresql://postgres.<ref>:<pass>@aws-0-<region>.pooler.supabase.com:6543/postgres" \
//     npm run test:live
//
// Read-only by default. Set LIVE_WRITE=1 to also create and remove one test
// account, which is the only way to prove registration end-to-end on that
// project.

process.env.NODE_ENV = 'test';

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

const hasUrl = Boolean((process.env.DATABASE_URL || '').trim());
const skip = hasUrl ? false : 'DATABASE_URL is not set — live Supabase checks skipped';

let db;
let runChecks;
let closeDb;

describe('live Supabase', () => {
  before(async () => {
    if (!hasUrl) return;
    db = await import('../src/db.js');
    ({ runChecks } = await import('../scripts/check-supabase.mjs'));
    await db.initDb();
    closeDb = db.closeDb;
  });
  after(async () => { if (closeDb) await closeDb(); });

  test('connects over the wire with the pg driver', { skip }, async () => {
    assert.equal(db.driver(), 'pg');
    const check = await db.verifyConnection();
    assert.equal(check.ok, true, JSON.stringify(check.error));
    console.log(`connected: ${check.database} as ${check.user} (${check.latencyMs}ms, ${check.version})`);
  });

  test('the connection doctor passes every check', { skip }, async () => {
    const results = await runChecks(db.db(), { log: () => {} });
    const failed = results.filter((r) => !r.pass);
    assert.deepEqual(failed.map((r) => `${r.name}: ${r.detail}`), []);
  });

  test('health reports the live database, not a cache', { skip }, async () => {
    const { getHealth } = await import('../src/health.js');
    const payload = await getHealth();
    assert.equal(payload.status, 'ok', JSON.stringify(payload.problems));
    assert.equal(payload.connectionStatus.state, 'connected');
    assert.equal(payload.driver, 'pg');
    assert.equal(payload.migrationStatus.state, 'up-to-date');
    assert.doesNotMatch(JSON.stringify(payload), /postgres(ql)?:\/\//i);
  });

  test('registration creates a real user, organisation and workspace', { skip: skip || (process.env.LIVE_WRITE === '1' ? false : 'set LIVE_WRITE=1 to allow a write test') }, async () => {
    const { createApp } = await import('../src/app.js');
    const app = createApp();
    const server = app.listen(0);
    await new Promise((r) => server.once('listening', r));
    const base = `http://127.0.0.1:${server.address().port}`;
    const email = `live.test.${Date.now()}.${crypto.randomBytes(2).toString('hex')}@example.test`;

    try {
      const res = await fetch(`${base}/api/auth/register`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          email, password: 'LiveTestPassword123', fullName: 'Live Test', orgName: 'Live Test Co'
        })
      });
      const body = await res.json();
      assert.equal(res.status, 201, JSON.stringify(body));

      const user = await db.one('select id from users where email = $1', [email]);
      assert.ok(user, 'the user row is in the live database');
      const org = await db.one('select id from organisations where id = $1', [body.org.id]);
      assert.ok(org, 'the organisation row is in the live database');
      const ws = await db.one('select id from workspaces where org_id = $1', [body.org.id]);
      assert.ok(ws, 'the workspace row is in the live database');

      // Clean up only what this test created.
      await db.q('delete from organisations where id = $1', [body.org.id]);
      await db.q('delete from users where id = $1', [user.id]);
      console.log(`live registration verified and removed: ${email}`);
    } finally {
      await new Promise((r) => server.close(r));
    }
  });
});
