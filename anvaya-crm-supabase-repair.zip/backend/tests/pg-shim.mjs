// A stand-in for `pg` that speaks the same API over PGlite.
//
// It exists so the PostgreSQL code path in src/db.js — transactions, SET LOCAL
// ROLE, set_config, multi-statement exec — is exercised by the test suite
// without needing a database server. The wire protocol is the only thing this
// does not prove; everything above it is the same code that runs on Supabase.

import { PGlite } from '@electric-sql/pglite';

let shared;

// `pg` sends a parameterless query through the simple protocol, which accepts
// several statements. PGlite's query() prepares one statement, so fall back to
// exec() for the multi-statement case (migrations) and report no rows.
async function run(p, sql, params) {
  if (params !== undefined) return p.query(sql, params);
  try {
    return await p.query(sql);
  } catch (err) {
    if (!/cannot insert multiple commands/i.test(err.message)) throw err;
    await p.exec(sql);
    return { rows: [] };
  }
}

export class Pool {
  constructor() {
    if (!shared) shared = new PGlite();
    this.p = shared;
    this.ready = shared.waitReady;
  }

  async query(sql, params) {
    await this.ready;
    return run(this.p, sql, params);
  }

  async connect() {
    await this.ready;
    const p = this.p;
    return {
      query: (sql, params) => run(p, sql, params),
      release: () => {}
    };
  }

  async end() {
    if (shared) { await shared.close(); shared = null; }
  }
}
