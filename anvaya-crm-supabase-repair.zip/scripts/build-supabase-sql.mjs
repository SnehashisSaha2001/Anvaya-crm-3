#!/usr/bin/env node
// Generates supabase/anvaya-supabase.sql from backend/db/migrations/*.sql.
//
// Why this exists: the project shipped two different schemas — the migration
// set the backend queries, and a hand-maintained "paste this into Supabase"
// file. They disagreed (the paste-file had no `sessions` table, no
// `subscriptions`, 29 tables instead of 51), so an operator who followed the
// Supabase instructions got a database on which registration and login could
// never work. There is now one source of truth and this file is a build
// artefact of it.
//
//   node scripts/build-supabase-sql.mjs           write the file
//   node scripts/build-supabase-sql.mjs --check   fail if it is out of date

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const MIGRATIONS = path.join(ROOT, 'backend', 'db', 'migrations');
const OUT = path.join(ROOT, 'supabase', 'anvaya-supabase.sql');

const files = fs.readdirSync(MIGRATIONS).filter((f) => f.endsWith('.sql')).sort();
if (!files.length) {
  console.error('no migrations found in', MIGRATIONS);
  process.exit(1);
}

const header = `-- ============================================================================
-- ANVAYA CRM — complete Supabase schema
--
-- GENERATED FILE — do not edit. Source: backend/db/migrations/*.sql
-- Regenerate with: node scripts/build-supabase-sql.mjs
--
-- How to use it: Supabase → SQL Editor → New query → paste this whole file →
-- Run. It is idempotent (create table if not exists / add column if not
-- exists), so running it twice is harmless and it will not drop data.
--
-- It contains no seed data and no demo account. Create your account through
-- the app's registration page, which writes a real user, organisation and
-- workspace.
--
-- Migrations included: ${files.join(', ')}
-- ============================================================================

`;

const body = files.map((file) => {
  const sql = fs.readFileSync(path.join(MIGRATIONS, file), 'utf8');
  const digest = crypto.createHash('sha256').update(sql).digest('hex').slice(0, 12);
  return `\n-- ---------------------------------------------------------------------------\n`
    + `-- ${file}  (sha256:${digest})\n`
    + `-- ---------------------------------------------------------------------------\n\n`
    + sql.trimEnd() + '\n';
}).join('');

const output = header + body;
const existing = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8') : '';

if (process.argv.includes('--check')) {
  if (existing !== output) {
    console.error('[supabase-sql] out of date — run: node scripts/build-supabase-sql.mjs');
    process.exit(1);
  }
  console.log('[supabase-sql] up to date');
  process.exit(0);
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, output);
console.log(`[supabase-sql] wrote ${path.relative(ROOT, OUT)} (${output.length} bytes, ${files.length} migrations)`);
