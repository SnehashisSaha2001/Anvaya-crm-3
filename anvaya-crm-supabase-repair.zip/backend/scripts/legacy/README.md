# Legacy scripts — do not use

These files are kept only so nothing is silently lost. **None of them is part of
the application**, none is referenced by `package.json`, and several of them are
actively harmful on a production database:

| File | Why it is here |
| --- | --- |
| `disable-rls.js` | Runs `ALTER TABLE … DISABLE ROW LEVEL SECURITY` on every table. This removes tenant isolation. Never run it. |
| `grant-permissions.js` | Grants `ALL` on every table to `anon`. An anonymous Supabase key would then read the whole database. |
| `setup-supabase-complete.js`, `init-supabase-db.js` | Earlier attempts at "just make it connect": they create their own ad-hoc schema, which is what produced the schema drift between `supabase/*.sql` and `backend/db/migrations/*`. |
| `auth-debug.js`, `check-connection.js`, `test-dashboard.js`, `test-db.js`, `test-ipv4.js`, `test-login-api.js`, `test-login-me.js`, `test-register.js` | One-off debugging scripts written while chasing the connection failures. They hardcoded database passwords; those literals have been removed. |

## What replaced them

```bash
# one canonical schema, versioned and verified
npm run db:migrate          # apply + verify, exits non-zero on failure
npm run db:check            # report state, change nothing
npm run db:doctor           # 11-point connectivity/schema/RLS diagnosis
```

The canonical schema is `backend/db/migrations/*.sql`. `supabase/anvaya-supabase.sql`
is generated from it and must not be edited by hand.
