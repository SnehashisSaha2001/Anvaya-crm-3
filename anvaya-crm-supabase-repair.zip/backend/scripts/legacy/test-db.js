import pkg from 'pg';
const { Pool } = pkg;

const connectionString = process.env.DATABASE_URL;

console.log('--------------------------------------------------');
console.log('Supabase Database Diagnostic Tool');
console.log('Target URL:', connectionString.replace(/:[^:@]+@/, ':****@'));
console.log('--------------------------------------------------');

async function testConnection() {
  const pool = new Pool({
    connectionString,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 8000
  });

  try {
    console.log('[1/2] Attempting connection to Supabase PostgreSQL...');
    const start = Date.now();
    const res = await pool.query('SELECT version(), current_database(), current_user');
    const duration = Date.now() - start;

    console.log('[SUCCESS] Connected successfully in', duration, 'ms');
    console.log('  Database version:', res.rows[0].version);
    console.log('  Current database:', res.rows[0].current_database);
    console.log('  Current user:', res.rows[0].current_user);

    const tables = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `);
    console.log('  Public tables found:', tables.rows.map(r => r.table_name).join(', ') || 'None');

  } catch (err) {
    console.error('\n[FAILURE] Connection failed!');
    console.error('Error Code:', err.code || 'UNKNOWN');
    console.error('Error Message:', err.message);
    if (err.code === '28P01') {
      console.error('Diagnosis: Authentication failed (incorrect database password or username).');
    } else if (err.code === 'ECONNREFUSED' || err.code === 'ETIMEDOUT' || err.code === 'EAI_AGAIN') {
      console.error('Diagnosis: Network / firewall restriction or DNS issue preventing TCP connection to port 5432.');
    } else if (err.message && err.message.includes('SSL')) {
      console.error('Diagnosis: SSL handshake error. Check SSL mode and certificate settings.');
    } else {
      console.error('Diagnosis: General connection error or unreachable host.');
    }
  } finally {
    await pool.end();
    console.log('--------------------------------------------------');
  }
}

testConnection();
