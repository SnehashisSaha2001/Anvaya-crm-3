#!/usr/bin/env node
// Environment verification.
//
//   node scripts/verify-env.js           check the current environment
//   node scripts/verify-env.js --build   strict: fail the build on a problem
//
// It reads process.env only. On Vercel, a local .env file is NOT present, so
// reading one here would report a false pass. The password is never printed.
//
// Exit codes: 0 ok / warnings only, 1 error (with --build), 2 error.

import { describeDatabaseUrl, provider, pgliteAllowed, isProduction } from '../backend/src/db.js';

const strict = process.argv.includes('--build');
const problems = [];
const warnings = [];

const line = (label, value) => console.log(`  ${label.padEnd(22)} ${value}`);

console.log('Anvaya CRM — environment verification\n');

/* ------------------------------------------------------------------ mode --- */
line('NODE_ENV', process.env.NODE_ENV || '(unset)');
line('VERCEL', process.env.VERCEL ? `yes (${process.env.VERCEL_ENV || 'unknown env'})` : 'no');
line('driver', describeDatabaseUrl().configured ? 'pg (PostgreSQL)' : pgliteAllowed() ? 'pglite (local only)' : 'none');
line('provider', provider());

/* -------------------------------------------------------------- database --- */
const info = describeDatabaseUrl();
if (!info.configured) {
  problems.push('DATABASE_URL is not set — the API will answer 503 and nothing can register or sign in.');
} else if (info.malformed) {
  problems.push('DATABASE_URL is not a valid postgresql:// URL.');
} else {
  line('database host', info.host);
  line('database port', info.port);
  line('database name', info.database);
  line('database user', info.user);
  line('connection mode', info.pooler ? 'pooler' : info.direct ? 'direct' : 'other');

  if (info.direct && (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME)) {
    problems.push(
      'DATABASE_URL uses the direct Supabase host (db.<ref>.supabase.co) on a serverless platform. '
      + 'That endpoint is IPv6-only and fails intermittently from Vercel. Use the pooler: '
      + 'aws-0-<region>.pooler.supabase.com:6543.'
    );
  }
  if (/@/.test(process.env.DATABASE_URL.split('@')[0]?.split('://')[1] || '') === false && !info.user) {
    warnings.push('DATABASE_URL has no username.');
  }
  if (info.pooler && info.port === 5432) {
    warnings.push('Pooler host on port 5432 is session mode: fine for a server, heavy for serverless. '
      + 'Use 6543 (transaction mode) on Vercel.');
  }
}

/* --------------------------------------------------------- required vars --- */
for (const key of ['DB_USER_ROLE']) {
  if (!process.env[key]) warnings.push(`${key} is unset; defaulting to "authenticated".`);
}
if (isProduction && !process.env.ENCRYPTION_KEY) {
  warnings.push('ENCRYPTION_KEY is unset: stored provider tokens and MFA secrets cannot be encrypted.');
}
if (process.env.ENCRYPTION_KEY && process.env.ENCRYPTION_KEY.length < 32) {
  problems.push('ENCRYPTION_KEY must be at least 32 characters.');
}

/* -------------------------------------------------------- leaked secrets --- */
const frontendLeak = Object.keys(process.env).filter(
  (k) => /^(VITE_|NEXT_PUBLIC_|PUBLIC_)/.test(k) && /(DATABASE|SUPABASE_SERVICE|SECRET|PASSWORD|ENCRYPTION)/i.test(k)
);
if (frontendLeak.length) {
  problems.push(`These variables are exposed to the browser bundle and must not hold secrets: ${frontendLeak.join(', ')}`);
}

/* ------------------------------------------------------------ local files --- */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
if (process.env.VERCEL && fs.existsSync(path.join(ROOT, '.env'))) {
  warnings.push('A .env file is present in the deployment. Vercel does not read it; set variables in the dashboard.');
}
if (fs.existsSync(path.join(ROOT, 'cookies.txt'))) {
  warnings.push('cookies.txt is present in the repository — it holds a live session token. Delete it.');
}

/* ---------------------------------------------------------------- report --- */
console.log('');
for (const w of warnings) console.log(`  WARN  ${w}`);
for (const p of problems) console.log(`  ERROR ${p}`);

if (!problems.length) {
  console.log(`\n  ${warnings.length ? 'OK with warnings' : 'OK'} — configuration looks usable.\n`);
  process.exit(0);
}
console.log(`\n  ${problems.length} problem(s) found.\n`);
process.exit(strict ? 1 : 2);
