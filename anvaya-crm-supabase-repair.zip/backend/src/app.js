// HTTP API.

import express from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { q, one, tx, asUser, DbUnavailableError, TenantContextError, explainDbError } from './db.js';
import {
  hashPassword, verifyPassword, dummyVerify, validatePassword, createSession, createSessionIn,
  destroySession, setSessionCookie, setOrgCookie, setWorkspaceCookie, clearSessionCookie,
  requireAuth, requirePerm, requirePlatformAdmin, loadContext
} from './auth.js';
import { getHealth, getDiagnostics } from './health.js';
import { rateLimit, clientIp, originGuard } from './security.js';
import { ROLE_TEMPLATES, rolePayload, can } from './permissions.js';
import {
  RESOURCES, listResource, getResource, createResource, updateResource, deleteResource
} from './resources.js';
import { dashboard, ask, approveAction, recentRuns } from './intelligence.js';
import { trigger, listRuns, runSteps, TRIGGER_EVENTS, ACTION_TYPES } from './workflows.js';
import { writeAudit, listAudit } from './audit.js';
import { mountGrowth, dispatchEvent } from './growth.js';
import { mountIntegrations } from './integrations.js';
import { mountMfa } from './mfa.js';
import { mountDocuments } from './documents.js';
import { mountFinance } from './finance.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_DIR = process.env.WEB_DIR
  ? path.resolve(process.env.WEB_DIR)
  : path.join(__dirname, '..', '..');

// Only these files are public. Serving the repo root wholesale would expose
// backend source, the migrations and the environment template.
const PUBLIC_FILES = new Set([
  'index.html', 'app.js', 'engine.js', 'data.js', 'offline.js', 'idb.js', 'sync.js', 'pwa.js',
  'styles.css', 'manifest.webmanifest', 'sw.js', 'favicon.ico'
]);

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({
    limit: '1mb',
    verify: (req, res, buf) => { req.rawBody = buf; }   // needed to verify HMAC signatures
  }));
  app.disable('x-powered-by');

  // Cross-origin use is opt-in. Reflecting whatever Origin arrives while also
  // allowing credentials lets any site drive this API with a user's cookies.
  const corsOrigins = (process.env.CORS_ORIGIN || '')
    .split(',').map((v) => v.trim()).filter(Boolean);
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && corsOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
    }
    res.setHeader('Access-Control-Allow-Headers', 'content-type, authorization, x-requested-with, x-api-key');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  // Cross-site request protection for cookie-authenticated state changes.
  app.use('/api', originGuard);

  const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
  const bad = (message, status = 400) => Object.assign(new Error(message), { status });

  // Growth + integration routes register first: the API-key middleware they
  // install has to run before any requireAuth() route below.
  mountGrowth(app, { wrap, bad });
  mountIntegrations(app, { wrap, bad });
  mountMfa(app, { wrap, bad });
  mountDocuments(app, { wrap, bad });
  mountFinance(app, { wrap, bad });

  // ------------------------------------------------------------- health ---
  // The static app probes this at boot, and so do uptime monitors. `mode:
  // 'server'` is only set when a real query against the real database just
  // succeeded and the schema the app needs is present.
  app.get('/api/health', wrap(async (req, res) => {
    const health = await getHealth();
    const status = health.status === 'ok' ? 200 : health.status === 'degraded' ? 200 : 503;
    res.status(status).json(health);
  }));

  // Administrator-only deep diagnostics: same safe shape, more detail.
  const diagGuard = (req, res, next) => {
    const token = process.env.DIAGNOSTICS_TOKEN;
    if (token && req.headers['x-diag-token'] === token) return next();
    return requireAuth(req, res, () => requirePlatformAdmin(req, res, next));
  };
  app.get('/api/health/diagnostics', diagGuard, wrap(async (req, res) => {
    const diag = await getDiagnostics();
    res.status(diag.health.status === 'unavailable' ? 503 : 200).json(diag);
  }));

  // --------------------------------------------------------------- auth ---
  // Login and registration are the two operations that must never lie. Both
  // rate limit, both write real rows, both fail loudly.
  // Limits are per instance and configurable, because a shared office NAT and
  // a CI suite both legitimately exceed a per-IP budget. Defaults are strict
  // enough to stop credential stuffing; the test suite raises them.
  const testMode = process.env.NODE_ENV === 'test';
  const loginLimiter = rateLimit({
    name: 'login',
    limit: Number(process.env.AUTH_LOGIN_LIMIT) || (testMode ? 100000 : 10),
    windowMs: 5 * 60_000,
    key: (req) => `${clientIp(req)}:${String(req.body?.email || '').toLowerCase().slice(0, 80)}`
  });
  const registerLimiter = rateLimit({
    name: 'register',
    limit: Number(process.env.AUTH_REGISTER_LIMIT) || (testMode ? 100000 : 20),
    windowMs: 60 * 60_000
  });

  app.post('/api/auth/register', registerLimiter, wrap(async (req, res) => {
    const { email, password, fullName, orgName, industry } = req.body || {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(cleanEmail)) throw bad('A valid email is required');
    const pwErr = validatePassword(password);
    if (pwErr) throw bad(pwErr);
    if (!fullName || fullName.trim().length < 2) throw bad('Full name is required');
    if (!orgName || orgName.trim().length < 2) throw bad('Organisation name is required');

    // One transaction: user, organisation, roles, workspace, owner membership,
    // pipeline, stages, subscription, notification and the session. If any step
    // fails the whole thing rolls back — no half-registered accounts.
    const result = await tx(async (t) => {
      const existing = await t.one('select id from users where lower(email) = lower($1)', [cleanEmail]);
      if (existing) throw bad('An account with that email already exists', 409);

      const user = await t.one(
        `insert into users (email, password_hash, full_name, email_verified_at)
         values ($1, $2, $3, null) returning id, email, full_name`,
        [cleanEmail, hashPassword(password), fullName.trim()]
      );

      const base = orgName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'workspace';
      const slug = `${base}-${crypto.randomBytes(2).toString('hex')}`;
      const org = await t.one(
        `insert into organisations (name, slug, industry) values ($1,$2,$3) returning id, name, slug`,
        [orgName.trim(), slug, industry || null]
      );

      for (const key of Object.keys(ROLE_TEMPLATES)) {
        const p = rolePayload(key);
        await t.q(
          `insert into roles (org_id, key, name, description, permissions, is_system)
           values ($1,$2,$3,$4,$5,true)`,
          [org.id, p.key, p.name, p.description, p.permissions]
        );
      }
      const ownerRole = await t.one(`select id from roles where org_id = $1 and key = 'owner'`, [org.id]);
      if (!ownerRole) throw new Error('owner role was not provisioned');

      const ws = await t.one(
        `insert into workspaces (org_id, name, slug, is_default, settings)
         values ($1,$2,'default',true,$3) returning id, name, slug`,
        [org.id, orgName.trim(), JSON.stringify({ created_by: 'self-registration', timezone: 'Asia/Kolkata' })]
      );

      const member = await t.one(
        `insert into members (org_id, user_id, role_id, workspace_id, status, title, joined_at)
         values ($1,$2,$3,$4,'active','Owner', now()) returning id`,
        [org.id, user.id, ownerRole.id, ws.id]
      );

      const pipeline = await t.one(
        `insert into pipelines (org_id, name, is_default) values ($1,'Sales pipeline',true) returning id`,
        [org.id]
      );
      const stageDefs = [
        ['Discovery', 10], ['Site survey', 25], ['Proposal sent', 45],
        ['Negotiation', 70], ['Closed won', 100], ['Closed lost', 0]
      ];
      for (const [i, [name, prob]] of stageDefs.entries()) {
        await t.q(
          `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
           values ($1,$2,$3,$4,$5,$6,$7)`,
          [org.id, pipeline.id, name, i, prob, name === 'Closed won', name === 'Closed lost']
        );
      }

      await t.q(
        `insert into subscriptions (org_id, plan, status, seats, trial_ends_at, current_period_end)
         values ($1,'professional','trialing',5, now() + interval '14 days', now() + interval '14 days')`,
        [org.id]
      );
      await t.q(
        `insert into notifications (org_id, user_id, type, title, body)
         values ($1,$2,'welcome','Welcome to Anvaya','Your workspace is ready. Create your first lead to get started.')`,
        [org.id, user.id]
      );

      // The session is created inside the same transaction, so a successful
      // 201 always means "account + workspace + login" all exist.
      const session = await createSessionIn(t, user.id, req);

      return { user, org, workspace: ws, member, pipeline, session };
    }).catch((err) => {
      // A duplicate email that slipped past the pre-check is still a 409, not a 500.
      if (err && err.code === '23505' && /users_email|email/i.test(err.message || '')) {
        throw bad('An account with that email already exists', 409);
      }
      throw err;
    });

    setSessionCookie(res, result.session.token, result.session.expires, req);
    setOrgCookie(res, result.org.id, req);
    setWorkspaceCookie(res, result.workspace.id, req);
    await q('update users set last_login_at = now() where id = $1', [result.user.id]);

    res.status(201).json({
      ok: true,
      user: { id: result.user.id, email: result.user.email, fullName: result.user.full_name },
      org: result.org,
      workspace: { id: result.workspace.id, name: result.workspace.name, slug: result.workspace.slug },
      member: { id: result.member.id, role: 'owner', status: 'active' }
    });
  }));

  app.post('/api/auth/login', loginLimiter, wrap(async (req, res) => {
    const { email, password } = req.body || {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail || !password) throw bad('Email and password are required');

    const user = await one('select * from users where lower(email) = lower($1)', [cleanEmail]);
    if (!user) {
      dummyVerify(password);                    // constant-ish time for unknown accounts
      throw bad('Incorrect email or password.', 401);
    }
    if (!verifyPassword(password, user.password_hash)) {
      throw bad('Incorrect email or password.', 401);
    }
    if ((user.status || 'active') !== 'active') {
      throw Object.assign(new Error('This account is suspended. Contact your workspace administrator.'), { status: 403 });
    }

    const membership = await one(
      `select m.id, m.org_id, m.workspace_id, m.status, o.status as org_status, o.deleted_at
         from members m join organisations o on o.id = m.org_id
        where m.user_id = $1 and m.status = 'active'
        order by o.name limit 1`,
      [user.id]
    );
    if (!membership) throw bad('This account is not a member of any workspace', 403);
    if (membership.org_status === 'suspended' || membership.deleted_at) {
      throw bad('This workspace is suspended. Contact your administrator.', 403);
    }

    const session = await createSession(user.id, req);
    setSessionCookie(res, session.token, session.expires, req);
    setOrgCookie(res, membership.org_id, req);
    if (membership.workspace_id) setWorkspaceCookie(res, membership.workspace_id, req);

    await q('update users set last_login_at = now() where id = $1', [user.id]);

    // With MFA enabled the session exists but cannot be used until the code is
    // proven. requireAuth ignores it until then.
    if (user.mfa_enabled_at) {
      await q('update sessions set mfa_ok = false where id = $1', [session.id]);
      return res.json({ ok: true, mfaRequired: true, sessionExpires: session.expires });
    }

    const ctx = await loadContext(req);
    const orgSettings = await one(`select settings from organisations where id = $1`, [membership.org_id]);
    const requireMfa = orgSettings?.settings?.require_mfa === true || orgSettings?.settings?.require_mfa === 'true';

    res.json({
      ok: true,
      mfaSetupRequired: requireMfa,
      sessionExpires: session.expires,
      user: { id: user.id, email: user.email, fullName: user.full_name },
      org: { id: membership.org_id, name: ctx?.orgName || null },
      workspace: ctx ? { id: ctx.workspaceId, name: ctx.workspaceName } : null
    });
  }));

  app.post('/api/auth/logout', wrap(async (req, res) => {
    const ctx = await loadContext(req);
    if (ctx) await destroySession(ctx.token);
    clearSessionCookie(res, req);
    res.json({ ok: true });
  }));

  app.get('/api/auth/me', wrap(async (req, res) => {
    const ctx = await loadContext(req);
    if (!ctx) return res.status(401).json({ error: 'Not authenticated', code: 'NOT_AUTHENTICATED' });
    const sub = await one(`select * from subscriptions where org_id = $1`, [ctx.orgId]);
    const counts = await one(
      `select (select count(*) from members where org_id = $1 and status='active')::int as seats,
              (select count(*) from leads where org_id = $1 and deleted_at is null)::int as leads,
              (select count(*) from deals where org_id = $1 and deleted_at is null)::int as deals`,
      [ctx.orgId]
    );
    res.json({
      user: { id: ctx.userId, email: ctx.email, fullName: ctx.fullName, isPlatformAdmin: ctx.isPlatformAdmin },
      org: { id: ctx.orgId, name: ctx.orgName, currency: ctx.currency, timezone: ctx.timezone, plan: ctx.plan },
      workspace: { id: ctx.workspaceId, name: ctx.workspaceName },
      role: { key: ctx.roleKey, name: ctx.roleName },
      perms: ctx.perms,
      memberships: ctx.memberships,
      subscription: sub,
      counts
    });
  }));

  app.post('/api/auth/switch-org', requireAuth, wrap(async (req, res) => {
    const { orgId } = req.body || {};
    const member = await one(
      `select m.org_id, m.workspace_id from members m where m.user_id = $1 and m.org_id = $2 and m.status = 'active'`,
      [req.ctx.userId, orgId]
    );
    if (!member) throw bad('You are not a member of that organisation', 403);
    setOrgCookie(res, orgId, req);
    if (member.workspace_id) setWorkspaceCookie(res, member.workspace_id, req);
    res.json({ ok: true, orgId, workspaceId: member.workspace_id || null });
  }));

  // Switch workspace inside the active organisation. Membership is re-checked
  // against the database, never trusted from the request body.
  app.post('/api/auth/switch-workspace', requireAuth, wrap(async (req, res) => {
    const { workspaceId } = req.body || {};
    const ws = await one(
      `select w.id, w.name from workspaces w
        where w.id = $1 and w.org_id = $2
          and exists (select 1 from members m
                       where m.user_id = $3 and m.org_id = $2 and m.status = 'active')`,
      [workspaceId, req.ctx.orgId, req.ctx.userId]
    );
    if (!ws) throw bad('Workspace not found in this organisation', 404);
    await q(`update members set workspace_id = $1 where org_id = $2 and user_id = $3`,
      [ws.id, req.ctx.orgId, req.ctx.userId]);
    setWorkspaceCookie(res, ws.id, req);
    res.json({ ok: true, workspace: ws });
  }));

  // Invitations are recorded and a one-time token is returned. No email is
  // sent because no mail provider is configured — the API says so explicitly.
  app.post('/api/auth/invite', requireAuth, requirePerm('member.write'), wrap(async (req, res) => {
    const { email, fullName, roleKey = 'sales' } = req.body || {};
    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw bad('A valid email is required');
    if (!ROLE_TEMPLATES[roleKey]) throw bad('Unknown role');

    const role = await one(`select id from roles where org_id = $1 and key = $2`, [req.ctx.orgId, roleKey]);
    if (!role) throw bad('Role not provisioned in this workspace', 400);

    const existing = await one('select id from users where lower(email) = lower($1)', [email]);
    const tempPassword = crypto.randomBytes(18).toString('base64url');
    const inviteToken = crypto.randomBytes(24).toString('hex');
    const inviteHash = crypto.createHash('sha256').update(inviteToken).digest('hex');

    const user = existing || await one(
      `insert into users (email, password_hash, full_name) values (lower($1),$2,$3) returning id`,
      [email, hashPassword(tempPassword), fullName || email.split('@')[0]]
    );

    const already = await one(
      `select id from members where org_id = $1 and user_id = $2`, [req.ctx.orgId, user.id]
    );
    if (already) throw bad('That person is already a member of this workspace', 409);

    const member = await one(
      `insert into members (org_id, user_id, role_id, workspace_id, status, invited_by, invited_at,
                            invite_token_hash, invite_expires_at)
       values ($1,$2,$3,$4,'invited',$5, now(), $6, now() + interval '7 days') returning id, status`,
      [req.ctx.orgId, user.id, role.id, req.ctx.workspaceId || null, req.ctx.userId, inviteHash]
    );

    await writeAudit(req.ctx, {
      action: 'member.invited', entity: 'member', entityId: member.id,
      after: { email, roleKey }, ip: req.ip
    });

    res.status(201).json({
      member,
      inviteToken,
      emailSent: false,
      note: 'No mail provider is configured, so nothing was emailed. Deliver this token to the invitee through your own channel.'
    });
  }));

  app.post('/api/auth/accept-invite', rateLimit({ name: 'accept-invite', limit: 20, windowMs: 15 * 60_000 }), wrap(async (req, res) => {
    const { token, password, email } = req.body || {};
    if (!token || !password) throw bad('Token and new password are required');
    const pwErr = validatePassword(password);
    if (pwErr) throw bad(pwErr);

    // The token is verified against its stored hash and its expiry — it is not
    // decorative. Without this, anyone could claim a pending invitation by
    // knowing the email address alone.
    const tokenHash = crypto.createHash('sha256').update(String(token)).digest('hex');
    const pending = await one(
      `select m.id, m.user_id, m.org_id, m.workspace_id
         from members m join users u on u.id = m.user_id
        where m.status = 'invited'
          and m.invite_token_hash = $1
          and (m.invite_expires_at is null or m.invite_expires_at > now())
          and ($2 = '' or lower(u.email) = lower($2))`,
      [tokenHash, email || '']
    );
    if (!pending) throw bad('This invitation is invalid or has expired', 404);

    await q('update users set password_hash = $2, email_verified_at = now() where id = $1',
      [pending.user_id, hashPassword(password)]);
    await q(`update members set status = 'active', joined_at = now(), invite_token_hash = null
              where id = $1`, [pending.id]);

    const session = await createSession(pending.user_id, req);
    setSessionCookie(res, session.token, session.expires, req);
    setOrgCookie(res, pending.org_id, req);
    if (pending.workspace_id) setWorkspaceCookie(res, pending.workspace_id, req);
    res.json({ ok: true });
  }));

  // ---------------------------------------------------------- analytics ---
  app.get('/api/dashboard', requireAuth, wrap(async (req, res) => {
    res.json(await dashboard(req.ctx));
  }));

  // ---------------------------------------------------------- pipelines ---
  app.get('/api/pipelines', requireAuth, wrap(async (req, res) => {
    const data = await asUser(req.ctx, async (t) => {
      const pipelines = await t.q(`select * from pipelines order by is_default desc, name`);
      const stages = await t.q(`select * from stages order by position`);
      return pipelines.map(p => ({ ...p, stages: stages.filter(s => s.pipeline_id === p.id) }));
    });
    res.json({ data });
  }));

  app.post('/api/pipelines/:id/stages', requireAuth, requirePerm('pipeline.write'), wrap(async (req, res) => {
    const { name, probability = 10, isWon = false, isLost = false } = req.body || {};
    if (!name) throw bad('Stage name is required');
    const row = await asUser(req.ctx, (t) => t.one(
      `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
       values ($1,$2,$3,(select coalesce(max(position),0)+1 from stages where pipeline_id = $2),$4,$5,$6) returning *`,
      [req.ctx.orgId, req.params.id, name, probability, isWon, isLost]
    ));
    await writeAudit(req.ctx, { action: 'stage.created', entity: 'stage', entityId: row.id, after: row });
    res.status(201).json(row);
  }));

  // ------------------------------------------------------- lead convert ---
  app.post('/api/leads/:id/convert', requireAuth, requirePerm('lead.write'), wrap(async (req, res) => {
    const { dealTitle, dealValue, stageId, companyId } = req.body || {};
    const result = await asUser(req.ctx, async (t) => {
      const lead = await t.one(`select * from leads where id = $1 and deleted_at is null`, [req.params.id]);
      if (!lead) throw bad('Lead not found', 404);
      if (lead.converted_contact_id) throw bad('This lead has already been converted', 409);

      let company = companyId
        ? await t.one(`select * from companies where id = $1`, [companyId])
        : await t.one(`select * from companies where lower(name) = lower($1) and deleted_at is null`, [lead.company_name || '']);
      if (!company && lead.company_name) {
        company = await t.one(
          `insert into companies (org_id, name, owner_id, industry) values ($1,$2,$3,'Unspecified') returning *`,
          [req.ctx.orgId, lead.company_name, lead.owner_id]
        );
      }

      const [first, ...rest] = String(lead.name).split(' ');
      const contact = await t.one(
        `insert into contacts (org_id, company_id, first_name, last_name, email, phone, owner_id, tags)
         values ($1,$2,$3,$4,$5,$6,$7,$8) returning *`,
        [req.ctx.orgId, company?.id || null, first, rest.join(' ') || null, lead.email, lead.phone,
          lead.owner_id, ['converted']]
      );

      const pipeline = await t.one(`select id from pipelines order by is_default desc limit 1`);
      const stage = stageId
        ? await t.one(`select * from stages where id = $1`, [stageId])
        : await t.one(`select * from stages where pipeline_id = $1 order by position limit 1`, [pipeline.id]);

      const deal = await t.one(
        `insert into deals (org_id, pipeline_id, stage_id, company_id, contact_id, title, value, currency,
                            probability, expected_close_date, owner_id, source_lead_id)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9, current_date + 30, $10, $11) returning *`,
        [req.ctx.orgId, pipeline.id, stage.id, company?.id || null, contact.id,
          dealTitle || `${lead.company_name || lead.name} — new opportunity`,
          dealValue ?? lead.estimated_value ?? 0, lead.currency, stage.probability,
          lead.owner_id, lead.id]
      );

      const updated = await t.one(
        `update leads set status = 'converted', converted_contact_id = $2, converted_deal_id = $3
          where id = $1 returning *`,
        [lead.id, contact.id, deal.id]
      );

      await t.q(
        `insert into activities (org_id, type, subject, body, contact_id, company_id, deal_id, owner_id, created_by)
         values ($1,'note','Lead converted',$2,$3,$4,$5,$6,$7)`,
        [req.ctx.orgId, `Converted from lead ${lead.name}.`, contact.id, company?.id || null, deal.id,
          lead.owner_id, req.ctx.userId]
      );

      return { lead: updated, contact, company, deal };
    });

    await writeAudit(req.ctx, {
      action: 'lead.converted', entity: 'lead', entityId: req.params.id,
      after: { contactId: result.contact.id, dealId: result.deal.id }
    });
    await trigger('lead.status_changed', req.ctx, result.lead, result.lead.id);
    await dispatchEvent(req.ctx.orgId, 'lead.converted', {
      leadId: result.lead.id, contactId: result.contact.id, dealId: result.deal.id
    });
    res.json(result);
  }));

  // ---------------------------------------------------------- deal stage ---
  app.patch('/api/deals/:id/stage', requireAuth, requirePerm('deal.write'), wrap(async (req, res) => {
    const { stageId } = req.body || {};
    if (!stageId) throw bad('stageId is required');

    const result = await asUser(req.ctx, async (t) => {
      const before = await t.one(`select * from deals where id = $1 and deleted_at is null`, [req.params.id]);
      if (!before) throw bad('Deal not found', 404);
      const stage = await t.one(`select * from stages where id = $1`, [stageId]);
      if (!stage) throw bad('Stage not found', 404);

      const status = stage.is_won ? 'won' : stage.is_lost ? 'lost' : 'open';
      const after = await t.one(
        `update deals set stage_id = $2, probability = $3, status = $4, stage_changed_at = now()
          where id = $1 returning *`,
        [before.id, stage.id, stage.probability, status]
      );
      return { before, after, stage };
    });

    await writeAudit(req.ctx, {
      action: 'deal.stage_changed', entity: 'deal', entityId: result.after.id,
      before: { stage_id: result.before.stage_id, status: result.before.status },
      after: { stage_id: result.after.stage_id, status: result.after.status }, ip: req.ip
    });
    await trigger('deal.stage_changed', req.ctx, result.after, result.after.id);
    await dispatchEvent(req.ctx.orgId, 'deal.stage_changed', {
      dealId: result.after.id, from: result.before.stage_id, to: result.after.stage_id, status: result.after.status
    });
    if (result.after.status === 'won') {
      await trigger('deal.won', req.ctx, result.after, result.after.id);
      await dispatchEvent(req.ctx.orgId, 'deal.won', { dealId: result.after.id, value: result.after.value });
    }
    res.json(result.after);
  }));

  // ------------------------------------------------------- customer 360 ---
  app.get('/api/contacts/:id/360', requireAuth, wrap(async (req, res) => {
    const payload = await asUser(req.ctx, async (t) => {
      const contact = await t.one(
        `select c.*, co.name as company_name, co.industry, co.city as company_city,
                coalesce(u.full_name,'Unassigned') as owner_name
           from contacts c
           left join companies co on co.id = c.company_id
           left join members m on m.id = c.owner_id
           left join users u on u.id = m.user_id
          where c.id = $1 and c.deleted_at is null`, [req.params.id]
      );
      if (!contact) return null;
      const [activities, deals, tickets, tasks, invoices] = await Promise.all([
        t.q(`select * from activities where contact_id = $1 order by occurred_at desc limit 40`, [contact.id]),
        t.q(`select d.*, s.name as stage_name from deals d join stages s on s.id = d.stage_id
              where d.contact_id = $1 and d.deleted_at is null order by d.created_at desc`, [contact.id]),
        t.q(`select * from tickets where contact_id = $1 order by created_at desc`, [contact.id]),
        t.q(`select * from tasks where related_id = $1 order by due_date nulls last limit 20`, [contact.id]),
        t.q(`select * from invoices where contact_id = $1 order by created_at desc`, [contact.id])
      ]);
      const lifetime = deals.filter(d => d.status === 'won').reduce((a, d) => a + Number(d.value), 0);
      return { contact, activities, deals, tickets, tasks, invoices, lifetime };
    });
    if (!payload) throw bad('Contact not found', 404);
    res.json(payload);
  }));

  // ---------------------------------------------------------------- AI ----
  app.post('/api/ai/copilot', requireAuth, requirePerm('ai.read'), wrap(async (req, res) => {
    const { message, contactId } = req.body || {};
    if (!message || String(message).trim().length < 2) throw bad('Ask a question');
    res.json(await ask(req.ctx, String(message).slice(0, 1000), { contactId }));
  }));

  app.get('/api/ai/runs', requireAuth, requirePerm('ai.read'), wrap(async (req, res) => {
    res.json({ data: await recentRuns(req.ctx) });
  }));

  app.post('/api/ai/actions/:id/:decision', requireAuth, requirePerm('ai.write'), wrap(async (req, res) => {
    const { decision } = req.params;
    if (!['approve', 'reject'].includes(decision)) throw bad('Decision must be approve or reject');
    res.json(await approveAction(req.ctx, req.params.id, decision));
  }));

  // ---------------------------------------------------------- workflows ---
  app.get('/api/workflows/meta', requireAuth, wrap(async (req, res) => {
    res.json({ triggers: TRIGGER_EVENTS, actions: ACTION_TYPES });
  }));

  app.get('/api/workflows/runs', requireAuth, requirePerm('workflow.read'), wrap(async (req, res) => {
    res.json({ data: await listRuns(req.ctx, req.query.workflowId) });
  }));

  app.get('/api/workflows/runs/:id/steps', requireAuth, requirePerm('workflow.read'), wrap(async (req, res) => {
    res.json({ data: await runSteps(req.ctx, req.params.id) });
  }));

  app.post('/api/workflows/:id/test', requireAuth, requirePerm('workflow.write'), wrap(async (req, res) => {
    const wf = await asUser(req.ctx, (t) => t.one(`select * from workflows where id = $1`, [req.params.id]));
    if (!wf) throw bad('Workflow not found', 404);
    const { record = {}, entityId } = req.body || {};
    const { runWorkflow } = await import('./workflows.js');
    const out = await runWorkflow(req.ctx, wf, record, (wf.trigger?.entity || 'deal'), entityId || null);
    res.json(out);
  }));

  // ---------------------------------------------------------- audit log ---
  app.get('/api/audit-logs', requireAuth, requirePerm('audit.read'), wrap(async (req, res) => {
    res.json({ data: await listAudit(req.ctx, { limit: Number(req.query.limit) || 100, offset: Number(req.query.offset) || 0 }) });
  }));

  // ------------------------------------------------------------- search ---
  app.get('/api/search', requireAuth, wrap(async (req, res) => {
    const term = String(req.query.q || '').trim();
    if (term.length < 2) return res.json({ data: [] });
    const like = `%${term}%`;
    const rows = await asUser(req.ctx, (t) => t.q(`
      select 'lead' as type, id, name as title, coalesce(company_name,'') as subtitle from leads
        where deleted_at is null and (name ilike $1 or company_name ilike $1)
      union all
      select 'contact', c.id, (c.first_name || ' ' || coalesce(c.last_name,'')), coalesce(co.name,'')
        from contacts c left join companies co on co.id = c.company_id
       where c.deleted_at is null and (c.first_name ilike $1 or c.last_name ilike $1 or c.email ilike $1)
      union all
      select 'company', id, name, coalesce(industry,'') from companies
       where deleted_at is null and name ilike $1
      union all
      select 'deal', id, title, coalesce(value::text,'') from deals
       where deleted_at is null and title ilike $1
      union all
      select 'ticket', id, subject, number from tickets where subject ilike $1 or number ilike $1
      limit 20`, [like]));
    res.json({ data: rows });
  }));

  // ------------------------------------------------- generic resources ----
  for (const key of Object.keys(RESOURCES)) {
    const res = RESOURCES[key];
    const permBase = res.perm;

    app.get(`/api/${key}`, requireAuth, requirePerm(`${permBase}.read`), wrap(async (req, res) => {
      res.json(await listResource(req.ctx, key, req.query));
    }));

    app.get(`/api/${key}/:id`, requireAuth, requirePerm(`${permBase}.read`), wrap(async (req, res) => {
      const row = await getResource(req.ctx, key, req.params.id);
      if (!row) throw bad('Not found', 404);
      res.json(row);
    }));

    app.post(`/api/${key}`, requireAuth, requirePerm(`${permBase}.write`), wrap(async (req, res) => {
      const row = await createResource(req.ctx, key, req.body || {});
      await writeAudit(req.ctx, { action: `${key}.created`, entity: key, entityId: row.id, after: row, ip: req.ip });
      await dispatchEvent(req.ctx.orgId, `${key.replace(/s$/, '')}.created`,
        { id: row.id, title: row.title || row.name || row.subject || null, source: row.source || null });
      if (key === 'leads') await trigger('lead.created', req.ctx, row, row.id);
      if (key === 'deals') await trigger('deal.created', req.ctx, row, row.id);
      if (key === 'contacts') await trigger('contact.created', req.ctx, row, row.id);
      if (key === 'tickets') await trigger('ticket.created', req.ctx, row, row.id);
      res.status(201).json(row);
    }));

    app.patch(`/api/${key}/:id`, requireAuth, requirePerm(`${permBase}.write`), wrap(async (req, res) => {
      const before = await getResource(req.ctx, key, req.params.id);
      if (!before) throw bad('Not found', 404);
      const row = await updateResource(req.ctx, key, req.params.id, req.body || {});
      await writeAudit(req.ctx, {
        action: `${key}.updated`, entity: key, entityId: row.id,
        before: pick(before, Object.keys(req.body || {})), after: pick(row, Object.keys(req.body || {})), ip: req.ip
      });
      if (key === 'leads' && req.body?.status && req.body.status !== before.status) {
        await trigger('lead.status_changed', req.ctx, row, row.id);
      }
      res.json(row);
    }));

    app.delete(`/api/${key}/:id`, requireAuth, requirePerm(`${permBase}.delete`), wrap(async (req, res) => {
      const row = await deleteResource(req.ctx, key, req.params.id);
      if (!row) throw bad('Not found', 404);
      await writeAudit(req.ctx, { action: `${key}.deleted`, entity: key, entityId: req.params.id, ip: req.ip });
      res.json({ ok: true });
    }));
  }

  // -------------------------------------------------------- super admin ---
  app.get('/api/superadmin/orgs', requireAuth, requirePlatformAdmin, wrap(async (req, res) => {
    const rows = await q(`
      select o.id, o.name, o.slug, o.plan, o.status, o.created_at,
             (select count(*) from members m where m.org_id = o.id and m.status='active')::int as members,
             (select count(*) from leads l where l.org_id = o.id and l.deleted_at is null)::int as leads,
             (select count(*) from ai_runs r where r.org_id = o.id)::int as ai_runs
        from organisations o where o.deleted_at is null order by o.created_at desc`);
    res.json({ data: rows });
  }));

  app.get('/api/superadmin/health', requireAuth, requirePlatformAdmin, wrap(async (req, res) => {
    const stats = await one(`
      select (select count(*) from organisations)::int as orgs,
             (select count(*) from users)::int as users,
             (select count(*) from sessions where revoked_at is null and expires_at > now())::int as sessions,
             (select count(*) from audit_logs where created_at > now() - interval '24 hours')::int as audits_24h,
             (select count(*) from workflow_runs where status='failed' and started_at > now() - interval '24 hours')::int as failed_runs`);
    res.json(stats);
  }));

  // ----------------------------------------------------------- api 404 ---
  // Anything under /api that no route claimed is a JSON 404, not index.html.
  app.use('/api', (req, res) => {
    res.status(404).json({ error: 'Unknown API endpoint', code: 'NOT_FOUND', path: req.originalUrl.split('?')[0] });
  });

  // -------------------------------------------------------------- static ---
  app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    const name = decodeURIComponent(req.path.replace(/^\/+/, ''));
    if (PUBLIC_FILES.has(name) || name.startsWith('icons/')) {
      if (!/^icons\/[a-z0-9._-]+$/i.test(name) && name.startsWith('icons/')) return next();
      return res.sendFile(path.join(WEB_DIR, name), err => { if (err) next(); });
    }
    return next();
  });
  app.get(/^\/(?!api).*/, (req, res) => res.sendFile(path.join(WEB_DIR, 'index.html')));

  // -------------------------------------------------------------- errors ---
  // API paths always answer JSON — never the frontend HTML page, and never a
  // stack trace. A database outage is 503 with a sentence a user can act on.
  app.use((err, req, res, next) => {
    if (err instanceof DbUnavailableError || err?.code === 'DB_UNAVAILABLE') {
      const info = explainDbError(err);
      console.error(`[api] database unavailable (${info.code}/${info.kind}): ${info.message}`);
      return res.status(503).json({
        error: 'Anvaya CRM is temporarily unable to connect to its database. Please try again.',
        code: info.code || 'DB_UNAVAILABLE',
        retryable: info.retryable !== false
      });
    }
    if (err instanceof TenantContextError) {
      console.error(`[api] tenant context failed: ${err.message}`);
      return res.status(500).json({
        error: 'Your workspace context could not be established. Please sign in again.',
        code: 'TENANT_CONTEXT_FAILED'
      });
    }
    const status = err.status || err.statusCode || 500;
    if (status >= 500) console.error('[api]', err.code || '', err.message);
    res.status(status).json({
      error: status >= 500 ? 'Something went wrong' : err.message,
      code: err.code && typeof err.code === 'string' && /^[A-Z_]+$/.test(err.code) ? err.code : undefined
    });
  });

  return app;
}

function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (obj && k in obj) out[k] = obj[k];
  return out;
}
