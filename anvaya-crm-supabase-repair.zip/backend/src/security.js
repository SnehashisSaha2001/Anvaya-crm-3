// Request-level security: rate limiting and cross-site request protection.
//
// Both are deliberately small and dependency-free. The limiter is per process:
// on Vercel each instance keeps its own window, which still stops credential
// stuffing from a single client, and a shared store (Upstash/Redis) can be
// dropped in later behind the same function signature.

const buckets = new Map();

/**
 * Fixed-window limiter.
 * @param {string} key      caller identity, e.g. `login:1.2.3.4`
 * @param {number} limit    allowed hits per window
 * @param {number} windowMs window length
 */
export function hit(key, limit, windowMs) {
  const now = Date.now();
  const entry = buckets.get(key);
  if (!entry || now >= entry.resetAt) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, retryAfter: 0 };
  }
  entry.count += 1;
  if (entry.count > limit) {
    return { allowed: false, remaining: 0, retryAfter: Math.ceil((entry.resetAt - now) / 1000) };
  }
  return { allowed: true, remaining: limit - entry.count, retryAfter: 0 };
}

// Keep the map from growing without bound in a long-lived process.
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of buckets) if (now >= entry.resetAt) buckets.delete(key);
}, 60_000).unref?.();

export function clientIp(req) {
  const fwd = req.headers?.['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length) return fwd.split(',')[0].trim();
  return req.ip || req.socket?.remoteAddress || 'unknown';
}

/** Express middleware factory: 429 with a readable message. */
export function rateLimit({ name, limit, windowMs, key = (req) => clientIp(req) }) {
  return (req, res, next) => {
    const result = hit(`${name}:${key(req)}`, limit, windowMs);
    res.setHeader('X-RateLimit-Limit', String(limit));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, result.remaining)));
    if (!result.allowed) {
      res.setHeader('Retry-After', String(result.retryAfter));
      return res.status(429).json({
        error: 'Too many attempts. Please wait a moment and try again.',
        code: 'RATE_LIMITED',
        retryAfter: result.retryAfter
      });
    }
    next();
  };
}

/** Requests that authenticate with something other than a cookie are not CSRF-able. */
function isNonCookieAuth(req) {
  if (req.headers['x-api-key']) return true;
  const auth = String(req.headers.authorization || '');
  if (/^bearer\s+/i.test(auth)) return true;
  if (req.headers['x-inbound-signature'] || req.headers['x-webhook-signature']) return true;
  const p = req.path || '';
  return p.startsWith('/api/inbound')
    || p.startsWith('/api/webhooks')
    || p.startsWith('/api/growth/webhooks')
    || p.includes('/webhook');
}

function allowedOrigins(req) {
  const set = new Set();
  const configured = [process.env.CORS_ORIGIN, process.env.PUBLIC_APP_URL, process.env.PUBLIC_API_URL]
    .filter(Boolean)
    .flatMap((v) => v.split(','))
    .map((v) => v.trim())
    .filter(Boolean);
  for (const origin of configured) {
    try { set.add(new URL(origin).origin); } catch { /* ignore malformed */ }
  }
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (host) {
    set.add(`https://${host}`);
    set.add(`http://${host}`);
  }
  return set;
}

/**
 * Origin/Sec-Fetch-Site check for state-changing requests.
 * A browser always sends Origin on a cross-site POST; a form post from another
 * site therefore cannot silently log a user out, create a workspace or change
 * a password. Non-browser clients (curl, tests, server-to-server) send no
 * Origin and are unaffected.
 */
export function originGuard(req, res, next) {
  const safe = req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS';
  if (safe) return next();
  if (isNonCookieAuth(req)) return next();

  const site = req.headers['sec-fetch-site'];
  if (site && !['same-origin', 'same-site', 'none'].includes(String(site))) {
    return res.status(403).json({ error: 'Cross-site request blocked', code: 'CROSS_SITE_BLOCKED' });
  }

  const origin = req.headers.origin;
  if (!origin) return next();                 // non-browser client
  if (origin === 'null') {
    return res.status(403).json({ error: 'Cross-site request blocked', code: 'CROSS_SITE_BLOCKED' });
  }
  let originHost;
  try { originHost = new URL(origin).origin; } catch {
    return res.status(403).json({ error: 'Cross-site request blocked', code: 'CROSS_SITE_BLOCKED' });
  }
  if (allowedOrigins(req).has(originHost)) return next();
  return res.status(403).json({ error: 'Cross-site request blocked', code: 'CROSS_SITE_BLOCKED' });
}

export const __testing = { buckets, clear: () => buckets.clear() };
