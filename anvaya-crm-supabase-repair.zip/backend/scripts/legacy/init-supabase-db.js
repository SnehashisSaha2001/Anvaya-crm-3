import pg from 'pg';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false }
});

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$16384$8$1$${salt}$${hash}`;
}

async function main() {
  console.log('[supabase] Connecting to Supabase database...');
  await pool.query('select 1');
  console.log('[supabase] Connected successfully!');

  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const schemaPath = path.join(__dirname, '../../supabase/anvaya-supabase.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');

  console.log('[supabase] Applying schema (anvaya-supabase.sql)...');
  await pool.query(schemaSql);
  console.log('[supabase] Schema applied successfully!');

  // Check if demo user exists
  const email = 'sneha@brightline.in';
  const check = await pool.query('select id from users where lower(email) = lower($1)', [email]);
  
  if (check.rows.length === 0) {
    console.log('[supabase] Seeding demo user and organisation...');
    const passwordHash = hashPassword('AnvayaDemo2026');
    
    const client = await pool.connect();
    try {
      await client.query('begin');
      
      const userRes = await client.query(
        'insert into users (email, password_hash, full_name, email_verified_at) values ($1, $2, $3, now()) returning id',
        [email, passwordHash, 'Snehasis Saha']
      );
      const userId = userRes.rows[0].id;

      const orgRes = await client.query(
        `insert into organisations (name, slug, industry, currency, timezone, plan)
         values ('Brightline Security Solutions', 'brightline-security', 'Security systems integrator', 'INR', 'Asia/Kolkata', 'professional')
         returning id`
      );
      const orgId = orgRes.rows[0].id;

      await client.query(
        `insert into workspaces (org_id, name, slug, is_default) values ($1, 'Brightline Security', 'default', true)`,
        [orgId]
      );

      const roleRes = await client.query(
        `insert into roles (org_id, key, name, description, permissions, is_system)
         values ($1, 'owner', 'Owner', 'Full access', '{*}'::text[], true) returning id`,
        [orgId]
      );
      const roleId = roleRes.rows[0].id;

      await client.query(
        `insert into members (org_id, user_id, role_id, status, title)
         values ($1, $2, $3, 'active', 'Managing Director')`,
        [orgId, userId, roleId]
      );

      const pipelineRes = await client.query(
        `insert into pipelines (org_id, name, is_default) values ($1, 'Sales pipeline', true) returning id`,
        [orgId]
      );
      const pipelineId = pipelineRes.rows[0].id;

      const stages = [
        ['Discovery', 1, 20, false, false],
        ['Site survey', 2, 35, false, false],
        ['Proposal sent', 3, 55, false, false],
        ['Negotiation', 4, 75, false, false],
        ['Closed won', 5, 100, true, false],
        ['Closed lost', 6, 0, false, true]
      ];

      for (const [name, pos, prob, won, lost] of stages) {
        await client.query(
          `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
           values ($1, $2, $3, $4, $5, $6, $7)`,
          [orgId, pipelineId, name, pos, prob, won, lost]
        );
      }

      await client.query('commit');
      console.log('[supabase] Demo user (sneha@brightline.in) and workspace seeded successfully!');
    } catch (err) {
      await client.query('rollback');
      throw err;
    } finally {
      client.release();
    }
  } else {
    console.log('[supabase] Demo user already exists in Supabase database.');
  }

  await pool.end();
  console.log('[supabase] Setup completed successfully!');
}

main().catch(err => {
  console.error('[supabase] Setup failed:', err);
  process.exit(1);
});
